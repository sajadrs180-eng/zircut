@file:OptIn(ExperimentalMaterial3Api::class)

package app.zircut.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.zircut.MainViewModel
import app.zircut.Stage
import app.zircut.core.ModelSize
import app.zircut.core.Planner
import app.zircut.core.Styles

private val CardBg = Color(0xCC12122E)

@UnstableApi
@Composable
fun ZirCutApp(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val theme = Themes.byId(ui.themeId)
    var showSettings by remember { mutableStateOf(false) }
    val busy = ui.stage is Stage.Working

    val ctx = LocalContext.current
    DisposableEffect(busy) {
        val w = (ctx as? Activity)?.window
        if (busy) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickVideo(uri)
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFont(uri)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Image(
                painter = painterResource(theme.res),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x55000000)))

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("زیرکات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showSettings = true }) { Text("تنظیمات") }
                }
                Spacer(Modifier.height(12.dp))

                when (val s = ui.stage) {
                    is Stage.Idle -> Panel {
                        Text("ویدیوت رو انتخاب کن", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("زیرنویس خودکار، حذف سکوت و «ام…»، زوم و خروجی عمودی برای ریلز و شورت", color = Color(0xFFCFCBEA))
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("انتخاب ویدیو") }
                    }

                    is Stage.NeedModel -> Panel {
                        Text("یه مدل تشخیص گفتار لازمه", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("فقط بار اول دانلود می‌شه و بعدش همه‌چیز آفلاین کار می‌کنه.", color = Color(0xFFCFCBEA))
                        Spacer(Modifier.height(12.dp))
                        ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.downloadModel() }, modifier = Modifier.fillMaxWidth()) {
                            Text("دانلود مدل (${ui.modelSize.sizeMb} مگابایت)")
                        }
                        OutlinedButton(
                            onClick = { modelPicker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("وارد کردن فایل مدل (.bin)") }
                        TextButton(onClick = { vm.reset() }) { Text("انصراف") }
                    }

                    is Stage.Working -> Panel {
                        Text(s.label, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(16.dp))
                        if (s.progress == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        else LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        Text("صفحه رو روشن نگه دار. ممکنه چند دقیقه طول بکشه.", color = Color(0xFFCFCBEA))
                        TextButton(onClick = { vm.cancel() }) { Text("لغو") }
                    }

                    is Stage.Review -> {
                        val info = ui.info
                        val words = ui.phrases.flatMap { it.words }
                        val kept = if (info != null) Planner.ranges(words, info.durationMs, ui.options).sumOf { it.len } else 0L
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                            item {
                                Panel {
                                    Text("تنظیمات ادیت", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    SwitchRow("زیرنویس", ui.options.captions) { vm.setOptions(ui.options.copy(captions = it)) }
                                    SwitchRow("حذف سکوت‌ها", ui.options.removeSilence) { vm.setOptions(ui.options.copy(removeSilence = it)) }
                                    SwitchRow("زوم ریتمی", ui.options.zoom) { vm.setOptions(ui.options.copy(zoom = it)) }
                                    SwitchRow("خروجی عمودی (۹:۱۶)", ui.options.vertical) { vm.setOptions(ui.options.copy(vertical = it)) }
                                    if (info != null) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            "مدت ویدیو: ${info.durationMs / 1000} ثانیه  ←  بعد از ادیت: ${kept / 1000} ثانیه",
                                            color = Color(0xFFCFCBEA)
                                        )
                                    }
                                }
                            }
                            item {
                                Panel {
                                    Text("استایل زیرنویس", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Styles.all.forEach { st ->
                                            FilterChip(selected = ui.styleId == st.id, onClick = { vm.setStyle(st.id) }, label = { Text(st.nameFa) })
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("فونت", style = MaterialTheme.typography.titleSmall, color = Color.White)
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        ui.fonts.forEach { f ->
                                            FilterChip(selected = ui.fontId == f.id, onClick = { vm.setFont(f.id) },
                                                label = { Text(if (f.persianOk) f.name else f.name + " (بدون فارسی)") })
                                        }
                                    }
                                    TextButton(onClick = { fontPicker.launch(arrayOf("*/*")) }) { Text("افزودن فونت (.ttf / .otf)") }
                                }
                            }
                            item {
                                Text("متن زیرنویس (می‌تونی ویرایش کنی)", color = Color.White, style = MaterialTheme.typography.titleSmall)
                            }
                            itemsIndexed(ui.phrases) { i, p ->
                                var t by remember(i) { mutableStateOf(p.text) }
                                OutlinedTextField(
                                    value = t,
                                    onValueChange = { t = it; vm.editPhrase(i, it) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            if (ui.phrases.isEmpty()) {
                                item { Panel { Text("گفتاری تشخیص داده نشد. ویدیو بدون زیرنویس ساخته می‌شه.", color = Color(0xFFCFCBEA)) } }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { vm.export() }, modifier = Modifier.fillMaxWidth()) { Text("ساخت ویدیو") }
                        TextButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("ویدیوی دیگه") }
                    }

                    is Stage.Done -> {
                        Panel {
                            Text("ویدیو آماده شد و توی گالری (Movies/ZirCut) ذخیره شد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Spacer(Modifier.height(10.dp))
                            AndroidView(
                                factory = { c ->
                                    VideoView(c).apply {
                                        val mc = MediaController(c)
                                        mc.setAnchorView(this)
                                        setMediaController(mc)
                                        setVideoURI(s.uri)
                                        setOnPreparedListener { it.isLooping = true; start() }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(420.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { share(ctx, s.uri) }, modifier = Modifier.fillMaxWidth()) { Text("اشتراک‌گذاری") }
                        OutlinedButton(onClick = { vm.backToReview() }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش دوباره") }
                        TextButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("ویدیوی جدید") }
                    }

                    is Stage.Failed -> Panel {
                        Text("یه مشکلی پیش اومد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text(s.message, color = Color(0xFFFFB4B4))
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("برگشت") }
                    }
                }
            }

            if (showSettings) {
                ModalBottomSheet(onDismissRequest = { showSettings = false }) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("تم پس‌زمینه", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Themes.all.forEach { t ->
                                    FilterChip(selected = ui.themeId == t.id, onClick = { vm.setTheme(t.id) }, label = { Text(t.nameFa) })
                                }
                            }
                            Text("زبان ویدیو", style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار").forEach { (code, name) ->
                                    FilterChip(selected = ui.options.language == code, onClick = { vm.setLanguage(code) }, label = { Text(name) })
                                }
                            }
                            Text("مدل تشخیص گفتار", style = MaterialTheme.typography.titleMedium)
                            ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ModelChips(selected: ModelSize, ready: Set<ModelSize>, onSelect: (ModelSize) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ModelSize.values().forEach { m ->
            FilterChip(
                selected = selected == m,
                onClick = { onSelect(m) },
                label = { Text(m.labelFa + " — " + m.sizeMb + "MB" + if (m in ready) " ✓" else "") }
            )
        }
    }
}

private fun share(ctx: android.content.Context, uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری"))
}
