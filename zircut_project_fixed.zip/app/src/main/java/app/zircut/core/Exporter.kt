package app.zircut.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.math.min

@UnstableApi
class Exporter(private val ctx: Context) {
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    class Params(
        val uri: Uri,
        val info: VideoInfo,
        val ranges: List<Range>,
        val phrases: List<Phrase>,
        val style: SubStyle,
        val typeface: Typeface,
        val options: Options,
        val out: File
    )

    /** Must be called on the main thread. */
    fun start(p: Params, onProgress: (Float) -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {
        val opt = p.options
        val srcW = p.info.width
        val srcH = p.info.height

        // Output geometry
        var outW = srcW
        var outH = srcH
        if (opt.vertical) {
            if (srcW.toFloat() / srcH > 9f / 16f) {
                outH = srcH
                outW = srcH * 9 / 16
            } else {
                outW = srcW
                outH = srcW * 16 / 9
            }
        }
        val cap = if (opt.vertical) 1920 else 1080
        val targetH = min(outH, cap) and 1.inv()
        val targetW = (outW.toLong() * targetH / outH).toInt() and 1.inv()

        val items = p.ranges.mapIndexed { i, r ->
            val mi = MediaItem.Builder()
                .setUri(p.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(r.startMs)
                        .setEndPositionMs(r.endMs)
                        .build()
                ).build()
            val v = ArrayList<Effect>()
            if (opt.zoom && i % 2 == 1) {
                v.add(ScaleAndRotateTransformation.Builder().setScale(1.18f, 1.18f).build())
            }
            EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), v)).build()
        }

        val comp = ArrayList<Effect>()
        if (opt.vertical) {
            comp.add(Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        }
        comp.add(Presentation.createForHeight(targetH))
        if (opt.captions && p.phrases.isNotEmpty()) {
            val overlay = CaptionOverlay(
                CaptionTimeline(p.phrases, p.ranges),
                p.phrases,
                CaptionRenderer(targetW, targetH, p.style, p.typeface),
                p.style
            )
            comp.add(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
        }

        val composition = Composition.Builder(EditedMediaItemSequence(items))
            .setEffects(Effects(emptyList(), comp))
            .build()

        val bitrate = if (targetH >= 1500) 10_000_000 else 8_000_000
        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    polling = false
                    onDone()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    polling = false
                    onError(exportException.message ?: "خطا در ساخت ویدیو")
                }
            })
            .build()
        transformer = t
        t.start(composition, p.out.absolutePath)

        polling = true
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val tr = transformer ?: return
                if (tr.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress / 100f)
                }
                handler.postDelayed(this, 400)
            }
        })
    }

    fun cancel() {
        polling = false
        transformer?.cancel()
    }
}

@UnstableApi
private class CaptionOverlay(
    private val timeline: CaptionTimeline,
    private val phrases: List<Phrase>,
    private val renderer: CaptionRenderer,
    private val style: SubStyle
) : BitmapOverlay() {
    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private var lastKey = Long.MIN_VALUE
    private var lastBmp: Bitmap = blank

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val st = timeline.stateAt(presentationTimeUs / 1000)
        val key = if (st == null) -1L else st.phraseIdx * 1000L + st.wordIdx
        if (key != lastKey) {
            lastBmp = if (st == null) blank else renderer.render(phrases[st.phraseIdx], st.wordIdx)
            lastKey = key
        }
        return lastBmp
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val st = timeline.stateAt(presentationTimeUs / 1000)
        val s = if (style.pop && st != null) st.pop else 1f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, style.yAnchor)
            .setOverlayFrameAnchor(0f, 0f)
            .setScale(s, s)
            .build()
    }
}
