package app.zircut.core

import android.graphics.Color

data class Word(
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val cutBefore: Boolean = false
)

data class Phrase(val words: List<Word>) {
    val startMs: Long get() = words.first().startMs
    val endMs: Long get() = words.last().endMs
    val text: String get() = words.joinToString(" ") { it.text }
}

data class Range(val startMs: Long, val endMs: Long) {
    val len: Long get() = endMs - startMs
}

data class VideoInfo(val durationMs: Long, val width: Int, val height: Int)

data class Options(
    val captions: Boolean = true,
    val removeSilence: Boolean = true,
    val removeFillers: Boolean = true,
    val zoom: Boolean = true,
    val vertical: Boolean = true,
    val maxGapMs: Long = 500,
    val language: String = "fa"
)

data class SubStyle(
    val id: String,
    val nameFa: String,
    val textColor: Int,
    val highlightColor: Int,
    val box: Boolean,
    val boxColor: Int,
    val outline: Float,
    val sizeFrac: Float,
    val yAnchor: Float,
    val pop: Boolean
)

object Styles {
    val all = listOf(
        SubStyle("pop", "پاپ", Color.WHITE, Color.parseColor("#FFE600"), false, 0, 0.18f, 0.075f, -0.45f, true),
        SubStyle("minimal", "مینیمال", Color.WHITE, 0, false, 0, 0.12f, 0.060f, -0.55f, false),
        SubStyle("karaoke", "کارائوکه", Color.WHITE, Color.parseColor("#4C8DFF"), true, Color.parseColor("#B3101030"), 0f, 0.065f, -0.50f, false),
        SubStyle("box", "باکس", Color.WHITE, Color.parseColor("#FFE600"), true, Color.parseColor("#E69147FF"), 0f, 0.065f, -0.50f, true)
    )

    fun byId(id: String): SubStyle = all.firstOrNull { it.id == id } ?: all.first()
}

enum class ModelSize(val id: String, val labelFa: String, val file: String, val sizeMb: Int) {
    TINY("tiny", "سریع (ضعیف‌تر)", "ggml-tiny-q5_1.bin", 31),
    BASE("base", "متوسط", "ggml-base-q5_1.bin", 57),
    SMALL("small", "دقیق (کندتر، پیشنهادی)", "ggml-small-q5_1.bin", 181);

    val url: String
        get() = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"
}
