#include <jni.h>
#include <string>
#include <vector>
#include <cstring>
#include "whisper.h"

static std::string sanitize_utf8(const char *s) {
    std::string out;
    size_t n = strlen(s);
    size_t i = 0;
    while (i < n) {
        unsigned char c = (unsigned char) s[i];
        int len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : 0;
        if (len == 0 || i + len > n) { i++; continue; }
        bool ok = true;
        for (int k = 1; k < len; k++) {
            if (((unsigned char) s[i + k] & 0xC0) != 0x80) { ok = false; break; }
        }
        if (ok) { out.append(s + i, len); i += len; } else { i++; }
    }
    return out;
}

extern "C" {

JNIEXPORT jlong JNICALL
Java_app_zircut_core_WhisperBridge_loadModel(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    whisper_context *ctx = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_app_zircut_core_WhisperBridge_release(JNIEnv *, jobject, jlong ctxPtr) {
    if (ctxPtr != 0) whisper_free((whisper_context *) ctxPtr);
}

JNIEXPORT jobjectArray JNICALL
Java_app_zircut_core_WhisperBridge_transcribe(JNIEnv *env, jobject, jlong ctxPtr,
                                              jfloatArray audio, jstring lang, jint threads) {
    auto *ctx = (whisper_context *) ctxPtr;
    jsize n = env->GetArrayLength(audio);
    jfloat *data = env->GetFloatArrayElements(audio, nullptr);
    const char *l = env->GetStringUTFChars(lang, nullptr);
    std::string language(l);
    env->ReleaseStringUTFChars(lang, l);

    whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.language = language.c_str();
    wp.n_threads = threads;
    wp.translate = false;
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    wp.no_context = true;
    wp.suppress_blank = true;
    wp.token_timestamps = true;
    wp.max_len = 1;
    wp.split_on_word = true;

    int rc = whisper_full(ctx, wp, data, n);
    env->ReleaseFloatArrayElements(audio, data, JNI_ABORT);

    std::vector<std::string> rows;
    if (rc == 0) {
        int ns = whisper_full_n_segments(ctx);
        for (int i = 0; i < ns; i++) {
            int64_t t0 = whisper_full_get_segment_t0(ctx, i);
            int64_t t1 = whisper_full_get_segment_t1(ctx, i);
            const char *text = whisper_full_get_segment_text(ctx, i);
            rows.push_back(std::to_string(t0 * 10) + "\t" + std::to_string(t1 * 10) + "\t" +
                           sanitize_utf8(text));
        }
    }

    jclass sc = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray((jsize) rows.size(), sc, nullptr);
    for (size_t i = 0; i < rows.size(); i++) {
        jstring js = env->NewStringUTF(rows[i].c_str());
        env->SetObjectArrayElement(arr, (jsize) i, js);
        env->DeleteLocalRef(js);
    }
    return arr;
}

}
