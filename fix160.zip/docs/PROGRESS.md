# ZirCut — progress and hand-off notes

Android video editor (Kotlin, Jetpack Compose, Media3 Transformer). Built only through GitHub Actions
(workflow unpacks every `fix*.zip` in the repo root in version order, then builds). Persian (RTL) first.

Target: a CapCut-class editor, delivered in 8 parts. Every part is a full project snapshot zip (fix110, fix120, ...).

## Parts

| # | Part | Status |
|---|------|--------|
| 1 | Projects + library (save, thumbnails, autosave, continue editing) | DONE (needs build verification) |
| 2 | Clip editing on the timeline of the main video (split, trim, delete, duplicate, reorder, undo/redo) | DONE (needs build verification) |
| 3 | Extra videos/photos as clips + multi-source preview and export | DONE (needs build verification) |
| 4 | Image and text layers (position, scale, rotation, opacity, time) | DONE (needs build verification) |
| 5 | Audio (music/voice tracks, waveform, volume, fades, recording) | IMPLEMENTED in fix150 (build and phone test pending) |
| 6 | Effects (GPU), transitions, color grading page | not started |
| 7 | Advanced export (resolution, fps, bitrate, codec, device capability check) | not started |
| 8 | AI tools that are really feasible (scene detect, silence, SRT import/export) + cleanup | not started |

Out of scope for these 8 parts (heavy models / separate engine): background removal, subject tracking,
advanced masks, full keyframe system. Do not fake them in the UI.

## Part 1 — what exists now

Done and wired to real logic:
- `project/Project.kt`: `ProjectStore` (filesDir/projects/<id>/ media.mp4, thumb.jpg, meta.json, project.json),
  create / save / load / list / rename / delete / duplicate. JSON via org.json. Original video is moved into the
  project folder (never modified).
- `MainViewModel`: every picked video becomes a project (`pickVideo`); `openProject`, `renameProject`,
  `duplicateProject`, `deleteProject`; autosave 500 ms after any edit (`autosave` / `persist`);
  `UiState` has `projectId`, `projectName`, `projects`, `saveStatus`.
- Home = library: new project, continue editing, 2-column project grid with thumbnails, ratio, age, search,
  per-project menu (rename / duplicate / delete), list of exported videos.
- New-project sheet: language + auto-edit options, then video picker.
- Editor top bar shows project name (tap to rename) and save status.
- Timeline ruler label no longer hidden under the playhead.

Not done in part 1 (deliberately later): templates, media browser, project settings screen, project recovery UI,
undo/redo (part 2), multiple media per project (part 2).

## Part 2 — what exists now

- `timeline/Edl.kt`: `EdlMap` (clips laid end to end; out-time <-> source-time), `EdlOps` (split, trimStart, trimEnd,
  delete, duplicate, moveEarlier, moveLater -> `EdlResult(segs, playhead)`), `outPhrasesOf` (subtitles on the edited timeline).
- `UiState.segments: List<Range>?` = manual clip list (null = automatic silence cut from `Planner.ranges`).
  First edit bakes the current automatic cut into manual clips. Saved in project.json ("segments").
  `MainViewModel.setSegments / undo / redo` (60 steps; history is only for clip edits, not subtitle text).
  `export()` uses the manual clips; the Exporter already accepts any ordered list of source ranges.
- Editor: playhead (`posMs`) is now on the EDITED timeline. Timeline draws clips end to end (current clip highlighted),
  subtitle blocks at their edited position. New dock tab "کلیپ" with the clip tools (work on the clip under the playhead).
  Preview playback walks the clip list (jumps between clips, supports duplicates and reordering).
  Undo/redo buttons in the top bar. App settings moved to the "ادیت" tab.
- Subtitle sync: `CaptionTimeline(phrases, ranges)` is used for preview exactly like export.

Not done in part 2: drag-to-trim handles and drag-and-drop reordering (use the tool buttons), ripple behaviours,
more than one source video (part 3), multiple tracks (parts 3-5), undo for subtitle edits.
A phrase that is played twice (duplicated clip) is drawn once on the timeline (first play).

## Part 3 — what exists now

- Extra media: "افزودن ویدیو یا عکس در پلی‌هد" in the clip tab. The picked file is copied into the project folder
  (`extra_<id>.mp4/jpg/png/webp`), stored in project.json ("extras") and inserted as a clip at the playhead
  (`EdlOps.insertAt`: before/after the clip under the playhead, or the clip is split). Photos get 5 s by default
  (can be shortened with the clip tools, cannot be lengthened yet).
- Source tagging: a clip's Range encodes its source (`timeline/Edl.kt` object `Src`: source 0 = main video,
  k >= 1 = extra k, time = k * 10^10 + ms). All clip tools/undo/redo/persistence work unchanged on mixed clips.
- Subtitles exist only for the main video. `captionRanges()` gives other clips impossible source times so no subtitle
  is shown over them.
- Preview: `ui/PreviewPlayer.kt` (one MediaPlayer that switches files; ~0.2 s pause when switching between files),
  photos are shown as an image and timed by wall clock. The preview frame keeps the output shape; each clip is
  cropped to fill it, like the exporter does.
- Export: `Exporter.Params` has `sources` (per-clip uri + isImage) and `captionRanges`. When media are mixed every
  clip is scaled/cropped to the output size (`Presentation.createForWidthAndHeight`). Photo clips are
  `EditedMediaItem` with duration + 30 fps; audio gaps are filled by calling `experimentalSetForceAudioTrack`
  through reflection (if that method is missing on the Media3 version, photos stay silent and audio may be dropped
  for the whole export — check first on a real device).
- Timeline: photo clips are grey, video clips blue, labelled "عکس N" / "ویدیو N".

Not done in part 3: transcribing extra videos (no subtitles on them), photo EXIF rotation, lengthening photos,
removing unused extra files from the project folder, per-clip volume/speed, multiple video tracks/overlays
(parts 4-6).

## Part 4 — what exists now

- `timeline/Layers.kt`: `Layer` (text or picture: start/end on the EDITED timeline, centre x/y as fractions of the frame,
  scale, rotation in degrees clockwise, opacity, text/colour/background/stroke/font, or picture file) and `LayerOps`
  (timeline rows, split, move up/down, unique ids). `UiState.layers` + `selectedLayer` (selection is not saved).
  Saved in project.json ("layers"). Picture files are copied into the project folder (`layer_<time>.png|jpg`, max 2000 px,
  EXIF-rotated; photos become JPEG, pictures with transparency stay PNG).
- `core/LayerRenderer.kt`: ONE renderer for preview and export (sizes are fractions of the frame's short side).
  A layer is drawn at min(scale, 2)x and shown at scale / that, so big text stays sharp. `LayerBitmapCache` for the preview.
- Editor: new dock tab "لایه" (the dock now scrolls sideways). Panel: add text / add picture, layer chips, text field, text colour,
  background box, dark outline, font, size, rotation, opacity, X, Y, start time, duration, "start here", "end here", split,
  copy, move up/down (drawing order), go to layer, delete. On the preview: one finger moves the selected layer, two fingers
  resize and turn it. Timeline: layers under the subtitle track (up to 3 rows; more overlapping layers share the last row),
  tap to select.
- History: undo/redo now covers clip edits AND layer edits (`Snap(segs, layers)`). Slider drags, typing and finger gestures
  on the same layer within 0.9 s are one undo step (`MainViewModel.editLayer`).
- Export: `Exporter.Params.layers/projectDir/layerFont`. Each layer is a Media3 `BitmapOverlay` (`LayerOverlay`), rotation baked
  into the bitmap, position/scale/opacity through `OverlaySettings`; only clips that overlap the layer's time get the overlay.
  Layers are drawn under the subtitles. Same time handling as the caption overlay (relative or absolute frame times).

Not done in part 4: drag-to-move/trim layers on the timeline (use the sliders and buttons), keyframes/animation, fade in/out,
text styles beyond colour/background/outline, bold/italic, per-letter effects, layer lock/hide, unused picture files are
not removed from the project folder, layer times do not follow clip edits (a layer keeps its place on the timeline even if
clips before it are cut), no layers over the timeline end (they simply are not shown).
Risk (still open, fix140 phone test not confirmed): `OverlaySettings` / multiple overlays in one `OverlayEffect` were written from memory of Media3 1.4.1 (same calls the
caption overlay already uses); first thing to test on the phone is export with a text layer and a picture layer.

## Part 5 — what exists now (fix150, NOT yet built or tested)

Written without a compiler (no Gradle/Kotlin in the authoring environment); the first GitHub Actions run decides whether it builds.
Media3 1.4.1 sources were checked for: `Composition.Builder(seq, vararg seq)`, `EditedMediaItem.Builder.setRemoveAudio`,
`Composition.Builder.experimentalSetForceAudioTrack` (EXISTS in 1.4.1, so the old reflection call is valid). Media3 1.4.1 has NO audio-gap
API, so the export builds the whole sound track itself.

New files
- `timeline/Audio.kt`: `AudioClip` (kind music/voice, file in project folder, start on edited timeline, in-point, length, file length,
  volume 0..1, fade in/out, mute) and `AudioOps` (`gainAt` = ONE volume/fade function used by preview and export, rows, fit, split).
- `core/PcmDecoder.kt`: any audio / video sound -> 44.1 kHz stereo 16-bit, streamed in blocks (MediaCodec, linear resampler;
  plain 16-bit WAV is read directly). `durationMs`, `hasAudio`.
- `core/AudioMixer.kt`: every video clip's sound (laid end to end on the edited timeline) + all music/voice clips -> ONE stereo WAV
  (sources decoded to temp files, mixed block by block, soft clip above 0.95). Photos/clips without audio = silence.
- `core/Waveform.kt`: real peaks (one byte per 20 ms) from the decoded file, stored as `<audiofile>.pk` in the project folder.
- `core/VoiceRecorder.kt`: AudioRecord mono 44.1 kHz -> WAV, always releases the microphone (`stop` / `cancel`).
- `ui/AudioPreview.kt`: one MediaPlayer per audible clip (created ~1.5 s before, released after), drift correction, per-moment volume.

Changed files
- `project/Project.kt`: `ProjectData.audio / mainVolume / mainMuted`, saved in project.json ("audio", "mainVol", "mainMute").
- `MainViewModel.kt`: `UiState.audio / selectedAudio / mainVolume / mainMuted / waves`; `importAudio`, `addRecording`, `editAudio`,
  `deleteAudio`, `duplicateAudio`, `splitAudio`, `setMainVolume`, `setMainMuted`, `showMessage`; undo/redo snapshot now also holds audio
  and main volume; `export()` mixes the sound first ("در حال میکس صدا…") when there are audio clips or the main volume is not 100 %.
  With no audio edits the OLD export path is used unchanged (clips keep their own sound).
- `core/Exporter.kt`: `Params.mixAudio`; with it, video clips get `setRemoveAudio(true)` and the WAV is a second audio-only sequence.
- `ui/PreviewPlayer.kt`: `setVolume`. `ui/Editor.kt`: dock tab "صدا" (`AudioPanel`), audio rows with waveform + fade corners under the
  layer rows on the timeline, recording (permission request, video plays while recording, pause/end stops the take).
- `ui/ZirCutApp.kt` (audio file picker), `ui/Theme.kt` (icons Music, Mic), `AndroidManifest.xml` (RECORD_AUDIO).

Known limits of part 5 (do not report as done)
- Volume is capped at 100 % (MediaPlayer cannot boost; the export matches the preview).
- No drag-to-move/trim of audio on the timeline (sliders and buttons only). Audio keeps its time when video clips are cut/moved.
- No waveform for the video's own sound. Only fades are linear. No ducking, no noise reduction, no per-clip speed/pitch.
- Preview starts a clip a fraction of a second late when playback starts inside it (player must prepare first).
- Recording in the background (app minimised) is not handled; headphones advised because the video plays while recording.
- Unused audio/recording/.pk files are not deleted (part 8). Mixing needs temp disk of about 10 MB per minute per source.
- Export of two sequences (silent video + WAV) is new in this build: must be tested on the phone, also with photo clips and zoom.

To test on the phone: import a song, check waveform and playback; change volume/fades; record a voice-over with headphones;
undo/redo each; export and listen (volumes, fades, position, original sound muted/lowered); export without any audio edit (old path);
reopen the project (clips and waveforms come back).

## Part 6 — step A (fix160, NOT yet built or tested)

fix150/fix151: build succeeded (after two small fixes); phone test of audio still pending.

Done in this step (only things that look the same in preview and export, and need no new GPU code):
- `core/ColorGrade.kt`: new grade controls Exposure (stops), Whites, Blacks, Hue rotation. All are affine, so they go through the
  same matrix as before (preview ColorMatrix = export RgbMatrix). Saved in project.json (old projects load with defaults).
- `core/Fx.kt` + `Exporter.kt` + `Editor.kt`: whole-video effects Vignette, Film grain (4 moving frames), Cinema bars, Light leak.
  They are pictures drawn over the video (Media3 BitmapOverlay in the export, Canvas in the preview) from the SAME bitmaps
  (`FxRender.build`). Media3 sizes an overlay by its pixels, so the export scales them to the output size (verified in
  OverlayMatrixProvider 1.4.1). Saved in project.json ("fx"). Panel: tab «فیلتر» (sliders under the color controls).

NOT done yet in part 6 (do not report as done): Blur / Gaussian blur, Sharpen, RGB split, Glitch, Noise, Glow (bloom), Highlights /
Shadows, per-color HSL, LUT, all transitions (Fade/Dissolve/Zoom/Slide/Blur/Spin/Glitch), effects per clip (current ones are global).
Reason: they need custom GPU shaders (BaseGlShaderProgram) and, for transitions, two clips drawn together. Media3 1.4.1 has no
built-in transitions or blur effect. Next step (B) will add a custom shader effect, tested first with one effect (Sharpen/RGB split)
before the rest.

Test on the phone: tab فیلتر: move Exposure / Whites / Blacks / Hue; each effect slider; compare preview and exported video;
check that old projects still open and that export with no effects looks like before.

## Design system (ui/Theme.kt, ui/Components.kt)

Tokens in `object Z` (colors, spacing 4pt, radii), `ZType` (Estedad variable font, per-weight Typeface),
Canvas-drawn icons `ZI`, controls `ZButton ZIconButton ZChip ZSegmented ZSwitch ZSlider ZCard ZField
ZSearchField ZToggleRow ZStat`. One accent (sky blue). Use `Txt(...)` for all text, `Modifier.press` for taps.
Persian digits: `fa(...)`, `faTime(ms)`.

## Known rules for whoever continues

- Cannot compile locally; keep each part small and re-check Kotlin signatures against the real source.
- Trailing lambda binds to the LAST parameter: put `onClick/onChange` last in composables.
- Do not remove existing working features (auto subtitles, silence cut, zoom, color look, export).
- Core engine files live in `core/` (Exporter, Planner, CaptionRenderer, ...). UI in `ui/`. Projects in `project/`.
