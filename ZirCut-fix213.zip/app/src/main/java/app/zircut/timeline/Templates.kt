package app.zircut.timeline

import app.zircut.core.ColorGrade

/** The title text a template puts on the video (position, entrance animation and one of the ready text styles by name). */
class TemplateTitle(val text: String, val y: Float, val animIn: Int, val styleName: String, val scale: Float = 1f)

/**
 * A ready-made video recipe: frame shape, subtitle style, colour look (with strength) and a title.
 * Applying one is a handful of normal edits done in one step; nothing is hidden: every part can be changed afterwards.
 */
class VideoTemplate(
    val id: String,
    val name: String,
    val note: String,
    /** frame ratio id as in Frame (9:16, 16:9, 1:1, 4:5, orig) or "c:2.35" */
    val ratio: String,
    val styleId: String,
    val lookId: String,
    val lookStrength: Float,
    val title: TemplateTitle
)

object VideoTemplates {
    val all = listOf(
        VideoTemplate("reels", "ریلز و شورتس", "عمودی ۹:۱۶ · زیرنویس ضربتی · رنگ زنده", "9:16", "zarbati", "vivid", 0.6f,
            TemplateTitle("عنوان ویدیو", 0.18f, 3, "تیتر زرد")),
        VideoTemplate("youtube", "یوتیوب", "افقی ۱۶:۹ · زیرنویس کادر · نام پایین تصویر", "16:9", "box", "none", 1f,
            TemplateTitle("نام شما", 0.84f, 4, "جعبه تیره", 0.8f)),
        VideoTemplate("cinema", "سینمایی", "عریض ۲٫۳۵ · رنگ سینمایی · عنوان وسط", "c:2.35", "cinema", "cinema", 1f,
            TemplateTitle("عنوان فیلم", 0.5f, 1, "ساده", 1.2f)),
        VideoTemplate("square", "پست مربعی", "۱:۱ · زیرنویس تمیز · رنگ ملایم", "1:1", "clean", "soft", 0.8f,
            TemplateTitle("عنوان پست", 0.16f, 6, "تیتر زرد")),
        VideoTemplate("portrait", "پست ۴:۵", "۴:۵ · هایلایت · رنگ گرم", "4:5", "highlight", "warm", 0.7f,
            TemplateTitle("عنوان پست", 0.15f, 2, "برچسب قرمز", 0.9f))
    )

    fun byId(id: String): VideoTemplate? = all.firstOrNull { it.id == id }

    fun grade(t: VideoTemplate, cur: ColorGrade): ColorGrade = cur.copy(lookId = t.lookId, strength = t.lookStrength)
}
