package app.zircut.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.zircut.Recent
import app.zircut.UiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Surface1 = Color(0xFF15151F)
private val Surface2 = Color(0xFF1E1E2C)
private val Accent = Color(0xFF8B5CFF)
private val Muted = Color(0xFF9A9AB0)

@Composable
fun HomeScreen(
    ui: UiState,
    modifier: Modifier,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (Recent) -> Unit,
    onDelete: (Recent) -> Unit
) {
    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("زیرکات", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("ادیت خودکار ویدیو", color = Muted, fontSize = 13.sp)
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(Surface2)
                        .clickable(onClick = onSettings).padding(horizontal = 16.dp, vertical = 9.dp)
                ) { Text("تنظیمات", color = Color.White, fontSize = 14.sp) }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Accent)
                    .clickable(onClick = onNew).padding(horizontal = 20.dp, vertical = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                PlusBadge()
                Column {
                    Text("ویدیو جدید", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("اول ویدیو باز می‌شه؛ هر ابزاری خواستی از پایین بزن", color = Color(0xFFEDE3FF), fontSize = 13.sp)
                }
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Feature(Modifier.weight(1f), "✨", "زیرنویس خودکار")
                Feature(Modifier.weight(1f), "🎞️", "فیلتر و رنگ")
                Feature(Modifier.weight(1f), "✂️", "برش و سرعت")
            }
        }

        item { SectionTitle("پروژه‌های اخیر") }
        if (ui.recent.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface1).padding(18.dp)) {
                    Text("هنوز پروژه‌ای نداری. بعد از اولین خروجی، اینجا می‌بینیش.", color = Muted, fontSize = 14.sp)
                }
            }
        } else {
            items(ui.recent, key = { it.uri }) { r ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface1)
                        .clickable { onOpen(r) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Thumb(r.uri, Modifier.size(width = 60.dp, height = 82.dp).clip(RoundedCornerShape(12.dp)))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Text(ago(r.time), color = Muted, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Surface2)
                            .clickable { onDelete(r) }.padding(horizontal = 12.dp, vertical = 7.dp)
                    ) { Text("حذف", color = Color(0xFFFF9C9C), fontSize = 12.sp) }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun PlusBadge() {
    Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(22.dp)) {
            val w = size.width
            drawLine(Color.White, Offset(w / 2f, 2f), Offset(w / 2f, w - 2f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(Color.White, Offset(2f, w / 2f), Offset(w - 2f, w / 2f), strokeWidth = 4f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun Feature(modifier: Modifier, icon: String, label: String) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Surface1).padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 20.sp)
        Text(label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Thumb(uri: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, Uri.parse(uri))
                val b = r.getFrameAtTime(500_000L)
                r.release()
                b
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.background(Surface2)) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        }
    }
}

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000L
    return when {
        m < 1L -> "همین الان"
        m < 60L -> "$m دقیقه پیش"
        m < 1440L -> "${m / 60L} ساعت پیش"
        else -> "${m / 1440L} روز پیش"
    }
}
