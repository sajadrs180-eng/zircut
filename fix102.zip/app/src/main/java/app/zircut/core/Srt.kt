package app.zircut.core

/** Builds SubRip (.srt) text from phrases. Times are in the ORIGINAL video's timeline. */
object Srt {
    fun time(ms: Long): String {
        val t = if (ms < 0) 0L else ms
        return "%02d:%02d:%02d,%03d".format(t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000)
    }

    fun build(phrases: List<Phrase>): String {
        val sb = StringBuilder()
        var n = 0
        for (p in phrases) {
            if (p.words.isEmpty()) continue
            val text = p.text.replace("*", "").trim()
            if (text.isEmpty()) continue
            n++
            sb.append(n).append('\n')
                .append(time(p.startMs)).append(" --> ").append(time(maxOf(p.endMs, p.startMs + 200))).append('\n')
                .append(text).append("\n\n")
        }
        return sb.toString()
    }
}
