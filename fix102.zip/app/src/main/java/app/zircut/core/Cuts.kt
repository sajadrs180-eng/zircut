package app.zircut.core

/** User edits that never touch the original file: split points and deleted source segments (source-time ms). */
data class EditState(val splits: List<Long> = emptyList(), val cuts: List<Range> = emptyList())

object Cuts {
    private const val MIN_PIECE = 200L
    private const val MIN_SPLIT_GAP = 300L

    /** [ranges] minus [cuts]; pieces shorter than 200 ms are dropped. */
    fun subtract(ranges: List<Range>, cuts: List<Range>): List<Range> {
        if (cuts.isEmpty()) return ranges
        val out = ArrayList<Range>()
        for (r in ranges) {
            var pieces = listOf(r)
            for (c in cuts) {
                val next = ArrayList<Range>()
                for (p in pieces) {
                    if (c.endMs <= p.startMs || c.startMs >= p.endMs) { next.add(p); continue }
                    if (c.startMs > p.startMs) next.add(Range(p.startMs, c.startMs))
                    if (c.endMs < p.endMs) next.add(Range(c.endMs, p.endMs))
                }
                pieces = next
            }
            out.addAll(pieces.filter { it.len >= MIN_PIECE })
        }
        return out
    }

    fun apply(base: List<Range>, e: EditState): List<Range> = subtract(base, e.cuts)

    /** The piece of the video between two split points that contains [pos]. */
    fun segmentAt(splits: List<Long>, total: Long, pos: Long): Range {
        val s = splits.filter { it <= pos }.maxOrNull() ?: 0L
        val e = splits.filter { it > pos }.minOrNull() ?: total
        return Range(s, e)
    }

    fun addSplit(e: EditState, pos: Long, total: Long): EditState? {
        if (pos < MIN_SPLIT_GAP || pos > total - MIN_SPLIT_GAP) return null
        if (e.splits.any { kotlin.math.abs(it - pos) < MIN_SPLIT_GAP }) return null
        return e.copy(splits = (e.splits + pos).sorted())
    }

    /** Deletes the piece under [pos]; refuses if less than half a second would remain. */
    fun deleteAt(e: EditState, pos: Long, total: Long, base: List<Range>): EditState? {
        val seg = segmentAt(e.splits, total, pos)
        val next = e.copy(cuts = e.cuts + seg)
        val left = apply(base, next).sumOf { it.len }
        return if (left < 500L) null else next
    }
}
