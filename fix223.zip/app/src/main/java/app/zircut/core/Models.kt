package app.zircut.core

import android.graphics.Color

data class Word(
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val cutBefore: Boolean = false,
    val conf: Float = 1f
)

data class Phrase(val words: List<Word>) {
    val startMs: Long get() = words.first().startMs
    val endMs: Long get() = words.last().endMs
    val text: String get() = words.joinToString(" ") { it.text }
}

/** A piece [startMs, endMs) of a source. [len] is its SOURCE length; [outLen] is how long it lasts on the edited timeline (source length / [speed]). */
data class Range(
    val startMs: Long,
    val endMs: Long,
    val speed: Float = 1f,
    /** transition at the cut BEFORE this clip: -1 = the project's transition, otherwise the ordinal of a [TrKind] (0 = none) */
    val tr: Int = -1,
    /** length of that transition in ms, 0 = the project's */
    val trMs: Long = 0L
) {
    val len: Long get() = endMs - startMs
    val outLen: Long get() = if (speed == 1f) len else Math.round(len / speed.toDouble())
}

data class VideoInfo(val durationMs: Long, val width: Int, val height: Int)

data class Options(
    val captions: Boolean = true,
    val removeSilence: Boolean = true,
    val removeFillers: Boolean = true,
    val zoom: Boolean = true,
    val vertical: Boolean = true,
    /** output frame shape: "" = follow [vertical] (old projects), "9:16", "16:9", "1:1", "4:5" or "orig" (the video's own shape) */
    val ratio: String = "",
    val maxGapMs: Long = 500,
    val language: String = "fa"
)

data class SubStyle(
    val id: String,
    val nameFa: String,
    val textColor: Int,
    val highlightColor: Int,
    val box: Boolean,
    val boxColor: Int,
    val outline: Float,
    val sizeFrac: Float,
    val pop: Boolean,
    val fade: Boolean = false,
    val hlBox: Int = 0,
    val glow: Int = 0,
    val font: String = "Vazirmatn-ExtraBold",
    val fontScale: Float = 1f
)

data class CapLayout(
    val x: Float = 0.5f,
    val y: Float = 0.66f,
    val mw: Float = 0.9f,
    val ls: Float = 1.5f,
    val lw: Int = 4,
    val size: Float = 1f
)

object Styles {
    private fun c(h: String) = Color.parseColor(h)

    val all = listOf(
        SubStyle("zarbati", "ضربتی", Color.WHITE, c("#FFD83A"), false, 0, 4f, 0.078f, true, font = "Lalezar-Regular", fontScale = 1.12f),
        SubStyle("clean", "تمیز", Color.WHITE, Color.WHITE, false, 0, 2f, 0.070f, false, fade = true),
        SubStyle("box", "کادر", Color.WHITE, Color.WHITE, true, c("#CC000000"), 0f, 0.066f, false),
        SubStyle("highlight", "هایلایت", Color.WHITE, Color.WHITE, false, 0, 2f, 0.068f, false, hlBox = c("#FFD83A"), font = "Cairo", fontScale = 0.96f),
        SubStyle("vlog", "ویلاگ", Color.WHITE, c("#5CF2C0"), false, 0, 3f, 0.072f, true, font = "Changa"),
        SubStyle("news", "خبری", Color.WHITE, Color.WHITE, true, c("#DD111111"), 0f, 0.062f, false, font = "Vazirmatn-Bold"),
        SubStyle("neon", "نئون", c("#EFE9FF"), c("#C4A8FF"), false, 0, 0f, 0.070f, false, fade = true, glow = c("#8B5CFF"), font = "Cairo", fontScale = 0.96f),
        SubStyle("cinema", "سینمایی", c("#F2F2F2"), Color.WHITE, false, 0, 1.5f, 0.060f, false, fade = true, font = "Vazirmatn-Regular"),
        SubStyle("estedad", "استعداد", Color.WHITE, c("#FFD83A"), false, 0, 3.5f, 0.072f, true, font = "Estedad"),
        SubStyle("sahel", "ساحل", Color.WHITE, c("#5CF2C0"), false, 0, 3.5f, 0.070f, false, fade = true, font = "Sahel-Black"),
        SubStyle("mikhak", "میخک", Color.WHITE, c("#FF8AD8"), false, 0, 3f, 0.072f, true, font = "Mikhak-Black")
    )

    fun byId(id: String): SubStyle = all.firstOrNull { it.id == id } ?: all.first()
}

enum class ModelSize(val id: String, val labelFa: String, val file: String, val sizeMb: Int) {
    TINY("tiny", "سریع (ضعیف‌تر)", "ggml-tiny-q5_1.bin", 31),
    BASE("base", "متوسط", "ggml-base-q5_1.bin", 57),
    SMALL("small", "دقیق (کندتر)", "ggml-small-q5_1.bin", 181),
    TURBO("turbo", "بهترین دقت (۵۷۰ مگابایت، خیلی کندتر)", "ggml-large-v3-turbo-q5_0.bin", 574),
    LARGE("large", "حداکثر دقت (۱ گیگابایت، بسیار کند)", "ggml-large-v3-q5_0.bin", 1080);

    val beam: Int
        get() = when (this) {
            TINY -> 1
            BASE, SMALL -> 2
            TURBO -> 3
            LARGE -> 5
        }

    val url: String
        get() = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"
}

/** Output frame shape: ONE place used by the preview, the export sheet and the exporter. */
object Frame {
    val IDS = listOf("9:16", "16:9", "1:1", "4:5", "orig")

    /** free (custom) ratio: stored as "c:<width/height>", for example "c:1.333" */
    const val CUSTOM = "c:"
    const val MIN_FREE = 0.4f
    const val MAX_FREE = 2.5f

    fun customId(a: Float): String = CUSTOM + "%.2f".format(java.util.Locale.US, a.coerceIn(MIN_FREE, MAX_FREE))

    private fun customValue(r: String): Float? =
        if (r.startsWith(CUSTOM)) r.substring(2).toFloatOrNull()?.coerceIn(MIN_FREE, MAX_FREE) else null

    /** the number behind a custom ratio, or null when the ratio is a fixed one */
    fun free(o: Options): Float? = customValue(o.ratio)

    fun id(o: Options): String = if (o.ratio in IDS || customValue(o.ratio) != null) o.ratio else if (o.vertical) "9:16" else "orig"

    /** width / height of the output frame, 0 = the shape of the video itself */
    fun aspect(o: Options): Float = customValue(o.ratio) ?: when (id(o)) {
        "9:16" -> 9f / 16f
        "16:9" -> 16f / 9f
        "1:1" -> 1f
        "4:5" -> 4f / 5f
        else -> 0f
    }

    fun label(o: Options): String = free(o)?.let { "آزاد " + fa("%.2f".format(java.util.Locale.US, it)) }
        ?: if (id(o) == "orig") "اندازه اصلی" else fa(id(o))

    private fun fa(s: String): String = s.map { c -> if (c in '0'..'9') ('\u06F0' + (c - '0')) else c }.joinToString("")

    /** biggest frame of this shape that fits inside the source (the rest is cropped, centred) */
    fun crop(aspect: Float, srcW: Int, srcH: Int): Pair<Int, Int> {
        if (aspect <= 0f || srcW <= 0 || srcH <= 0) return srcW to srcH
        return if (srcW.toFloat() / srcH > aspect) {
            Math.round(srcH * aspect) to srcH
        } else {
            srcW to Math.round(srcW / aspect)
        }
    }
}
