package app.zircut.timeline

/**
 * One piece of extra audio on the edited timeline (part 5): imported music/sound or a recorded voice-over.
 * The file lives inside the project folder. [startMs] is the position on the EDITED timeline (same time line as the
 * playhead), [inMs] is where inside the file playback begins, [lenMs] is how long it plays.
 * The original sound of the video is not a clip: it has its own volume/mute in the project (see UiState.mainVolume).
 */
data class AudioClip(
    val id: Int,
    val kind: Int,
    val file: String,
    val name: String,
    val startMs: Long,
    val inMs: Long,
    val lenMs: Long,
    /** total length of the file */
    val fileMs: Long,
    /** 0..1 (the phone's player cannot go above 100 % in the preview, so the export does not either) */
    val volume: Float = 1f,
    val fadeInMs: Long = 0L,
    val fadeOutMs: Long = 0L,
    val muted: Boolean = false
) {
    val endMs: Long get() = startMs + lenMs
    val isVoice: Boolean get() = kind == KIND_VOICE
    fun activeAt(ms: Long): Boolean = ms >= startMs && ms < endMs

    companion object {
        const val KIND_MUSIC = 0
        const val KIND_VOICE = 1
        const val MIN_MS = 200L
    }
}

object AudioOps {
    /** the timeline shows at most this many rows of audio; more overlapping clips share the last row */
    const val MAX_ROWS = 3

    fun nextId(clips: List<AudioClip>): Int = (clips.maxOfOrNull { it.id } ?: 0) + 1

    /**
     * Volume of a clip [tMs] milliseconds after its own start, fades included.
     * The preview and the export mixer both use this one function, so they sound the same.
     */
    fun gainAt(c: AudioClip, tMs: Double): Float {
        if (c.muted) return 0f
        var g = c.volume.coerceIn(0f, 1f)
        if (c.fadeInMs > 0L && tMs < c.fadeInMs) g *= (tMs / c.fadeInMs).coerceIn(0.0, 1.0).toFloat()
        val left = c.lenMs - tMs
        if (c.fadeOutMs > 0L && left < c.fadeOutMs) g *= (left / c.fadeOutMs).coerceIn(0.0, 1.0).toFloat()
        return g
    }

    /** Row of every clip on the timeline: clips that overlap in time go to different rows. */
    fun rows(clips: List<AudioClip>): IntArray {
        val order = clips.indices.sortedBy { clips[it].startMs }
        val rowEnd = ArrayList<Long>()
        val res = IntArray(clips.size)
        for (i in order) {
            val c = clips[i]
            var r = rowEnd.indexOfFirst { it <= c.startMs }
            if (r < 0) {
                rowEnd.add(c.endMs)
                r = rowEnd.size - 1
            } else {
                rowEnd[r] = c.endMs
            }
            res[i] = minOf(r, MAX_ROWS - 1)
        }
        return res
    }

    fun rowCount(rows: IntArray): Int {
        if (rows.isEmpty()) return 0
        var m = 0
        for (r in rows) if (r > m) m = r
        return m + 1
    }

    /** Keeps a clip inside its file: it cannot start before 0 or play past the end of the file. */
    fun fit(c: AudioClip): AudioClip {
        val inMs = c.inMs.coerceIn(0L, maxOf(0L, c.fileMs - AudioClip.MIN_MS))
        val len = c.lenMs.coerceIn(AudioClip.MIN_MS, maxOf(AudioClip.MIN_MS, c.fileMs - inMs))
        val fi = c.fadeInMs.coerceIn(0L, len)
        val fo = c.fadeOutMs.coerceIn(0L, len)
        return c.copy(startMs = maxOf(0L, c.startMs), inMs = inMs, lenMs = len, fadeInMs = fi, fadeOutMs = fo)
    }

    /** Cuts one clip into two at [at] (position on the edited timeline). Null when a piece would be too short. */
    fun split(clips: List<AudioClip>, id: Int, at: Long): List<AudioClip>? {
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return null
        val c = clips[i]
        if (at - c.startMs < AudioClip.MIN_MS || c.endMs - at < AudioClip.MIN_MS) return null
        val cut = at - c.startMs
        val left = c.copy(lenMs = cut, fadeOutMs = 0L)
        val right = c.copy(
            id = nextId(clips), startMs = at, inMs = c.inMs + cut, lenMs = c.lenMs - cut, fadeInMs = 0L
        )
        val n = ArrayList(clips)
        n[i] = fit(left)
        n.add(i + 1, fit(right))
        return n
    }
}
