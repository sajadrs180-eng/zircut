package app.zircut.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import app.zircut.timeline.Layer
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Draws a text or picture layer into a bitmap. The preview (frame 540 px wide) and the export (frame 1080 px wide or more)
 * both use this, so a layer looks the same in both: sizes are fractions of the frame's short side.
 * The bitmap is drawn at [bs] times its natural size and shown at layer.scale / bs, which keeps big layers sharp.
 */
object LayerRenderer {
    /** the resolution a layer is drawn at: its own scale, but never more than 2x (memory) and never less than 0.25x */
    fun bakeScale(scale: Float): Float = ((min(scale, 2f) * 4f).roundToInt() / 4f).coerceAtLeast(0.25f)

    /** Unrotated bitmap of the layer, or null when there is nothing to draw (empty text, missing picture). */
    fun base(l: Layer, frameW: Int, frameH: Int, tf: Typeface, dir: File?, bs: Float): Bitmap? =
        try {
            if (l.isText) text(l, frameW, frameH, tf, bs) else image(l, frameW, frameH, dir, bs)
        } catch (_: Throwable) {
            null
        }

    /** The same bitmap turned by [deg] degrees clockwise on a bigger transparent canvas (used by the exporter). */
    fun bakeRotation(src: Bitmap, deg: Float): Bitmap {
        if (abs(deg) < 0.01f) return src
        val rad = Math.toRadians(deg.toDouble())
        val c = abs(cos(rad))
        val s = abs(sin(rad))
        val nw = ceil(src.width * c + src.height * s).toInt().coerceAtLeast(2)
        val nh = ceil(src.width * s + src.height * c).toInt().coerceAtLeast(2)
        val out = Bitmap.createBitmap(nw, nh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.translate(nw / 2f, nh / 2f)
        cv.rotate(deg)
        cv.drawBitmap(src, -src.width / 2f, -src.height / 2f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun makeLayout(t: CharSequence, paint: TextPaint, w: Int): StaticLayout =
        StaticLayout.Builder.obtain(t, 0, t.length, paint, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.ANYRTL_LTR)
            .setLineSpacing(0f, 1.2f)
            .build()

    private fun text(l: Layer, fw: Int, fh: Int, tf: Typeface, bs: Float): Bitmap? {
        val t = l.text.trim()
        if (t.isEmpty()) return null
        val unit = min(fw, fh).toFloat()
        val size = unit * 0.075f * bs
        val maxW = (fw * 0.84f * bs).toInt().coerceAtLeast(40)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = tf
            textSize = size
            color = l.color
        }
        val probe = makeLayout(t, paint, maxW)
        var lineMax = 0f
        for (i in 0 until probe.lineCount) lineMax = max(lineMax, probe.getLineWidth(i))
        val pad = (size * 0.35f).toInt()
        val w = (ceil(lineMax).toInt() + 2 * pad).coerceAtLeast(2)
        val h = (probe.height + 2 * pad).coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (l.bgColor != 0) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = l.bgColor }
            c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), size * 0.3f, size * 0.3f, bg)
        }
        c.save()
        c.translate(pad - (maxW - lineMax) / 2f, pad.toFloat())
        if (l.stroke) {
            val sp = TextPaint(paint).apply {
                style = Paint.Style.STROKE
                strokeWidth = size * 0.14f
                strokeJoin = Paint.Join.ROUND
                color = 0xFF000000.toInt()
            }
            makeLayout(t, sp, maxW).draw(c)
        } else if (l.bgColor == 0) {
            paint.setShadowLayer(size * 0.08f, 0f, size * 0.04f, 0x99000000.toInt())
        }
        makeLayout(t, paint, maxW).draw(c)
        c.restore()
        return bmp
    }

    private fun image(l: Layer, fw: Int, fh: Int, dir: File?, bs: Float): Bitmap? {
        if (dir == null || l.file.isEmpty()) return null
        val f = File(dir, l.file)
        if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        // at scale 1 a picture fits inside half of the frame
        val k = min(fw * 0.5f / o.outWidth, fh * 0.5f / o.outHeight) * bs
        val tw = max(2, (o.outWidth * k).roundToInt())
        val th = max(2, (o.outHeight * k).roundToInt())
        var sample = 1
        while (o.outWidth / (sample * 2) >= tw && o.outHeight / (sample * 2) >= th) sample *= 2
        val src = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        if (src.width == tw && src.height == th) return src
        val scaled = Bitmap.createScaledBitmap(src, tw, th, true)
        if (scaled !== src) src.recycle()
        return scaled
    }
}

/** Keeps the bitmaps of the layers drawn in the preview so they are not redrawn on every frame. */
class LayerBitmapCache {
    private val map = HashMap<String, Bitmap?>()

    fun get(l: Layer, fw: Int, fh: Int, tf: Typeface, fontKey: String, dir: File?, bs: Float): Bitmap? {
        val key = "${fw}x$fh|$bs|$fontKey|${l.kind}|${l.text}|${l.color}|${l.bgColor}|${l.stroke}|${l.file}"
        if (map.containsKey(key)) return map[key]
        if (map.size > 30) map.clear()
        val b = LayerRenderer.base(l, fw, fh, tf, dir, bs)
        map[key] = b
        return b
    }
}
