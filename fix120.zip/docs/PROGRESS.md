# ZirCut — progress and hand-off notes

Android video editor (Kotlin, Jetpack Compose, Media3 Transformer). Built only through GitHub Actions
(workflow unpacks every `fix*.zip` in the repo root in version order, then builds). Persian (RTL) first.

Target: a CapCut-class editor, delivered in 8 parts. Every part is a full project snapshot zip (fix110, fix120, ...).

## Parts

| # | Part | Status |
|---|------|--------|
| 1 | Projects + library (save, thumbnails, autosave, continue editing) | DONE (needs build verification) |
| 2 | Clip editing on the timeline of the main video (split, trim, delete, duplicate, reorder, undo/redo) | DONE (needs build verification) |
| 3 | Add more videos/photos as extra clips + multi-source export/preview | not started |
| 4 | Image and text tracks (position, scale, rotation, opacity) | not started |
| 5 | Audio (music/voice tracks, waveform, volume, fades, recording) | not started |
| 6 | Effects (GPU), transitions, color grading page | not started |
| 7 | Advanced export (resolution, fps, bitrate, codec, device capability check) | not started |
| 8 | AI tools that are really feasible (scene detect, silence, SRT import/export) + cleanup | not started |

Out of scope for these 8 parts (heavy models / separate engine): background removal, subject tracking,
advanced masks, full keyframe system. Do not fake them in the UI.

## Part 1 — what exists now

Done and wired to real logic:
- `project/Project.kt`: `ProjectStore` (filesDir/projects/<id>/ media.mp4, thumb.jpg, meta.json, project.json),
  create / save / load / list / rename / delete / duplicate. JSON via org.json. Original video is moved into the
  project folder (never modified).
- `MainViewModel`: every picked video becomes a project (`pickVideo`); `openProject`, `renameProject`,
  `duplicateProject`, `deleteProject`; autosave 500 ms after any edit (`autosave` / `persist`);
  `UiState` has `projectId`, `projectName`, `projects`, `saveStatus`.
- Home = library: new project, continue editing, 2-column project grid with thumbnails, ratio, age, search,
  per-project menu (rename / duplicate / delete), list of exported videos.
- New-project sheet: language + auto-edit options, then video picker.
- Editor top bar shows project name (tap to rename) and save status.
- Timeline ruler label no longer hidden under the playhead.

Not done in part 1 (deliberately later): templates, media browser, project settings screen, project recovery UI,
undo/redo (part 2), multiple media per project (part 2).

## Part 2 — what exists now

- `timeline/Edl.kt`: `EdlMap` (clips laid end to end; out-time <-> source-time), `EdlOps` (split, trimStart, trimEnd,
  delete, duplicate, moveEarlier, moveLater -> `EdlResult(segs, playhead)`), `outPhrasesOf` (subtitles on the edited timeline).
- `UiState.segments: List<Range>?` = manual clip list (null = automatic silence cut from `Planner.ranges`).
  First edit bakes the current automatic cut into manual clips. Saved in project.json ("segments").
  `MainViewModel.setSegments / undo / redo` (60 steps; history is only for clip edits, not subtitle text).
  `export()` uses the manual clips; the Exporter already accepts any ordered list of source ranges.
- Editor: playhead (`posMs`) is now on the EDITED timeline. Timeline draws clips end to end (current clip highlighted),
  subtitle blocks at their edited position. New dock tab "کلیپ" with the clip tools (work on the clip under the playhead).
  Preview playback walks the clip list (jumps between clips, supports duplicates and reordering).
  Undo/redo buttons in the top bar. App settings moved to the "ادیت" tab.
- Subtitle sync: `CaptionTimeline(phrases, ranges)` is used for preview exactly like export.

Not done in part 2: drag-to-trim handles and drag-and-drop reordering (use the tool buttons), ripple behaviours,
more than one source video (part 3), multiple tracks (parts 3-5), undo for subtitle edits.
A phrase that is played twice (duplicated clip) is drawn once on the timeline (first play).

## Design system (ui/Theme.kt, ui/Components.kt)

Tokens in `object Z` (colors, spacing 4pt, radii), `ZType` (Estedad variable font, per-weight Typeface),
Canvas-drawn icons `ZI`, controls `ZButton ZIconButton ZChip ZSegmented ZSwitch ZSlider ZCard ZField
ZSearchField ZToggleRow ZStat`. One accent (sky blue). Use `Txt(...)` for all text, `Modifier.press` for taps.
Persian digits: `fa(...)`, `faTime(ms)`.

## Known rules for whoever continues

- Cannot compile locally; keep each part small and re-check Kotlin signatures against the real source.
- Trailing lambda binds to the LAST parameter: put `onClick/onChange` last in composables.
- Do not remove existing working features (auto subtitles, silence cut, zoom, color look, export).
- Core engine files live in `core/` (Exporter, Planner, CaptionRenderer, ...). UI in `ui/`. Projects in `project/`.
