package app.zircut.timeline

import app.zircut.core.Phrase
import app.zircut.core.Range

/**
 * The edited timeline: an ordered list of clips, each one a [start, end) piece of the source video.
 * Clips can be split, trimmed, deleted, duplicated and re-ordered, so the same source time may appear
 * twice (duplicate) or out of order (move). "out" time = position on the edited timeline.
 */
class EdlMap(val segs: List<Range>) {
    private val starts = LongArray(segs.size)
    val total: Long

    init {
        var acc = 0L
        segs.forEachIndexed { i, r ->
            starts[i] = acc
            acc += r.len
        }
        total = acc
    }

    fun outStart(i: Int): Long = if (segs.isEmpty()) 0L else starts[i.coerceIn(0, segs.size - 1)]

    /** clip index and source position for a position on the edited timeline */
    fun locate(out: Long): Pair<Int, Long> {
        if (segs.isEmpty()) return 0 to 0L
        var i = segs.size - 1
        while (i > 0 && starts[i] > out) i--
        val r = segs[i]
        return i to (r.startMs + (out - starts[i]).coerceIn(0L, r.len))
    }

    /** first place on the edited timeline where this source time is played, or null if it was cut away */
    fun srcToOut(src: Long): Long? {
        for (i in segs.indices) {
            val r = segs[i]
            if (src >= r.startMs && src < r.endMs) return starts[i] + (src - r.startMs)
        }
        return null
    }

    /** first clip that overlaps a source interval */
    fun overlapIndex(s: Long, e: Long): Int? {
        for (i in segs.indices) {
            val r = segs[i]
            if (s < r.endMs && e > r.startMs) return i
        }
        return null
    }
}

class EdlResult(val segs: List<Range>, val playhead: Long)

/** All clip edits. They work on the clip under the playhead and return null when the edit is not possible. */
object EdlOps {
    private const val MIN = 100L

    fun split(segs: List<Range>, out: Long): EdlResult? {
        if (segs.isEmpty()) return null
        val m = EdlMap(segs)
        val (i, src) = m.locate(out)
        val r = segs[i]
        if (src - r.startMs < MIN || r.endMs - src < MIN) return null
        val n = ArrayList(segs)
        n[i] = Range(r.startMs, src)
        n.add(i + 1, Range(src, r.endMs))
        return EdlResult(n, out)
    }

    /** remove everything before the playhead inside this clip */
    fun trimStart(segs: List<Range>, out: Long): EdlResult? {
        if (segs.isEmpty()) return null
        val m = EdlMap(segs)
        val (i, src) = m.locate(out)
        val r = segs[i]
        if (src - r.startMs < 1L || r.endMs - src < MIN) return null
        val n = ArrayList(segs)
        n[i] = Range(src, r.endMs)
        return EdlResult(n, m.outStart(i))
    }

    /** remove everything after the playhead inside this clip */
    fun trimEnd(segs: List<Range>, out: Long): EdlResult? {
        if (segs.isEmpty()) return null
        val m = EdlMap(segs)
        val (i, src) = m.locate(out)
        val r = segs[i]
        if (src - r.startMs < MIN || r.endMs - src < 1L) return null
        val n = ArrayList(segs)
        n[i] = Range(r.startMs, src)
        return EdlResult(n, m.outStart(i) + (src - r.startMs))
    }

    fun delete(segs: List<Range>, out: Long): EdlResult? {
        if (segs.size <= 1) return null
        val m = EdlMap(segs)
        val i = m.locate(out).first
        val n = ArrayList(segs)
        n.removeAt(i)
        val nm = EdlMap(n)
        return EdlResult(n, minOf(nm.outStart(i.coerceAtMost(n.size - 1)), nm.total))
    }

    fun duplicate(segs: List<Range>, out: Long): EdlResult? {
        if (segs.isEmpty()) return null
        val m = EdlMap(segs)
        val i = m.locate(out).first
        val n = ArrayList(segs)
        n.add(i + 1, segs[i])
        return EdlResult(n, m.outStart(i) + segs[i].len)
    }

    fun moveEarlier(segs: List<Range>, out: Long): EdlResult? {
        if (segs.size < 2) return null
        val i = EdlMap(segs).locate(out).first
        if (i == 0) return null
        val n = ArrayList(segs)
        val t = n[i]; n[i] = n[i - 1]; n[i - 1] = t
        return EdlResult(n, EdlMap(n).outStart(i - 1))
    }

    fun moveLater(segs: List<Range>, out: Long): EdlResult? {
        if (segs.size < 2) return null
        val i = EdlMap(segs).locate(out).first
        if (i >= segs.size - 1) return null
        val n = ArrayList(segs)
        val t = n[i]; n[i] = n[i + 1]; n[i + 1] = t
        return EdlResult(n, EdlMap(n).outStart(i + 1))
    }
}

/** A subtitle placed on the edited timeline (first time it is played). */
class OutPhrase(val idx: Int, val startMs: Long, val endMs: Long, val text: String, val low: Boolean)

fun outPhrasesOf(phrases: List<Phrase>, map: EdlMap): List<OutPhrase> {
    val res = ArrayList<OutPhrase>()
    phrases.forEachIndexed { i, p ->
        val si = map.overlapIndex(p.startMs, p.endMs) ?: return@forEachIndexed
        val r = map.segs[si]
        val s = maxOf(p.startMs, r.startMs)
        val e = minOf(p.endMs, r.endMs)
        val o = map.outStart(si) + (s - r.startMs)
        res.add(OutPhrase(i, o, o + (e - s), p.text.replace("*", ""), p.words.any { it.conf < 0.5f }))
    }
    return res
}
