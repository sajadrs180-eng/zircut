package app.zircut

import app.zircut.core.Frame
import app.zircut.core.Options
import app.zircut.core.Range
import app.zircut.core.fineCover
import app.zircut.timeline.AudioClip
import app.zircut.timeline.AudioOps
import app.zircut.timeline.EdlOps
import app.zircut.timeline.SpeechMap
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-logic unit tests (no Android needed): run with `./gradlew testDebugUnitTest`.
 * WRITTEN WITHOUT A COMPILER / NEVER RUN in the environment where they were authored; if one fails to compile or fails,
 * fix the test or the code from the real message.
 */
class LogicTest {
    private fun segs() = listOf(Range(0, 1000), Range(1000, 3000), Range(3000, 4000))

    @Test fun deleteManyKeepsAtLeastOneClip() {
        assertNull(EdlOps.deleteMany(segs(), setOf(0, 1, 2)))
        val r = EdlOps.deleteMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(1, r!!.segs.size)
        assertEquals(1000L, r.segs[0].startMs)
    }

    @Test fun duplicateManyPutsCopiesAfterEachChosenClip() {
        val r = EdlOps.duplicateMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(5, r!!.segs.size)
        assertEquals(r.segs[0], r.segs[1])
        assertEquals(r.segs[3], r.segs[4])
    }

    @Test fun speedManySkipsPhotosAndSpeedsUpTheTimeline() {
        val r = EdlOps.setSpeedMany(segs(), setOf(0, 1), 2f, skip = setOf(0))
        assertNotNull(r)
        assertEquals(1f, r!!.segs[0].speed, 0.001f)
        assertEquals(2f, r.segs[1].speed, 0.001f)
        assertNull(EdlOps.setSpeedMany(segs(), setOf(0), 2f, skip = setOf(0)))
    }

    @Test fun moveManyKeepsOrderAndTracksPicked() {
        val l = listOf(Range(0, 1000), Range(1000, 2000), Range(2000, 3000), Range(3000, 4000))
        val toEnd = EdlOps.moveMany(l, setOf(0, 2), 3)!!
        assertEquals(listOf(1000L, 3000L, 0L, 2000L), toEnd.result.segs.map { it.startMs })
        assertEquals(setOf(2, 3), toEnd.picked)
        val earlier = EdlOps.moveMany(l, setOf(2), 0)!!
        assertEquals(listOf(0L, 2000L, 1000L, 3000L), earlier.result.segs.map { it.startMs })
        assertEquals(setOf(1), earlier.picked)
        assertNull(EdlOps.moveMany(l, setOf(0), 0))
        assertNull(EdlOps.moveMany(l, setOf(0, 1, 2, 3), 2))
    }

    @Test fun fineCoverIsOneWithoutRotationAndGrows() {
        assertEquals(1f, fineCover(0f, 1080f, 1920f), 0.001f)
        assertTrue(fineCover(10f, 1080f, 1920f) > 1f)
        assertTrue(fineCover(30f, 1080f, 1920f) > fineCover(10f, 1080f, 1920f))
        assertEquals(fineCover(15f, 100f, 100f), fineCover(-15f, 100f, 100f), 0.0001f)
    }

    @Test fun freeAspectRatioRoundTrips() {
        val o = Options(ratio = Frame.customId(1.5f))
        assertEquals(1.5f, Frame.aspect(o), 0.001f)
        assertEquals(1.5f, Frame.free(o)!!, 0.001f)
        assertEquals(Frame.MAX_FREE, Frame.free(Options(ratio = Frame.customId(99f)))!!, 0.001f)
    }

    private fun clip(inMs: Long, lenMs: Long) = AudioClip(1, AudioClip.KIND_VOICE, "a.wav", "a", 1000L, inMs, lenMs, 10_000L)

    @Test fun removeSilenceClosesGapsAndKeepsOrder() {
        // 10 s at 50 peaks/s: loud 0-2 s, silent 2-5 s, loud 5-10 s
        val peaks = ByteArray(500) { i -> if (i in 100 until 250) 0 else 200.toByte() }
        val r = AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36)
        assertNotNull(r)
        assertEquals(2, r!!.size)
        assertEquals(1000L, r[0].startMs)
        assertEquals(r[0].endMs, r[1].startMs)
        assertTrue(r.sumOf { it.lenMs } < 10_000L - 2000L)
    }

    @Test fun removeSilenceReturnsNullWhenNothingIsQuiet() {
        val peaks = ByteArray(500) { 200.toByte() }
        assertNull(AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36))
    }

    @Test fun speechMapJoinsCloseSpeechAndMeasuresDistance() {
        val m = SpeechMap.of(listOf(1000L to 2000L, 2300L to 3000L, 9000L to 9500L))
        assertEquals(0.0, m.distance(1500.0), 0.001)
        assertEquals(0.0, m.distance(2150.0), 0.001) // the 300 ms gap is joined
        assertEquals(500.0, m.distance(3500.0), 0.001)
        assertEquals(400.0, m.distance(600.0), 0.001)
        assertTrue(m.distance(5000.0) >= 2000.0)
        assertTrue(SpeechMap.of(emptyList()).distance(100.0) > 1e9)
    }

    @Test fun speechDucksMusicButNotTheExtractedVideoSound() {
        val music = AudioClip(1, AudioClip.KIND_MUSIC, "a.wav", "music", 0L, 0L, 20000L, 20000L)
        val ext = music.copy(id = 2, name = "صدای ویدیو ۱")
        val m = SpeechMap.of(listOf(5000L to 6000L))
        assertEquals(AudioOps.DUCK_LEVEL, AudioOps.duckFactor(listOf(music), music, 5500.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(ext), ext, 5500.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(music), music, 1000.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(music), music, 5500.0, null), 0.001f)
    }
}
