package app.zircut.core

import kotlin.math.max

object Planner {
    private val fillerSet = setOf(
        "ام", "اوم", "اِ", "اه", "امم", "اممم", "اووم", "اوووم", "اِمم",
        "um", "uh", "uhh", "umm", "er", "erm", "ehm", "hmm", "hm", "mm", "mmm", "ah", "eh"
    )
    private val punctChars = ".,،؟?!…-\"«»:;؛()[]"

    private fun norm(t: String) = t.trim().trim { it in punctChars }.lowercase()

    /** Turns raw Whisper tokens (one word each) into clean words. */
    fun clean(raw: List<Word>, removeFillers: Boolean): List<Word> {
        val out = ArrayList<Word>()
        var pendingCut = false
        for (w in raw) {
            val t = w.text.trim().replace('ي', 'ی').replace('ك', 'ک')
            if (t.isEmpty()) continue
            if (t.startsWith("[") || t.startsWith("(") || t.startsWith("♪") || t.startsWith("*")) continue
            if (t.all { it in punctChars } && out.isNotEmpty()) {
                val last = out.removeAt(out.size - 1)
                out.add(last.copy(text = last.text + t, endMs = max(last.endMs, w.endMs)))
                continue
            }
            if (removeFillers && norm(t) in fillerSet) {
                pendingCut = true
                continue
            }
            out.add(w.copy(text = t, cutBefore = pendingCut))
            pendingCut = false
        }
        // Whisper sometimes loops on one word; keep at most 3 in a row.
        val res = ArrayList<Word>()
        var run = 0
        for (w in out) {
            if (res.isNotEmpty() && norm(res.last().text) == norm(w.text)) run++ else run = 1
            if (run <= 3) res.add(w)
        }
        return res
    }

    fun phrases(words: List<Word>, maxWords: Int = 4): List<Phrase> {
        val res = ArrayList<Phrase>()
        var cur = ArrayList<Word>()
        for (w in words) {
            if (cur.isNotEmpty()) {
                val gap = w.startMs - cur.last().endMs
                val endsSentence = cur.last().text.last() in ".?!؟…،,"
                if (cur.size >= maxWords || gap > 450 || endsSentence) {
                    res.add(Phrase(cur))
                    cur = ArrayList()
                }
            }
            cur.add(w)
        }
        if (cur.isNotEmpty()) res.add(Phrase(cur))
        return res
    }

    /** Applies a user's text edit to a phrase while keeping its timing. */
    fun rebuild(old: Phrase, newText: String): Phrase {
        val parts = newText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return old
        if (parts.size == old.words.size) {
            return Phrase(old.words.mapIndexed { i, w -> w.copy(text = parts[i], conf = if (parts[i] == w.text) w.conf else 1f) })
        }
        val s = old.startMs
        val e = old.endMs
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        var cursor = s
        val words = parts.mapIndexed { i, p ->
            val dur = (e - s) * p.length / total
            val w = Word(p, cursor, if (i == parts.size - 1) e else cursor + dur, i == 0 && old.words.first().cutBefore)
            cursor += dur
            w
        }
        return Phrase(words)
    }

    /** Segments of the original video that are kept in the final cut. */
    fun ranges(words: List<Word>, totalMs: Long, opt: Options): List<Range> {
        if (!opt.removeSilence || words.isEmpty()) return listOf(Range(0, totalMs))
        val pad = 120L
        val maxGap = opt.maxGapMs.coerceAtLeast(2 * pad + 60)
        val groups = ArrayList<Range>()
        var s = words.first().startMs
        var e = words.first().endMs
        for (i in 1 until words.size) {
            val w = words[i]
            val gap = w.startMs - e
            val limit = if (w.cutBefore) 120L else maxGap
            if (gap > limit) {
                groups.add(Range(s, e))
                s = w.startMs
                e = w.endMs
            } else {
                e = max(e, w.endMs)
            }
        }
        groups.add(Range(s, e))
        val padded = groups.map {
            Range((it.startMs - pad).coerceAtLeast(0), (it.endMs + pad).coerceAtMost(totalMs))
        }.toMutableList()
        for (i in 0 until padded.size - 1) {
            if (padded[i + 1].startMs < padded[i].endMs) {
                val mid = (padded[i + 1].startMs + padded[i].endMs) / 2
                padded[i] = padded[i].copy(endMs = mid)
                padded[i + 1] = padded[i + 1].copy(startMs = mid)
            }
        }
        val kept = padded.filter { it.len >= 200 }
        return if (kept.isEmpty()) listOf(Range(0, totalMs)) else kept
    }
}

/** Maps the final (cut) timeline back to the source video to decide which caption to show. */
class CaptionTimeline(private val phrases: List<Phrase>, private val ranges: List<Range>) {
    private val outStart = LongArray(ranges.size)

    init {
        var acc = 0L
        ranges.forEachIndexed { i, r ->
            outStart[i] = acc
            acc += r.len
        }
    }

    data class State(val phraseIdx: Int, val wordIdx: Int, val pop: Float, val tMs: Long = 0)

    private fun srcAt(outMs: Long): Long {
        var i = ranges.size - 1
        while (i > 0 && outStart[i] > outMs) i--
        return ranges[i].startMs + (outMs - outStart[i])
    }

    fun stateAt(outMs: Long): State? {
        if (ranges.isEmpty()) return null
        val src = srcAt(outMs)
        var best: State? = null
        for ((pi, p) in phrases.withIndex()) {
            if (src < p.startMs - 40) break
            if (src <= p.endMs + 250) {
                var wi = 0
                for ((k, w) in p.words.withIndex()) if (src >= w.startMs) wi = k
                val t = (src - p.startMs).coerceAtLeast(0)
                val pop = if (t < 150) 0.88f + 0.12f * (t / 150f) else 1f
                best = State(pi, wi, pop, t)
            }
        }
        return best
    }
}
