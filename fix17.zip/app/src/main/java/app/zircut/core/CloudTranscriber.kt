package app.zircut.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Optional online recognition through Cloudflare Workers AI (Whisper large-v3-turbo), using the user's own free account. */
object CloudTranscriber {
    data class W(val text: String, val startMs: Long, val endMs: Long)

    fun transcribe(account: String, token: String, samples: FloatArray, lang: String): List<W> {
        val b64 = android.util.Base64.encodeToString(toWav(samples), android.util.Base64.NO_WRAP)
        val body = JSONObject().put("audio", b64).put("task", "transcribe")
        if (lang != "auto") body.put("language", lang)
        val url = URL("https://api.cloudflare.com/client/v4/accounts/${account.trim()}/ai/run/@cf/openai/whisper-large-v3-turbo")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 120_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${token.trim()}")
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) throw IOException("خطای سرویس آنلاین ($code)")
            val root = JSONObject(text)
            if (root.has("success") && !root.optBoolean("success", true)) throw IOException("سرویس آنلاین خطا داد")
            val res = root.optJSONObject("result") ?: root
            return parse(res, samples.size / 16f)
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(res: JSONObject, durMs: Float): List<W> {
        val out = ArrayList<W>()
        fun addWords(arr: JSONArray?) {
            if (arr == null) return
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val w = o.optString("word").trim()
                if (w.isEmpty()) continue
                val s = (o.optDouble("start", 0.0) * 1000).toLong()
                val e = (o.optDouble("end", 0.0) * 1000).toLong()
                out.add(W(w, s, maxOf(e, s + 50)))
            }
        }
        addWords(res.optJSONArray("words"))
        if (out.isEmpty()) {
            val segs = res.optJSONArray("segments")
            if (segs != null) {
                for (i in 0 until segs.length()) {
                    val sg = segs.optJSONObject(i) ?: continue
                    val before = out.size
                    addWords(sg.optJSONArray("words"))
                    if (out.size == before) {
                        spread(out, sg.optString("text"), (sg.optDouble("start", 0.0) * 1000).toLong(), (sg.optDouble("end", 0.0) * 1000).toLong())
                    }
                }
            }
        }
        if (out.isEmpty()) spread(out, res.optString("text"), 0L, durMs.toLong())
        return out
    }

    private fun spread(out: MutableList<W>, text: String, s: Long, e: Long) {
        val parts = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        val end = maxOf(e, s + 200)
        var cur = s
        parts.forEachIndexed { i, p ->
            val d = (end - s) * p.length / total
            out.add(W(p, cur, if (i == parts.size - 1) end else cur + d))
            cur += d
        }
    }

    private fun toWav(s: FloatArray): ByteArray {
        val n = s.size * 2
        val b = ByteBuffer.allocate(44 + n).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt(36 + n).put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(16000).putInt(32000).putShort(2).putShort(16)
        b.put("data".toByteArray()).putInt(n)
        for (v in s) {
            val x = (v.coerceIn(-1f, 1f) * 32767f).toInt()
            b.putShort(x.toShort())
        }
        return b.array()
    }
}
