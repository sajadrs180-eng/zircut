package app.zircut.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.zircut.Recent
import app.zircut.UiState
import app.zircut.core.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(
    ui: UiState,
    modifier: Modifier,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onOptions: (Options) -> Unit,
    onLanguage: (String) -> Unit,
    onOpen: (Recent) -> Unit,
    onDelete: (Recent) -> Unit
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = Z.S5, vertical = Z.S4),
        verticalArrangement = Arrangement.spacedBy(Z.S3)
    ) {
        // ---- header ----
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ZMark(40.dp)
                Spacer(Modifier.size(Z.S3))
                Column(Modifier.weight(1f)) {
                    Txt("زیرکات", style = ZType.title)
                    Txt("ادیت خودکار ویدیو", style = ZType.caption, color = Z.TextSec)
                }
                ZIconButton(
                    ZI.Tune, onSettings, bg = Z.Surface2, box = 44.dp, size = Z.IconMd,
                    modifier = Modifier.border(Z.Hair, Z.Border, RoundedCornerShape(Z.RSm))
                )
            }
        }

        // ---- primary action ----
        item {
            Spacer(Modifier.height(Z.S2))
            val shape = RoundedCornerShape(Z.RMd)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(Z.Accent).press(true, onNew).padding(Z.S5),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Txt("پروژه جدید", style = ZType.title, color = Z.OnAccent)
                    Txt("یک ویدیو انتخاب کن؛ بقیه‌اش خودکاره", style = ZType.caption, color = Color(0xCC04141D))
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Z.OnAccent), contentAlignment = Alignment.Center) {
                    ZIcon(ZI.Plus, tint = Z.Accent, size = Z.IconLg)
                }
            }
        }

        // ---- automatic tools ----
        item { ZSectionLabel("ویرایش خودکار", Modifier.padding(top = Z.S3)) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
                ToolTile(Modifier.weight(1f), ZI.Captions, "زیرنویس خودکار", "فارسی و انگلیسی", ui.options.captions) {
                    onOptions(ui.options.copy(captions = it))
                }
                ToolTile(Modifier.weight(1f), ZI.Scissors, "حذف سکوت و «اِم»", "ویدیوی فشرده‌تر", ui.options.removeSilence) {
                    onOptions(ui.options.copy(removeSilence = it, removeFillers = it))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
                ToolTile(Modifier.weight(1f), ZI.Expand, "زوم ریتمیک", "حرکت روی برش‌ها", ui.options.zoom) {
                    onOptions(ui.options.copy(zoom = it))
                }
                ToolTile(Modifier.weight(1f), ZI.Phone, "خروجی ۹:۱۶", "ریلز، شورت و استوری", ui.options.vertical) {
                    onOptions(ui.options.copy(vertical = it))
                }
            }
        }

        // ---- language ----
        item { ZSectionLabel("زبان گفتار", Modifier.padding(top = Z.S3)) }
        item {
            ZSegmented(
                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار"),
                ui.options.language, onLanguage
            )
        }

        // ---- recents ----
        item { ZSectionLabel("پروژه‌های اخیر", Modifier.padding(top = Z.S3)) }
        if (ui.recent.isEmpty()) {
            item {
                ZCard(Modifier.fillMaxWidth(), padding = PaddingValues(vertical = Z.S6, horizontal = Z.S4)) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(Z.RSm)).background(Z.Surface3), contentAlignment = Alignment.Center) {
                            ZIcon(ZI.Film, tint = Z.TextSec, size = Z.IconMd)
                        }
                        Spacer(Modifier.height(Z.S3))
                        Txt("هنوز پروژه‌ای نداری", style = ZType.labelStrong)
                        Txt("ویدیوهایی که بسازی اینجا نشون داده می‌شن.", style = ZType.caption, color = Z.TextSec)
                    }
                }
            }
        } else {
            items(ui.recent, key = { it.uri }) { r ->
                ZCard(Modifier.fillMaxWidth(), padding = PaddingValues(Z.S2), onClick = { onOpen(r) }) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
                        Thumb(r.uri, Modifier.size(width = 52.dp, height = 70.dp).clip(RoundedCornerShape(8.dp)))
                        Column(Modifier.weight(1f)) {
                            Txt(r.title, style = ZType.bodyStrong, maxLines = 2)
                            Txt(ago(r.time), style = ZType.caption, color = Z.TextSec)
                        }
                        ZIconButton(ZI.Trash, { onDelete(r) }, tint = Z.Danger, box = 40.dp, size = Z.IconSm)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(Z.S6)) }
    }
}

@Composable
private fun ToolTile(modifier: Modifier, icon: ZI, title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    ZCard(modifier, selected = on, padding = PaddingValues(Z.S3), onClick = { onChange(!on) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(Z.RSm)).background(if (on) Z.AccentSoft else Z.Surface3),
                contentAlignment = Alignment.Center
            ) { ZIcon(icon, tint = if (on) Z.Accent else Z.TextSec, size = Z.IconMd) }
            Spacer(Modifier.weight(1f))
            ZSwitch(on, null)
        }
        Spacer(Modifier.height(Z.S3))
        Txt(title, style = ZType.labelStrong, maxLines = 1)
        Txt(sub, style = ZType.caption, color = Z.TextSec, maxLines = 1)
    }
}

@Composable
private fun Thumb(uri: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, Uri.parse(uri))
                val b = r.getFrameAtTime(500_000L)
                r.release()
                b
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.background(Z.Surface3), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        } else {
            ZIcon(ZI.Film, tint = Z.TextTer, size = Z.IconMd)
        }
    }
}

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000L
    return when {
        m < 1L -> "همین الان"
        m < 60L -> fa("$m") + " دقیقه پیش"
        m < 1440L -> fa("${m / 60L}") + " ساعت پیش"
        else -> fa("${m / 1440L}") + " روز پیش"
    }
}
