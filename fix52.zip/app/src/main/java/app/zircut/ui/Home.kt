package app.zircut.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.zircut.Recent
import app.zircut.UiState
import app.zircut.core.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Surface1 = Color(0xFF15151F)
private val Surface2 = Color(0xFF1E1E2C)
private val Accent = Color(0xFF8B5CFF)
private val Blue = Color(0xFF3D7BFF)
private val Muted = Color(0xFF9A9AB0)

@Composable
fun HomeScreen(
    ui: UiState,
    modifier: Modifier,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onOptions: (Options) -> Unit,
    onLanguage: (String) -> Unit,
    onOpen: (Recent) -> Unit,
    onDelete: (Recent) -> Unit
) {
    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { HomeHeader(onSettings) }
        item { HeroButton(onNew) }

        item { SectionTitle("ابزارهای هوشمند") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolCard(Modifier.weight(1f), Icons.Rounded.Subtitles, "زیرنویس خودکار", "فارسی و انگلیسی", ui.options.captions) {
                    onOptions(ui.options.copy(captions = it))
                }
                ToolCard(Modifier.weight(1f), Icons.Rounded.ContentCut, "حذف سکوت و «اِم»", "ویدیو فشرده‌تر می‌شه", ui.options.removeSilence) {
                    onOptions(ui.options.copy(removeSilence = it, removeFillers = it))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolCard(Modifier.weight(1f), Icons.Rounded.ZoomIn, "زوم ریتمیک", "حرکت روی برش‌ها", ui.options.zoom) {
                    onOptions(ui.options.copy(zoom = it))
                }
                ToolCard(Modifier.weight(1f), Icons.Rounded.Smartphone, "خروجی ۹:۱۶", "ریلز، شورت و استوری", ui.options.vertical) {
                    onOptions(ui.options.copy(vertical = it))
                }
            }
        }

        item { SectionTitle("زبان گفتار") }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار").forEach { (code, name) ->
                    val sel = ui.options.language == code
                    val bg by animateColorAsState(if (sel) Accent else Color.Transparent, tween(220), label = "langBg")
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg)
                            .clickable { onLanguage(code) }.padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(name, color = if (sel) Color.White else Muted, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp) }
                }
            }
        }

        item { SectionTitle("پروژه‌های اخیر") }
        if (ui.recent.isEmpty()) {
            item { EmptyRecents() }
        } else {
            items(ui.recent.chunked(2), key = { pair -> pair.first().uri }) { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    pair.forEach { r -> RecentCard(r, Modifier.weight(1f), onOpen, onDelete) }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun HomeHeader(onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Brush.linearGradient(listOf(Accent, Blue))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(25.dp)) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("زیرکات", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("ادیتور هوشمند ویدیو", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Surface2).clickable(onClick = onSettings),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Settings, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp)) }
    }
}

/** The big "new project" button: a moving gradient, a pulsing plus and a little bounce when pressed. */
@Composable
private fun HeroButton(onNew: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) 0.96f else 1f, spring(dampingRatio = 0.45f, stiffness = 420f), label = "heroPress")
    val inf = rememberInfiniteTransition(label = "hero")
    val pulse by inf.animateFloat(1f, 1.12f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "heroPulse")
    val shift by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Reverse), label = "heroShift")
    Box(
        Modifier.fillMaxWidth()
            .graphicsLayer { scaleX = press; scaleY = press }
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Accent, Blue), start = Offset(0f, 0f), end = Offset(700f + 500f * shift, 420f)))
            .clickable(interactionSource = src, indication = null, onClick = onNew)
            .padding(horizontal = 22.dp, vertical = 26.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(
                Modifier.size(64.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }.clip(CircleShape).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp)) }
            Column {
                Text("پروژه جدید", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("ویدیو رو انتخاب کن؛ زیرنویس و ادیت خودکاره", color = Color(0xFFEDE3FF), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun ToolCard(modifier: Modifier, icon: ImageVector, title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val border by animateColorAsState(if (on) Accent else Color.Transparent, tween(250), label = "toolBorder")
    val bg by animateColorAsState(if (on) Color(0xFF241D45) else Surface1, tween(250), label = "toolBg")
    val iconBg by animateColorAsState(if (on) Accent else Surface2, tween(250), label = "toolIconBg")
    Column(
        modifier.clip(shape).background(bg).border(1.5.dp, border, shape).clickable { onChange(!on) }.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(iconBg), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = null)
        }
        Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyRecents() {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Surface1).padding(vertical = 28.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(Icons.Rounded.VideoLibrary, contentDescription = null, tint = Muted, modifier = Modifier.size(40.dp))
        Text("هنوز ویدیویی نساختی. بعد از ساخت، اینجا نشون داده می‌شه.", color = Muted, fontSize = 14.sp)
    }
}

@Composable
private fun RecentCard(r: Recent, modifier: Modifier, onOpen: (Recent) -> Unit, onDelete: (Recent) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(modifier.aspectRatio(0.78f).clip(shape).background(Surface1).clickable { onOpen(r) }) {
        Thumb(r.uri, Modifier.matchParentSize())
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color(0xDD000000))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(r.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(ago(r.time), color = Color(0xFFCFCBEA), fontSize = 11.sp)
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(8.dp).size(32.dp).clip(CircleShape)
                .background(Color(0x99000000)).clickable { onDelete(r) },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Delete, contentDescription = null, tint = Color(0xFFFF9C9C), modifier = Modifier.size(17.dp)) }
    }
}

@Composable
private fun Thumb(uri: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, Uri.parse(uri))
                val b = r.getFrameAtTime(500_000L)
                r.release()
                b
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.background(Surface2)) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        }
    }
}

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000L
    return when {
        m < 1L -> "همین الان"
        m < 60L -> "$m دقیقه پیش"
        m < 1440L -> "${m / 60L} ساعت پیش"
        else -> "${m / 1440L} روز پیش"
    }
}
