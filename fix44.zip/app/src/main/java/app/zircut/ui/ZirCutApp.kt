@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.zircut.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.Slider
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import app.zircut.core.CapLayout
import app.zircut.core.CaptionRenderer
import app.zircut.core.Phrase
import app.zircut.core.Word
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.zircut.MainViewModel
import app.zircut.Stage
import app.zircut.core.ModelSize
import app.zircut.core.Planner
import app.zircut.core.Styles

private val CardBg = Color(0xFF15151F)

@UnstableApi
@Composable
fun ZirCutApp(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val keepOn = ui.stage is Stage.Working
    val hostView = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(keepOn) {
        hostView.keepScreenOn = keepOn
        onDispose { hostView.keepScreenOn = false }
    }
    val theme = Themes.byId(ui.themeId)
    var showSettings by remember { mutableStateOf(false) }
    val busy = ui.stage is Stage.Working
    BackHandler(enabled = ui.stage is Stage.Done || ui.stage is Stage.Failed || ui.stage is Stage.NeedModel) { vm.reset() }

    val ctx = LocalContext.current
    DisposableEffect(busy) {
        val w = (ctx as? Activity)?.window
        if (busy) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickVideo(uri)
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFont(uri)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Box(
                Modifier.fillMaxSize().background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF17112E), Color(0xFF0B0B12), Color(0xFF0B0B12)))
                )
            )

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(if (ui.stage is Stage.Review) 8.dp else 16.dp)
            ) {
                if (ui.stage !is Stage.Idle && ui.stage !is Stage.Review) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("زیرکات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { showSettings = true }) { Text("تنظیمات") }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                when (val s = ui.stage) {
                    is Stage.Idle -> HomeScreen(
                        ui = ui,
                        modifier = Modifier.weight(1f),
                        onNew = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                        onSettings = { showSettings = true },
                        onOptions = { vm.setOptions(it) },
                        onLanguage = { vm.setLanguage(it) },
                        onOpen = { vm.openRecent(it) },
                        onDelete = { vm.removeRecent(it) }
                    )

                    is Stage.NeedModel -> Panel {
                        Text("یه مدل تشخیص گفتار لازمه", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("فقط بار اول دانلود می‌شه و بعدش همه‌چیز آفلاین کار می‌کنه.", color = Color(0xFFCFCBEA))
                        if (ui.notice.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(ui.notice, color = Color(0xFFFFD27A))
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { vm.retryCloud() }, modifier = Modifier.fillMaxWidth()) { Text("تلاش دوباره (بعد از روشن کردن فیلترشکن)") }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { vm.diagnose() }, modifier = Modifier.fillMaxWidth()) { Text("تست اتصال (پیدا کردن مشکل)") }
                        if (ui.diag.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            androidx.compose.foundation.text.selection.SelectionContainer {
                                Text(ui.diag, color = Color(0xFFB9F6CA), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.downloadModel() }, modifier = Modifier.fillMaxWidth()) {
                            Text("دانلود مدل (${ui.modelSize.sizeMb} مگابایت)")
                        }
                        OutlinedButton(
                            onClick = { modelPicker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("وارد کردن فایل مدل (.bin)") }
                        TextButton(onClick = { vm.reset() }) { Text("انصراف") }
                    }

                    is Stage.Working -> Panel {
                        Text(s.label, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(16.dp))
                        val pr = s.progress
                        if (pr == null) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)))
                        } else {
                            LinearProgressIndicator(progress = { pr }, color = Color(0xFF8B5CFF), trackColor = Color(0xFF2A2A3C), modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)))
                            Spacer(Modifier.height(6.dp))
                            Text("${(pr * 100).toInt()}٪", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("صفحه رو روشن نگه دار. ممکنه چند دقیقه طول بکشه.", color = Color(0xFFCFCBEA))
                        if (ui.transcribing) {
                            Spacer(Modifier.height(12.dp))
                            Text("تا اینجا تموم بشه، استایل زیرنویس رو انتخاب کن:", color = Color.White, style = MaterialTheme.typography.titleSmall)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Styles.all.forEach { st ->
                                    FilterChip(selected = ui.styleId == st.id, onClick = { vm.setStyle(st.id) }, label = { Text(st.nameFa) })
                                }
                            }
                        }
                        TextButton(onClick = { vm.cancel() }) { Text("لغو") }
                    }

                    is Stage.Review -> EditorScreen(
                        ui = ui,
                        vm = vm,
                        onSettings = { showSettings = true },
                        onPickFont = { fontPicker.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f)
                    )

                    is Stage.Done -> {
                        Panel {
                            Text("ویدیو آماده شد و توی گالری (Movies/ZirCut) ذخیره شد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Text(ui.debug, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9A95C4))
                            Spacer(Modifier.height(10.dp))
                            AndroidView(
                                factory = { c ->
                                    VideoView(c).apply {
                                        val mc = MediaController(c)
                                        mc.setAnchorView(this)
                                        setMediaController(mc)
                                        setVideoURI(s.uri)
                                        setOnPreparedListener { it.isLooping = true; start() }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(420.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { share(ctx, s.uri) }, modifier = Modifier.fillMaxWidth()) { Text("اشتراک‌گذاری") }
                        if (ui.phrases.isNotEmpty()) {
                            OutlinedButton(onClick = { vm.backToReview() }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش دوباره") }
                        }
                        TextButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("برگشت به خانه") }
                    }

                    is Stage.Failed -> Panel {
                        Text("یه مشکلی پیش اومد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        val hint = when {
                            s.message.contains("Codec", ignoreCase = true) || s.message.contains("encoder", ignoreCase = true) ->
                                "گوشی تنظیمات ساخت ویدیو رو قبول نکرد. دوباره امتحان کن؛ برنامه خودش کیفیت رو پایین‌تر می‌آره."
                            s.message.contains("مدل") ->
                                "مدل تشخیص گفتار آماده نیست. اینترنت رو چک کن و دوباره امتحان کن."
                            else -> null
                        }
                        if (hint != null) {
                            Text(hint, color = Color.White)
                            Spacer(Modifier.height(8.dp))
                        }
                        Text(s.message, color = Color(0xFFFFB4B4), style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("برگشت") }
                    }
                }
            }

            if (showSettings) {
                ModalBottomSheet(onDismissRequest = { showSettings = false }) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("زبان ویدیو", style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار").forEach { (code, name) ->
                                    FilterChip(selected = ui.options.language == code, onClick = { vm.setLanguage(code) }, label = { Text(name) })
                                }
                            }
                            Text("مدل تشخیص گفتار", style = MaterialTheme.typography.titleMedium)
                            ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                            SwitchRow("دقت بیشتر (کندتر)", ui.accurate) { vm.setAccurate(it) }
                            Text("خاموش = جستجوی سریع (پیش‌فرض). روشن = جستجوی دقیق‌تر ولی کندتر.", style = MaterialTheme.typography.bodySmall)
                            Text("تشخیص آنلاین (بدون دانلود مدل، دقیق‌ترین)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "اگر آدرس سرویس آنلاین پر باشد، صدا برای تشخیص فرستاده می‌شود و هیچ مدلی دانلود نمی‌شود. اگر خطا بدهد، مدل روی گوشی استفاده می‌شود.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            OutlinedTextField(value = ui.workerUrl, onValueChange = { vm.setWorkerUrl(it) }, label = { Text("آدرس سرویس آنلاین") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ModelChips(selected: ModelSize, ready: Set<ModelSize>, onSelect: (ModelSize) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ModelSize.values().forEach { m ->
            FilterChip(
                selected = selected == m,
                onClick = { onSelect(m) },
                label = { Text(m.labelFa + " — " + m.sizeMb + "MB" + if (m in ready) " ✓" else "") }
            )
        }
    }
}

private fun share(ctx: android.content.Context, uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری"))
}


@Composable
private fun CaptionPreview(phrase: Phrase, style: app.zircut.core.SubStyle, font: android.graphics.Typeface, layout: CapLayout) {
    val bmp = remember(phrase, style, font, layout) {
        CaptionRenderer(540, 960, style, font, layout).render(phrase, minOf(1, phrase.words.size - 1))
    }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.height(300.dp).aspectRatio(9f / 16f)) {
            drawRect(Color(0xFF15151B))
            val img = bmp.asImageBitmap()
            val k = size.width / 540f
            val w = img.width * k
            val h = img.height * k
            drawImage(
                img,
                dstOffset = IntOffset((layout.x * size.width - w / 2f).toInt(), (layout.y * size.height - h / 2f).toInt()),
                dstSize = IntSize(w.toInt(), h.toInt())
            )
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, min: Float, max: Float, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Color(0xFFCFCBEA), style = MaterialTheme.typography.labelMedium)
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max, steps = steps)
    }
}
