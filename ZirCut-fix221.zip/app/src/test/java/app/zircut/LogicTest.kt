package app.zircut

import app.zircut.core.Frame
import app.zircut.core.Cuts
import app.zircut.core.CutTr
import app.zircut.core.TrKind
import app.zircut.core.TrMath
import app.zircut.core.Fx
import app.zircut.core.VideoKeys
import app.zircut.core.VideoPose
import app.zircut.core.Options
import app.zircut.core.Range
import app.zircut.core.fineCover
import app.zircut.timeline.AudioClip
import app.zircut.timeline.AudioOps
import app.zircut.timeline.EdlOps
import app.zircut.timeline.SpeechMap
import app.zircut.timeline.Layer
import app.zircut.timeline.Ripple
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-logic unit tests (no Android needed): run with `./gradlew testDebugUnitTest`.
 * WRITTEN WITHOUT A COMPILER / NEVER RUN in the environment where they were authored; if one fails to compile or fails,
 * fix the test or the code from the real message.
 */
class LogicTest {
    private fun segs() = listOf(Range(0, 1000), Range(1000, 3000), Range(3000, 4000))

    @Test fun deleteManyKeepsAtLeastOneClip() {
        assertNull(EdlOps.deleteMany(segs(), setOf(0, 1, 2)))
        val r = EdlOps.deleteMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(1, r!!.segs.size)
        assertEquals(1000L, r.segs[0].startMs)
    }

    @Test fun duplicateManyPutsCopiesAfterEachChosenClip() {
        val r = EdlOps.duplicateMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(5, r!!.segs.size)
        assertEquals(r.segs[0], r.segs[1])
        assertEquals(r.segs[3], r.segs[4])
    }

    @Test fun speedManySkipsPhotosAndSpeedsUpTheTimeline() {
        val r = EdlOps.setSpeedMany(segs(), setOf(0, 1), 2f, skip = setOf(0))
        assertNotNull(r)
        assertEquals(1f, r!!.segs[0].speed, 0.001f)
        assertEquals(2f, r.segs[1].speed, 0.001f)
        assertNull(EdlOps.setSpeedMany(segs(), setOf(0), 2f, skip = setOf(0)))
    }

    @Test fun moveManyKeepsOrderAndTracksPicked() {
        val l = listOf(Range(0, 1000), Range(1000, 2000), Range(2000, 3000), Range(3000, 4000))
        val toEnd = EdlOps.moveMany(l, setOf(0, 2), 3)!!
        assertEquals(listOf(1000L, 3000L, 0L, 2000L), toEnd.result.segs.map { it.startMs })
        assertEquals(setOf(2, 3), toEnd.picked)
        val earlier = EdlOps.moveMany(l, setOf(2), 0)!!
        assertEquals(listOf(0L, 2000L, 1000L, 3000L), earlier.result.segs.map { it.startMs })
        assertEquals(setOf(1), earlier.picked)
        assertNull(EdlOps.moveMany(l, setOf(0), 0))
        assertNull(EdlOps.moveMany(l, setOf(0, 1, 2, 3), 2))
    }

    @Test fun fineCoverIsOneWithoutRotationAndGrows() {
        assertEquals(1f, fineCover(0f, 1080f, 1920f), 0.001f)
        assertTrue(fineCover(10f, 1080f, 1920f) > 1f)
        assertTrue(fineCover(30f, 1080f, 1920f) > fineCover(10f, 1080f, 1920f))
        assertEquals(fineCover(15f, 100f, 100f), fineCover(-15f, 100f, 100f), 0.0001f)
    }

    @Test fun freeAspectRatioRoundTrips() {
        val o = Options(ratio = Frame.customId(1.5f))
        assertEquals(1.5f, Frame.aspect(o), 0.001f)
        assertEquals(1.5f, Frame.free(o)!!, 0.001f)
        assertEquals(Frame.MAX_FREE, Frame.free(Options(ratio = Frame.customId(99f)))!!, 0.001f)
    }

    private fun clip(inMs: Long, lenMs: Long) = AudioClip(1, AudioClip.KIND_VOICE, "a.wav", "a", 1000L, inMs, lenMs, 10_000L)

    @Test fun removeSilenceClosesGapsAndKeepsOrder() {
        // 10 s at 50 peaks/s: loud 0-2 s, silent 2-5 s, loud 5-10 s
        val peaks = ByteArray(500) { i -> if (i in 100 until 250) 0 else 200.toByte() }
        val r = AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36)
        assertNotNull(r)
        assertEquals(2, r!!.size)
        assertEquals(1000L, r[0].startMs)
        assertEquals(r[0].endMs, r[1].startMs)
        assertTrue(r.sumOf { it.lenMs } < 10_000L - 2000L)
    }

    @Test fun removeSilenceReturnsNullWhenNothingIsQuiet() {
        val peaks = ByteArray(500) { 200.toByte() }
        assertNull(AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36))
    }

    @Test fun speechMapJoinsCloseSpeechAndMeasuresDistance() {
        val m = SpeechMap.of(listOf(1000L to 2000L, 2300L to 3000L, 9000L to 9500L))
        assertEquals(0.0, m.distance(1500.0), 0.001)
        assertEquals(0.0, m.distance(2150.0), 0.001) // the 300 ms gap is joined
        assertEquals(500.0, m.distance(3500.0), 0.001)
        assertEquals(400.0, m.distance(600.0), 0.001)
        assertTrue(m.distance(5000.0) >= 2000.0)
        assertTrue(SpeechMap.of(emptyList()).distance(100.0) > 1e9)
    }

    @Test fun speechDucksMusicButNotTheExtractedVideoSound() {
        val music = AudioClip(1, AudioClip.KIND_MUSIC, "a.wav", "music", 0L, 0L, 20000L, 20000L)
        val ext = music.copy(id = 2, name = "صدای ویدیو ۱")
        val m = SpeechMap.of(listOf(5000L to 6000L))
        assertEquals(AudioOps.DUCK_LEVEL, AudioOps.duckFactor(listOf(music), music, 5500.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(ext), ext, 5500.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(music), music, 1000.0, m), 0.001f)
        assertEquals(1f, AudioOps.duckFactor(listOf(music), music, 5500.0, null), 0.001f)
    }

    @Test fun rippleShiftsLaterItemsWhenAClipIsDeleted() {
        val old = listOf(Range(0, 1000), Range(1000, 3000), Range(3000, 4000))
        val new = listOf(Range(0, 1000), Range(3000, 4000))
        val ch = Ripple.diff(old, new)!!
        assertEquals(1000L, ch.from)
        assertEquals(3000L, ch.oldEnd)
        assertEquals(-2000L, ch.delta)
        assertEquals(500L, Ripple.shift(500L, ch))      // before: untouched
        assertEquals(1000L, Ripple.shift(2000L, ch))    // inside the deleted stretch: pulled to its start
        assertEquals(1500L, Ripple.shift(3500L, ch))    // after: moves back by 2 s
    }

    @Test fun rippleIgnoresReorderAndShiftsLockedNever() {
        val a = listOf(Range(0, 1000), Range(1000, 3000))
        val b = listOf(Range(1000, 3000), Range(0, 1000))
        assertNull(Ripple.diff(a, b))
        val ch = Ripple.diff(a, a + Range(3000, 4000))!!
        val free = Layer(1, 0, 3000L, 3500L)
        val locked = free.copy(id = 2, locked = true)
        val r = Ripple.layers(listOf(free, locked), ch)
        assertEquals(4000L, r[0].startMs)
        assertEquals(3000L, r[1].startMs)
    }

    @Test fun videoKeysInterpolateSmoothlyAndClamp() {
        var fx = Fx()
        fx = VideoKeys.upsert(fx, 1000L, VideoPose(1f, 0f, 0f))
        fx = VideoKeys.upsert(fx, 3000L, VideoPose(3f, 0.5f, -0.5f))
        assertEquals(2, fx.vkeys.size)
        assertEquals(1f, VideoKeys.pose(fx, 0L).zoom, 0.001f)        // before the first key
        assertEquals(3f, VideoKeys.pose(fx, 9000L).zoom, 0.001f)     // after the last key
        assertEquals(2f, VideoKeys.pose(fx, 2000L).zoom, 0.001f)     // halfway = halfway (ease is symmetric)
        assertEquals(0.25f, VideoKeys.pose(fx, 2000L).panX, 0.001f)
        // a key close to an existing one replaces it
        fx = VideoKeys.upsert(fx, 3030L, VideoPose(4f, 0f, 0f))
        assertEquals(2, fx.vkeys.size)
        assertEquals(4f, VideoKeys.pose(fx, 3030L).zoom, 0.001f)
        assertEquals(1, VideoKeys.remove(fx, 3000L).vkeys.size)
        assertTrue(Fx(vkeys = fx.vkeys).hasTransform)
    }

    @Test fun videoWindowCentreIsMiddleWithoutPanAndMovesWithPan() {
        val c0 = VideoKeys.centre(2f, 0f, 0f, 1920, 1080, 1080, 1920)
        assertEquals(0.5f, c0[0], 0.001f)
        assertEquals(0.5f, c0[1], 0.001f)
        val c1 = VideoKeys.centre(2f, 1f, 0f, 1920, 1080, 1080, 1920)
        assertTrue(c1[0] < 0.5f)   // the picture moves right, so the window moves left
        assertEquals(0.5f, c1[1], 0.001f)
    }

    @Test fun cutsUseTheClipsOwnTransitionElseTheProjects() {
        val fx = Fx(trKind = "fade", trMs = 400L)
        val r = listOf(Range(0, 2000), Range(2000, 4000, 1f, TrKind.ZOOM.ordinal, 300L), Range(4000, 6000, 1f, 0))
        assertEquals(TrKind.NONE, Cuts.enter(r, 0, fx).kind)
        assertEquals(TrKind.ZOOM, Cuts.enter(r, 1, fx).kind)
        assertEquals(300L, Cuts.enter(r, 1, fx).ms)
        assertEquals(TrKind.NONE, Cuts.enter(r, 2, fx).kind)       // tr = 0 means "no transition here"
        assertEquals(TrKind.ZOOM, Cuts.exit(r, 0, fx).kind)         // the exit of a clip is the entrance of the next
        assertEquals(TrKind.NONE, Cuts.exit(r, 2, fx).kind)
        val plain = listOf(Range(0, 2000), Range(2000, 4000))
        assertEquals(TrKind.FADE, Cuts.enter(plain, 1, fx).kind)    // project default
        assertEquals(400L, Cuts.enter(plain, 1, fx).ms)
    }

    @Test fun trMathPlaysExitAtTheEndAndEnterAtTheStart() {
        val enter = CutTr(TrKind.FADE, 400L)
        val exit = CutTr(TrKind.SLIDE, 400L)
        val end = TrMath.at(1900L, 2000L, false, false, enter, exit)!!
        assertEquals(TrKind.SLIDE, end.kind)
        assertEquals(1f, end.dir, 0.001f)
        val start = TrMath.at(100L, 2000L, false, false, enter, exit)!!
        assertEquals(TrKind.FADE, start.kind)
        assertEquals(-1f, start.dir, 0.001f)
        assertNull(TrMath.at(1000L, 2000L, false, false, enter, exit))
        assertNull(TrMath.at(100L, 2000L, true, false, enter, exit))   // first clip: no entrance
    }

    @Test fun splitKeepsTheEntranceTransitionOnlyOnTheFirstHalf() {
        val segs = listOf(Range(0, 1000), Range(1000, 3000, 1f, 2, 300L))
        val r = EdlOps.split(segs, 2000L)!!
        assertEquals(2, r.segs[1].tr)
        assertEquals(300L, r.segs[1].trMs)
        assertEquals(-1, r.segs[2].tr)
        assertEquals(0L, r.segs[2].trMs)
    }
}
