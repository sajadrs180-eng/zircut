@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.zircut.ui

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.text.TextPaint
import android.text.TextUtils
import android.view.Surface
import android.view.TextureView
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import app.zircut.MainViewModel
import app.zircut.UiState
import app.zircut.core.CapLayout
import app.zircut.core.CaptionRenderer
import app.zircut.core.CaptionTimeline
import app.zircut.core.ColorGrade
import app.zircut.core.FontStore
import app.zircut.core.Looks
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Planner
import app.zircut.core.Range
import app.zircut.core.Styles
import app.zircut.core.SubStyle
import app.zircut.core.VideoInfo
import app.zircut.core.Word
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.graphics.Paint as AndroidPaint

private enum class EdTab(val label: String, val title: String, val icon: ZI) {
    CAPTIONS("زیرنویس", "زیرنویس‌ها", ZI.Captions),
    STYLE("استایل", "استایل زیرنویس", ZI.Palette),
    FONT("فونت", "فونت زیرنویس", ZI.Type),
    POSITION("جایگاه", "جایگاه و اندازه", ZI.Position),
    FILTER("فیلتر", "فیلتر و رنگ", ZI.Filters),
    EDIT("ادیت", "ویرایش خودکار", ZI.Scissors)
}

private class PlayerHolder {
    var mp: MediaPlayer? = null
    var ready = false
}

private fun outTime(pos: Long, ranges: List<Range>): Long {
    var acc = 0L
    for (r in ranges) {
        if (pos >= r.endMs) {
            acc += r.len
        } else {
            if (pos > r.startMs) acc += pos - r.startMs
            break
        }
    }
    return acc
}

private fun pct(v: Float): String = fa(Math.round(v * 100f)) + "٪"

private fun signed(n: Int): String = when {
    n > 0 -> "+" + fa(n)
    n < 0 -> "−" + fa(-n)
    else -> fa(0)
}

/**
 * Editor: preview on top, a scrolling two-track timeline (video + subtitles) under it,
 * and a tool dock at the bottom. All tools open as a panel above the dock.
 */
@UnstableApi
@Composable
fun EditorScreen(
    ui: UiState,
    vm: MainViewModel,
    onSettings: () -> Unit,
    onPickFont: () -> Unit,
    modifier: Modifier = Modifier
) {
    val info: VideoInfo = ui.info ?: return
    val uri = ui.video ?: return
    val holder = remember { PlayerHolder() }
    var playing by remember { mutableStateOf(false) }
    var posMs by remember { mutableStateOf(0L) }
    var tab by remember { mutableStateOf(EdTab.CAPTIONS) }
    var panelOpen by remember { mutableStateOf(ui.phrases.isNotEmpty()) }
    var showExport by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var tlScale by remember { mutableStateOf(48f) }

    val words = remember(ui.phrases) { ui.phrases.flatMap { it.words } }
    val ranges = remember(words, ui.options, info) { Planner.ranges(words, info.durationMs, ui.options) }
    val kept = ranges.sumOf { it.len }

    fun seek(ms: Long) {
        val t = ms.coerceIn(0L, info.durationMs)
        posMs = t
        val m = holder.mp
        if (m != null && holder.ready) {
            try { m.seekTo(t, MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { }
        }
    }

    fun toggle() {
        val m = holder.mp
        if (m == null || !holder.ready) return
        if (playing) {
            try { m.pause() } catch (_: Exception) { }
            playing = false
        } else {
            if (posMs >= info.durationMs - 150) seek(ranges.firstOrNull()?.startMs ?: 0L)
            try { m.start() } catch (_: Exception) { }
            playing = true
        }
    }

    fun pauseIfPlaying() {
        if (playing) {
            try { holder.mp?.pause() } catch (_: Exception) { }
            playing = false
        }
    }

    fun scrub(ms: Long) {
        pauseIfPlaying()
        seek(ms)
    }

    fun prevCaption() {
        val t = ui.phrases.lastOrNull { it.startMs < posMs - 500 }?.startMs ?: 0L
        seek(t)
    }

    fun nextCaption() {
        val n = ui.phrases.firstOrNull { it.startMs > posMs + 80 }
        if (n != null) seek(n.startMs)
    }

    val rangesNow by rememberUpdatedState(ranges)
    val skipNow by rememberUpdatedState(ui.options.removeSilence)

    LaunchedEffect(Unit) {
        while (true) {
            val v = holder.mp
            if (v != null && holder.ready && playing) {
                val p = try { v.currentPosition.toLong() } catch (_: Exception) { posMs }
                var np = p
                if (skipNow) {
                    val rs = rangesNow
                    val inside = rs.any { p >= it.startMs && p < it.endMs }
                    if (!inside) {
                        val next = rs.firstOrNull { it.startMs > p }
                        if (next != null) {
                            seek(next.startMs)
                            np = next.startMs
                        } else {
                            try { v.pause() } catch (_: Exception) { }
                            playing = false
                        }
                    }
                }
                posMs = np
            }
            delay(33)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            holder.ready = false
            try { holder.mp?.release() } catch (_: Exception) { }
            holder.mp = null
        }
    }

    val appCtx = LocalContext.current
    val style = Styles.byId(ui.styleId)
    val font: Typeface = ui.fonts.firstOrNull { it.id == ui.fontId }?.typeface ?: Typeface.DEFAULT_BOLD
    val timeline = remember(ui.phrases, info) { CaptionTimeline(ui.phrases, listOf(Range(0L, info.durationMs))) }
    val st = if (ui.options.captions) timeline.stateAt(posMs) else null
    val activeIdx = st?.phraseIdx ?: -1

    val va = info.width.toFloat() / info.height
    val aspect = if (ui.options.vertical) 9f / 16f else va
    val renderW = 540
    val renderH = (540f / aspect).toInt()
    val capBmp = remember(st?.phraseIdx, st?.wordIdx, style, font, ui.layout, ui.phrases, aspect) {
        if (st == null || st.phraseIdx !in ui.phrases.indices) null
        else try {
            CaptionRenderer(renderW, renderH, style, font, ui.layout).render(ui.phrases[st.phraseIdx], st.wordIdx)
        } catch (e: Throwable) {
            null
        }
    }
    val curRange = ranges.indexOfFirst { posMs >= it.startMs && posMs < it.endMs }
    val zoom = if (ui.options.zoom && curRange % 2 == 1) 1.18f else 1f

    val screenH = LocalConfiguration.current.screenHeightDp
    val panelH = (screenH * 0.29f).dp.coerceIn(190.dp, 270.dp)

    Column(modifier.fillMaxWidth()) {
        // ================= top bar =================
        Row(
            Modifier.fillMaxWidth().height(56.dp).padding(horizontal = Z.S3),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ZIconButton(ZI.Arrow, { vm.reset() })
            Spacer(Modifier.width(Z.S1))
            Column(Modifier.weight(1f).press(true) { showRename = true }) {
                Txt(ui.projectName.ifBlank { "ویرایش" }, style = ZType.heading, maxLines = 1)
                val saveLabel = when (ui.saveStatus) {
                    "saving" -> "در حال ذخیره…"
                    "saved" -> "ذخیره شد"
                    "error" -> "ذخیره نشد"
                    else -> ""
                }
                Txt(
                    listOf(saveLabel, if (ui.options.vertical) "۹:۱۶" else "اندازه اصلی", faTime(kept))
                        .filter { it.isNotEmpty() }.joinToString("  ·  "),
                    style = ZType.caption, color = if (ui.saveStatus == "error") Z.Danger else Z.TextSec, maxLines = 1
                )
            }
            ZIconButton(ZI.Tune, onSettings)
            Spacer(Modifier.width(Z.S1))
            ZButton("خروجی", { pauseIfPlaying(); showExport = true }, icon = ZI.Export, compact = true)
        }

        // ================= preview =================
        BoxWithConstraints(
            Modifier.fillMaxWidth().weight(1f).padding(horizontal = Z.S3, vertical = Z.S1),
            contentAlignment = Alignment.Center
        ) {
            var fw: Dp = maxWidth
            var fh: Dp = fw / aspect
            if (fh > maxHeight) {
                fh = maxHeight
                fw = fh * aspect
            }
            val cw: Dp
            val ch: Dp
            if (va >= aspect) {
                ch = fh
                cw = fh * va
            } else {
                cw = fw
                ch = fw / va
            }
            Box(
                Modifier.size(fw, fh).clip(RoundedCornerShape(Z.RXs)).background(Color.Black)
                    .border(Z.Hair, Z.Border, RoundedCornerShape(Z.RXs))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { toggle() },
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { c ->
                        TextureView(c).apply {
                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                override fun onSurfaceTextureAvailable(t: SurfaceTexture, w: Int, h: Int) {
                                    try {
                                        val m = MediaPlayer()
                                        m.setDataSource(appCtx, uri)
                                        m.setSurface(Surface(t))
                                        m.setOnPreparedListener { p ->
                                            holder.ready = true
                                            try { p.seekTo(1L, MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { }
                                        }
                                        m.setOnCompletionListener { playing = false }
                                        holder.mp = m
                                        m.prepareAsync()
                                    } catch (_: Exception) {
                                    }
                                }

                                override fun onSurfaceTextureSizeChanged(t: SurfaceTexture, w: Int, h: Int) {}

                                override fun onSurfaceTextureDestroyed(t: SurfaceTexture): Boolean {
                                    holder.ready = false
                                    try { holder.mp?.release() } catch (_: Exception) { }
                                    holder.mp = null
                                    return true
                                }

                                override fun onSurfaceTextureUpdated(t: SurfaceTexture) {}
                            }
                        }
                    },
                    modifier = Modifier.requiredSize(cw, ch).graphicsLayer { scaleX = zoom; scaleY = zoom },
                    update = { v -> applyGrade(v, ui.grade) }
                )
                Canvas(Modifier.fillMaxSize()) {
                    val b = capBmp
                    if (b != null && st != null) {
                        val img = b.asImageBitmap()
                        val k = size.width / renderW
                        val w = img.width * k
                        val h = img.height * k
                        val cx = ui.layout.x * size.width
                        val cy = ui.layout.y * size.height
                        val sc = if (style.pop) st.pop else 1f
                        val al = if (style.fade) minOf(1f, st.tMs / 220f) else 1f
                        scale(sc, Offset(cx, cy)) {
                            drawImage(
                                img,
                                dstOffset = IntOffset((cx - w / 2f).toInt(), (cy - h / 2f).toInt()),
                                dstSize = IntSize(w.toInt(), h.toInt()),
                                alpha = al
                            )
                        }
                    }
                }
                if (!playing) {
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(Color(0x99000000))
                            .border(1.dp, Color(0x33FFFFFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) { ZIcon(ZI.Play, tint = Color.White, size = 26.dp) }
                }
            }
        }

        // ================= word strip =================
        WordStrip(words, posMs) { t -> scrub(t) }

        // ================= transport =================
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                Modifier.fillMaxWidth().height(52.dp).padding(horizontal = Z.S3),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Txt(faTime(outTime(posMs, ranges)), style = ZType.mono, size = 13.sp)
                    Txt("  /  ", style = ZType.mono, color = Z.TextTer, size = 13.sp)
                    Txt(faTime(kept), style = ZType.mono, color = Z.TextSec, size = 13.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(Z.S2), verticalAlignment = Alignment.CenterVertically) {
                    ZIconButton(ZI.SkipPrev, { prevCaption() }, enabled = ui.phrases.isNotEmpty(), size = 20.dp)
                    ZIconButton(
                        if (playing) ZI.Pause else ZI.Play, { toggle() },
                        bg = Z.Text, tint = Z.Bg, box = 44.dp, size = 22.dp, round = true
                    )
                    ZIconButton(ZI.SkipNext, { nextCaption() }, enabled = ui.phrases.isNotEmpty(), size = 20.dp)
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    ZIconButton(ZI.Minus, { tlScale = (tlScale / 1.4f).coerceAtLeast(14f) }, size = 18.dp, box = 36.dp, tint = Z.TextSec)
                    ZIconButton(ZI.Plus, { tlScale = (tlScale * 1.4f).coerceAtMost(220f) }, size = 18.dp, box = 36.dp, tint = Z.TextSec)
                }
            }
        }

        // ================= timeline =================
        Timeline(
            durMs = info.durationMs,
            posMs = posMs,
            ranges = ranges,
            phrases = ui.phrases,
            scale = tlScale,
            onScale = { tlScale = it },
            onScrub = { scrub(it) },
            onPhrase = { i ->
                if (i in ui.phrases.indices) {
                    scrub(ui.phrases[i].startMs)
                    tab = EdTab.CAPTIONS
                    panelOpen = true
                }
            },
            activeIdx = activeIdx
        )

        // ================= tool panel =================
        AnimatedVisibility(
            visible = panelOpen,
            enter = expandVertically(tween(220)) + fadeIn(tween(220)),
            exit = shrinkVertically(tween(180)) + fadeOut(tween(120))
        ) {
            Column(Modifier.fillMaxWidth().height(panelH).background(Z.Surface)) {
                ZHairline()
                Row(
                    Modifier.fillMaxWidth().height(44.dp).padding(horizontal = Z.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Txt(tab.title, style = ZType.heading, modifier = Modifier.weight(1f), maxLines = 1)
                    if (tab == EdTab.CAPTIONS && ui.phrases.isNotEmpty()) {
                        Txt(fa(ui.phrases.size) + " بخش", style = ZType.caption, color = Z.TextSec)
                        Spacer(Modifier.width(Z.S2))
                    }
                    ZIconButton(ZI.Chevron, { panelOpen = false }, tint = Z.TextSec, box = 36.dp, size = 20.dp)
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(start = Z.S4, end = Z.S4, bottom = Z.S3)) {
                    when (tab) {
                        EdTab.CAPTIONS -> CaptionsPanel(
                            phrases = ui.phrases,
                            activeIdx = activeIdx,
                            onSeek = { t -> scrub(t) },
                            onEdit = { i, t -> vm.editPhrase(i, t) },
                            onMerge = { vm.mergeWithNext(it) },
                            onDelete = { vm.deletePhrase(it) },
                            onGenerate = { vm.startCaptions() }
                        )
                        EdTab.STYLE -> StylePanel(ui) { vm.setStyle(it) }
                        EdTab.FONT -> FontPanel(ui.fonts, ui.fontId, { vm.setFont(it) }, onPickFont)
                        EdTab.POSITION -> PositionPanel(ui.layout) { vm.setLayout(it) }
                        EdTab.FILTER -> FilterPanel(ui.video, ui.grade) { vm.setGrade(it) }
                        EdTab.EDIT -> EditPanel(ui.options, info, kept) { vm.setOptions(it) }
                    }
                }
            }
        }

        // ================= tool dock =================
        Column(Modifier.fillMaxWidth().background(Z.Surface)) {
            ZHairline()
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal = Z.S2)) {
                // Nothing is processed when the video opens. This button starts the speech recognition.
                if (ui.phrases.isEmpty()) {
                    ToolItem(ZI.Wave, "خودکار", selected = false, action = true, modifier = Modifier.weight(1f)) { vm.startCaptions() }
                }
                EdTab.values().forEach { t ->
                    ToolItem(t.icon, t.label, selected = panelOpen && tab == t, action = false, modifier = Modifier.weight(1f)) {
                        if (panelOpen && tab == t) {
                            panelOpen = false
                        } else {
                            tab = t
                            panelOpen = true
                        }
                    }
                }
            }
        }
    }

    if (showRename) {
        RenameDialog(
            initial = ui.projectName,
            onConfirm = { vm.renameProject(ui.projectId, it); showRename = false },
            onDismiss = { showRename = false }
        )
    }

    if (showExport) {
        ExportSheet(
            opt = ui.options,
            phraseCount = ui.phrases.size,
            original = info.durationMs,
            kept = kept,
            onOptions = { vm.setOptions(it) },
            onDismiss = { showExport = false },
            onExport = {
                showExport = false
                vm.export()
            }
        )
    }
}

// =====================================================================================
//  Dock
// =====================================================================================

@Composable
private fun ToolItem(icon: ZI, label: String, selected: Boolean, action: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val tint by animateColorAsState(if (selected || action) Z.Accent else Z.TextSec, tween(160), label = "toolTint")
    val iconTint = if (action) Z.OnAccent else tint
    val bg by animateColorAsState(
        if (action) Z.Accent else if (selected) Z.AccentSoft else Color.Transparent, tween(160), label = "toolBg"
    )
    Column(
        modifier.fillMaxHeight().press(true, onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(width = 44.dp, height = 30.dp).clip(RoundedCornerShape(9.dp)).background(bg),
            contentAlignment = Alignment.Center
        ) { ZIcon(icon, tint = iconTint, size = 20.dp) }
        Spacer(Modifier.height(3.dp))
        Txt(label, style = ZType.micro, color = tint, maxLines = 1)
    }
}

// =====================================================================================
//  Word strip: every word is a pill, tap to jump, the current one follows the playhead
// =====================================================================================

@Composable
private fun WordStrip(words: List<Word>, posMs: Long, onSeek: (Long) -> Unit) {
    if (words.isEmpty()) return
    var lo = 0
    var hi = words.size - 1
    var cur = 0
    while (lo <= hi) {
        val m = (lo + hi) / 2
        if (words[m].startMs <= posMs) { cur = m; lo = m + 1 } else hi = m - 1
    }
    val state = rememberLazyListState()
    LaunchedEffect(cur) { state.animateScrollToItem((cur - 1).coerceAtLeast(0)) }
    LazyRow(
        state = state,
        modifier = Modifier.fillMaxWidth().height(40.dp),
        contentPadding = PaddingValues(horizontal = Z.S3),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        itemsIndexed(words) { i, w ->
            val sel = i == cur
            val bg by animateColorAsState(if (sel) Z.Accent else Z.Surface2, tween(120), label = "wordBg")
            Box(
                Modifier.clip(RoundedCornerShape(8.dp)).background(bg)
                    .press(true) { onSeek(w.startMs) }
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Txt(w.text, style = if (sel) ZType.labelStrong else ZType.label, color = if (sel) Z.OnAccent else Z.TextSec, maxLines = 1)
            }
        }
    }
}

// =====================================================================================
//  Timeline: playhead fixed in the middle, content scrolls under it.
//  Drag = scrub, pinch = zoom, tap a subtitle block = select it.
// =====================================================================================

@Composable
private fun Timeline(
    durMs: Long,
    posMs: Long,
    ranges: List<Range>,
    phrases: List<Phrase>,
    activeIdx: Int,
    scale: Float,
    onScale: (Float) -> Unit,
    onScrub: (Long) -> Unit,
    onPhrase: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val paint = remember {
        TextPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply { typeface = ZFont.typeface(ctx, 500) ?: Typeface.DEFAULT }
    }
    val scrubCb by rememberUpdatedState(onScrub)
    val scaleCb by rememberUpdatedState(onScale)
    val phraseCb by rememberUpdatedState(onPhrase)
    val scaleNow by rememberUpdatedState(scale)
    val phrasesNow by rememberUpdatedState(phrases)
    val live = remember { floatArrayOf(0f) }
    live[0] = posMs.toFloat()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Canvas(
            Modifier.fillMaxWidth().height(110.dp)
                .pointerInput(durMs) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (zoom != 1f) scaleCb((scaleNow * zoom).coerceIn(14f, 220f))
                        if (pan.x != 0f) {
                            val pxMs = scaleNow * density / 1000f
                            val t = (live[0] - pan.x / pxMs).coerceIn(0f, durMs.toFloat())
                            live[0] = t
                            scrubCb(t.toLong())
                        }
                    }
                }
                .pointerInput(durMs) {
                    detectTapGestures { o ->
                        val pxMs = scaleNow * density / 1000f
                        val ms = (live[0] + (o.x - size.width / 2f) / pxMs).coerceIn(0f, durMs.toFloat()).toLong()
                        var hit = -1
                        if (o.y >= 60f * density) {
                            val list = phrasesNow
                            for (i in list.indices) {
                                if (ms >= list[i].startMs && ms <= list[i].endMs) { hit = i; break }
                            }
                        }
                        if (hit >= 0) phraseCb(hit) else scrubCb(ms)
                    }
                }
        ) {
            val d = density
            val w = size.width
            val h = size.height
            val pxMs = scale * d / 1000f
            val cx = w / 2f
            val pos = posMs
            fun xOf(ms: Long): Float = cx + (ms - pos) * pxMs

            val lane1Top = 26f * d
            val laneH = 32f * d
            val lane2Top = 64f * d
            val r = CornerRadius(5f * d, 5f * d)

            // lanes
            drawRect(Z.Surface, Offset(0f, lane1Top), Size(w, laneH))
            drawRect(Z.Surface, Offset(0f, lane2Top), Size(w, laneH))

            // ---- ruler ----
            val stepsSec = intArrayOf(1, 2, 5, 10, 15, 30, 60, 120, 300, 600)
            var stepSec = 600
            for (s in stepsSec) {
                if (s * 1000f * pxMs >= 70f * d) { stepSec = s; break }
            }
            val stepMs = stepSec * 1000L
            val visStart = (pos - cx / pxMs).toLong()
            val visEnd = (pos + cx / pxMs).toLong()
            var t = (maxOf(0L, visStart - stepMs) / stepMs) * stepMs
            paint.textSize = 10.5f * d
            paint.textAlign = AndroidPaint.Align.LEFT
            paint.color = Z.TextTer.toArgb()
            while (t <= minOf(durMs, visEnd + stepMs)) {
                val x = xOf(t)
                drawLine(Z.BorderStrong, Offset(x, 17f * d), Offset(x, 24f * d), strokeWidth = 1f * d)
                val label = faTime(t)
                drawIntoCanvas { it.nativeCanvas.drawText(label, x + 8f * d, 13f * d, paint) }
                if (t + stepMs / 2 <= durMs) {
                    val mx = xOf(t + stepMs / 2)
                    drawLine(Z.Border, Offset(mx, 20f * d), Offset(mx, 24f * d), strokeWidth = 1f * d)
                }
                t += stepMs
            }

            // ---- video track ----
            for (rg in ranges) {
                val x1 = xOf(rg.startMs)
                val x2 = xOf(rg.endMs)
                if (x2 < 0f || x1 > w) continue
                val bw = maxOf(3f * d, x2 - x1)
                drawRoundRect(Color(0xFF15384A), Offset(x1, lane1Top), Size(bw, laneH), r)
                drawRoundRect(Z.AccentLine, Offset(x1, lane1Top), Size(bw, laneH), r, style = Stroke(1f * d))
                val tx = minOf(x1 + bw, w) - 8f * d
                if (tx - maxOf(x1, 0f) > 48f * d) {
                    paint.textSize = 11f * d
                    paint.textAlign = AndroidPaint.Align.RIGHT
                    paint.color = Z.Accent.toArgb()
                    drawIntoCanvas { it.nativeCanvas.drawText("ویدیو", tx, lane1Top + laneH / 2f + 4f * d, paint) }
                }
            }

            // ---- subtitle track ----
            if (phrases.isEmpty()) {
                paint.textSize = 11.5f * d
                paint.textAlign = AndroidPaint.Align.CENTER
                paint.color = Z.TextTer.toArgb()
                drawIntoCanvas { it.nativeCanvas.drawText("هنوز زیرنویسی ساخته نشده", cx, lane2Top + laneH / 2f + 4f * d, paint) }
            } else {
                for ((i, p) in phrases.withIndex()) {
                    val x1 = xOf(p.startMs) + 1f * d
                    val x2 = xOf(p.endMs) - 1f * d
                    if (x2 < 0f || x1 > w) continue
                    val bw = maxOf(4f * d, x2 - x1)
                    val active = i == activeIdx
                    drawRoundRect(if (active) Z.Accent else Z.Surface3, Offset(x1, lane2Top), Size(bw, laneH), r)
                    if (!active) drawRoundRect(Z.BorderStrong, Offset(x1, lane2Top), Size(bw, laneH), r, style = Stroke(1f * d))
                    if (bw > 30f * d) {
                        paint.textSize = 12f * d
                        paint.textAlign = AndroidPaint.Align.RIGHT
                        paint.color = if (active) Z.OnAccent.toArgb() else Z.Text.toArgb()
                        val avail = bw - 14f * d
                        val shown = TextUtils.ellipsize(p.text.replace("*", ""), paint, avail, TextUtils.TruncateAt.END).toString()
                        drawIntoCanvas { it.nativeCanvas.drawText(shown, x1 + bw - 7f * d, lane2Top + laneH / 2f + 4.2f * d, paint) }
                    }
                    if (p.words.any { it.conf < 0.5f }) {
                        drawCircle(Z.Warn, 3f * d, Offset(x1 + 6f * d, lane2Top + 6f * d))
                    }
                }
            }

            // ---- outside the clip: dim ----
            val x0 = xOf(0L)
            val xe = xOf(durMs)
            val dim = Color(0xCC0A0B0D)
            if (x0 > 0f) drawRect(dim, Offset(0f, 0f), Size(minOf(x0, w), h))
            if (xe < w) {
                val sx = maxOf(xe, 0f)
                drawRect(dim, Offset(sx, 0f), Size(w - sx, h))
            }

            // ---- playhead ----
            drawLine(Z.Text, Offset(cx, 0f), Offset(cx, h), strokeWidth = 1.5f * d)
            val head = Path().apply {
                moveTo(cx - 5.5f * d, 0f)
                lineTo(cx + 5.5f * d, 0f)
                lineTo(cx + 5.5f * d, 6f * d)
                lineTo(cx, 11f * d)
                lineTo(cx - 5.5f * d, 6f * d)
                close()
            }
            drawPath(head, Z.Text)
        }
    }
}

// =====================================================================================
//  Panels
// =====================================================================================

@Composable
private fun CaptionsPanel(
    phrases: List<Phrase>,
    activeIdx: Int,
    onSeek: (Long) -> Unit,
    onEdit: (Int, String) -> Unit,
    onMerge: (Int) -> Unit,
    onDelete: (Int) -> Unit,
    onGenerate: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(activeIdx) {
        if (activeIdx in phrases.indices) listState.animateScrollToItem(activeIdx)
    }
    if (phrases.isEmpty()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(Z.RSm)).background(Z.AccentSoft), contentAlignment = Alignment.Center) {
                ZIcon(ZI.Wave, tint = Z.Accent, size = Z.IconMd)
            }
            Spacer(Modifier.height(Z.S2))
            Txt("هنوز زیرنویسی ساخته نشده", style = ZType.labelStrong)
            Txt(
                "با تشخیص گفتار، زیرنویس خودکار ساخته می‌شه. اگه نسازی، ویدیو بدون زیرنویس خروجی می‌گیره.",
                style = ZType.caption, color = Z.TextSec, align = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(Z.S3))
            ZButton("ساخت زیرنویس خودکار", onGenerate, icon = ZI.Wave, compact = true)
        }
        return
    }
    LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(Z.S2), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(phrases) { i, p ->
            var t by remember(p.startMs, p.words.size) { mutableStateOf(p.text) }
            var editIdx by remember(p.startMs, p.words.size) { mutableStateOf(-1) }
            var wordText by remember { mutableStateOf("") }
            var focused by remember { mutableStateOf(false) }
            val active = i == activeIdx
            val shape = RoundedCornerShape(Z.RSm)
            val line by animateColorAsState(
                if (focused) Z.Accent else if (active) Z.AccentLine else Z.Border, tween(140), label = "capLine"
            )
            Column(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (active) Color(0xFF12202A) else Z.Surface2)
                    .border(Z.Hair, line, shape)
                    .padding(horizontal = Z.S2, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.clip(RoundedCornerShape(7.dp)).background(if (active) Z.AccentSoft else Z.Surface3)
                            .press(true) { onSeek(p.startMs) }.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) { Txt(faTime(p.startMs), style = ZType.mono, color = if (active) Z.Accent else Z.TextSec) }
                    Spacer(Modifier.width(Z.S2))
                    BasicTextField(
                        value = t,
                        onValueChange = { t = it; onEdit(i, it) },
                        textStyle = ZType.body.copy(color = Z.Text),
                        cursorBrush = SolidColor(Z.Accent),
                        modifier = Modifier.weight(1f).onFocusChanged {
                            focused = it.isFocused
                            if (it.isFocused) onSeek(p.startMs)
                        }
                    )
                    if (i < phrases.size - 1) {
                        ZIconButton(ZI.Merge, { onMerge(i) }, tint = Z.TextSec, box = 34.dp, size = 18.dp)
                    }
                    ZIconButton(ZI.Trash, { onDelete(i) }, tint = Z.Danger, box = 34.dp, size = 18.dp)
                }
                val bad = p.words.withIndex().filter { it.value.conf < 0.5f }
                if (bad.isNotEmpty()) {
                    androidx.compose.foundation.layout.FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Txt("احتمال خطا:", style = ZType.caption, color = Z.Warn, modifier = Modifier.padding(top = 3.dp))
                        bad.forEach { iv ->
                            Box(
                                Modifier.clip(RoundedCornerShape(7.dp)).background(Z.WarnSoft)
                                    .press(true) { editIdx = iv.index; wordText = iv.value.text }
                                    .padding(horizontal = 10.dp, vertical = 3.dp)
                            ) { Txt(iv.value.text, style = ZType.label, color = Z.Warn) }
                        }
                    }
                }
            }
            if (editIdx >= 0 && editIdx < p.words.size) {
                AlertDialog(
                    onDismissRequest = { editIdx = -1 },
                    containerColor = Z.Surface2,
                    shape = RoundedCornerShape(Z.RMd),
                    title = { Txt("اصلاح کلمه", style = ZType.heading) },
                    text = { ZField(wordText, { wordText = it }, singleLine = true) },
                    confirmButton = {
                        ZButton("تأیید", {
                            val nt = p.words.mapIndexed { k, w -> if (k == editIdx) wordText.trim() else w.text }
                                .filter { it.isNotEmpty() }.joinToString(" ")
                            t = nt
                            onEdit(i, nt)
                            editIdx = -1
                        }, compact = true)
                    },
                    dismissButton = { ZButton("لغو", { editIdx = -1 }, kind = ZBtn.Ghost, compact = true) }
                )
            }
        }
    }
}

@Composable
private fun StylePanel(ui: UiState, onPick: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Z.S3)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
            items(Styles.all, key = { it.id }) { s ->
                StyleCard(s, ui.styleId == s.id, ui.fonts.firstOrNull { it.name == s.font }?.typeface) { onPick(s.id) }
            }
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(Z.RSm)).background(Z.Surface2).padding(Z.S3),
            verticalAlignment = Alignment.Top
        ) {
            ZIcon(ZI.Info, tint = Z.TextSec, size = Z.IconSm, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.width(Z.S2))
            Txt(
                "اگه اول یک کلمه در متن زیرنویس * بذاری، اون کلمه با رنگ تاکیدی نشون داده می‌شه.",
                style = ZType.caption, color = Z.TextSec
            )
        }
    }
}

/** A real typography preset: the card is rendered by the same CaptionRenderer that exports the video. */
@Composable
private fun StyleCard(s: SubStyle, selected: Boolean, tf: Typeface?, onClick: () -> Unit) {
    val bmp = remember(s.id, tf) {
        try {
            val ph = Phrase(listOf(Word("سلام", 0L, 400L), Word("دنیا", 400L, 800L)))
            CaptionRenderer(240, 150, s, tf ?: Typeface.DEFAULT_BOLD, CapLayout(x = 0.5f, y = 0.5f, mw = 0.92f, ls = 1.5f, lw = 4, size = 2.3f))
                .render(ph, 1)
        } catch (e: Throwable) {
            null
        }
    }
    val shape = RoundedCornerShape(Z.RSm)
    val line by animateColorAsState(if (selected) Z.Accent else Z.Border, tween(160), label = "styleLine")
    Column(Modifier.width(112.dp).press(true, onClick), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.fillMaxWidth().height(74.dp).clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF474E5C), Color(0xFF242932))))
                .border(if (selected) 1.5.dp else Z.Hair, line, shape),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    bitmap = b.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    contentScale = ContentScale.Fit
                )
            }
            if (selected) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(5.dp).size(16.dp).clip(CircleShape).background(Z.Accent),
                    contentAlignment = Alignment.Center
                ) { ZIcon(ZI.Check, tint = Z.OnAccent, size = 12.dp) }
            }
        }
        Column {
            Txt(s.nameFa, style = ZType.labelStrong, color = if (selected) Z.Text else Z.TextSec, maxLines = 1)
            Txt(s.font.substringBefore('-'), style = ZType.micro, color = Z.TextTer, maxLines = 1)
        }
    }
}

@Composable
private fun FontPanel(fonts: List<FontStore.Font>, selectedId: String, onPick: (String) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(Z.S2)) {
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(fonts, key = { it.id }) { f ->
                val sel = f.id == selectedId
                val shape = RoundedCornerShape(Z.RSm)
                val line by animateColorAsState(if (sel) Z.AccentLine else Z.Border, tween(140), label = "fontLine")
                Row(
                    Modifier.fillMaxWidth().height(48.dp).clip(shape)
                        .background(if (sel) Z.AccentSoft else Z.Surface2)
                        .border(Z.Hair, line, shape)
                        .press(true) { onPick(f.id) }.padding(horizontal = Z.S3),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ZRadioDot(sel)
                    Spacer(Modifier.width(Z.S3))
                    Column(Modifier.weight(1f)) {
                        Txt(f.name, style = ZType.label, color = if (sel) Z.Text else Z.TextSec, maxLines = 1)
                        if (!f.persianOk) Txt("بدون حروف فارسی", style = ZType.micro, color = Z.Warn, maxLines = 1)
                    }
                    Text(
                        if (f.persianOk) "سلام دنیا" else "Aa Bb",
                        style = TextStyle(fontFamily = FontFamily(f.typeface), fontSize = 19.sp),
                        color = Z.Text,
                        maxLines = 1
                    )
                }
            }
        }
        ZButton("افزودن فونت (.ttf / .otf)", onAdd, Modifier.fillMaxWidth(), kind = ZBtn.Secondary, icon = ZI.Plus, compact = true)
    }
}

@Composable
private fun TwoCols(a: @Composable () -> Unit, b: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Z.S5)) {
        Box(Modifier.weight(1f)) { a() }
        Box(Modifier.weight(1f)) { b() }
    }
}

@Composable
private fun PositionPanel(layout: CapLayout, onLayout: (CapLayout) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Z.S2)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(Z.S2)) {
            items(listOf("بالا" to 0.2f, "بالا‌میانه" to 0.36f, "وسط" to 0.5f, "پایین ایمن" to 0.66f, "خیلی پایین" to 0.82f)) { (n, y) ->
                ZChip(n, kotlin.math.abs(layout.y - y) < 0.02f, { onLayout(layout.copy(y = y)) })
            }
        }
        TwoCols(
            { ZSlider("اندازه", layout.size, 0.6f, 1.5f, { onLayout(layout.copy(size = it)) }, readout = ::pct) },
            { ZSlider("عرض متن", layout.mw, 0.4f, 0.96f, { onLayout(layout.copy(mw = it)) }, readout = ::pct) }
        )
        TwoCols(
            { ZSlider("جای عمودی", layout.y, 0.08f, 0.94f, { onLayout(layout.copy(y = it)) }, readout = ::pct) },
            { ZSlider("جای افقی", layout.x, 0.1f, 0.9f, { onLayout(layout.copy(x = it)) }, readout = ::pct) }
        )
        TwoCols(
            { ZSlider("فاصله خطوط", layout.ls, 1.1f, 2f, { onLayout(layout.copy(ls = it)) }, readout = { fa(Math.round(it * 10f)).let { s -> s.dropLast(1) + "٫" + s.last() } }) },
            { ZSlider("کلمه در هر خط", layout.lw.toFloat(), 1f, 6f, { onLayout(layout.copy(lw = it.toInt())) }, steps = 4) }
        )
    }
}

@Composable
private fun EditPanel(opt: Options, info: VideoInfo, kept: Long, onOptions: (Options) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Z.S1)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
            ZStat("مدت اصلی", faTime(info.durationMs), Modifier.weight(1f))
            ZStat("بعد از ادیت", faTime(kept), Modifier.weight(1f), highlight = true)
        }
        OptionToggles(opt, onOptions)
    }
}

@Composable
internal fun OptionToggles(opt: Options, onOptions: (Options) -> Unit) {
    ZToggleRow(ZI.Captions, "زیرنویس", "نمایش زیرنویس روی ویدیو", opt.captions) { onOptions(opt.copy(captions = it)) }
    ZToggleRow(ZI.Scissors, "حذف سکوت‌ها", "بخش‌های بی‌صدا برش می‌خورن", opt.removeSilence) { onOptions(opt.copy(removeSilence = it)) }
    ZToggleRow(ZI.Expand, "زوم ریتمی", "حرکت ملایم روی برش‌ها", opt.zoom) { onOptions(opt.copy(zoom = it)) }
    ZToggleRow(ZI.Phone, "خروجی عمودی (۹:۱۶)", "مناسب ریلز، شورت و استوری", opt.vertical) { onOptions(opt.copy(vertical = it)) }
}

/** Live preview of the color grade: the same matrix the exporter uses is applied to the video surface. */
private fun applyGrade(v: View, g: ColorGrade) {
    if (v.tag == g) return
    v.tag = g
    if (g.isIdentity) {
        v.setLayerType(View.LAYER_TYPE_NONE, null)
        return
    }
    val p = android.graphics.Paint()
    p.colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix(g.affine().toColorMatrix()))
    v.setLayerType(View.LAYER_TYPE_HARDWARE, p)
}

@Composable
private fun FilterPanel(video: android.net.Uri?, grade: ColorGrade, onGrade: (ColorGrade) -> Unit) {
    val ctx = LocalContext.current
    val frame by produceState<Bitmap?>(null, video) {
        value = withContext(Dispatchers.IO) {
            val src = video ?: return@withContext null
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, src)
                val b = r.getFrameAtTime(1_000_000L)
                r.release()
                if (b == null) null else {
                    val k = 160f / maxOf(b.width, b.height)
                    Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true)
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Z.S2)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
            items(Looks.all, key = { it.id }) { look ->
                val sel = grade.lookId == look.id
                val m = ColorGrade(lookId = look.id).affine().toColorMatrix()
                val shape = RoundedCornerShape(Z.RSm)
                val line by animateColorAsState(if (sel) Z.Accent else Z.Border, tween(140), label = "lookLine")
                Column(
                    Modifier.press(true) { onGrade(grade.copy(lookId = look.id)) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        Modifier.size(width = 58.dp, height = 76.dp).clip(shape).background(Z.Surface3)
                            .border(if (sel) 1.5.dp else Z.Hair, line, shape)
                    ) {
                        val b = frame
                        if (b != null) {
                            Image(
                                bitmap = b.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.matchParentSize(),
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m))
                            )
                        }
                    }
                    Txt(look.nameFa, style = ZType.micro, color = if (sel) Z.Text else Z.TextSec, maxLines = 1)
                }
            }
        }
        if (grade.lookId != "none") {
            ZSlider("شدت فیلتر", grade.strength, 0f, 1f, { onGrade(grade.copy(strength = it)) }, readout = ::pct)
        }
        TwoCols(
            { ZSlider("روشنایی", grade.brightness, -0.3f, 0.3f, { onGrade(grade.copy(brightness = it)) }, readout = { signed(Math.round(it / 0.3f * 100f)) }) },
            { ZSlider("کنتراست", grade.contrast, 0.6f, 1.6f, { onGrade(grade.copy(contrast = it)) }, readout = { signed(Math.round((it - 1f) * 100f)) }) }
        )
        TwoCols(
            { ZSlider("اشباع رنگ", grade.saturation, 0f, 2f, { onGrade(grade.copy(saturation = it)) }, readout = { signed(Math.round((it - 1f) * 100f)) }) },
            { ZSlider("محو", grade.fade, 0f, 0.3f, { onGrade(grade.copy(fade = it)) }, readout = { pct(it / 0.3f) }) }
        )
        TwoCols(
            { ZSlider("گرمی / سردی", grade.warmth, -1f, 1f, { onGrade(grade.copy(warmth = it)) }, readout = { signed(Math.round(it * 100f)) }) },
            { ZSlider("سبز / سرخ", grade.tint, -1f, 1f, { onGrade(grade.copy(tint = it)) }, readout = { signed(Math.round(it * 100f)) }) }
        )
        ZButton("برگرداندن همه به حالت اصلی", { onGrade(ColorGrade()) }, Modifier.fillMaxWidth(), kind = ZBtn.Secondary, icon = ZI.Undo, compact = true)
    }
}

// =====================================================================================
//  Export sheet
// =====================================================================================

@Composable
private fun ExportSheet(
    opt: Options,
    phraseCount: Int,
    original: Long,
    kept: Long,
    onOptions: (Options) -> Unit,
    onDismiss: () -> Unit,
    onExport: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Z.Surface,
        shape = RoundedCornerShape(topStart = Z.RLg, topEnd = Z.RLg),
        dragHandle = { ZSheetHandle() }
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = Z.S5).padding(bottom = Z.S6),
                verticalArrangement = Arrangement.spacedBy(Z.S3)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Txt("خروجی ویدیو", style = ZType.title)
                        Txt("گزینه‌ها رو بررسی کن و ویدیو رو بساز.", style = ZType.caption, color = Z.TextSec)
                    }
                    ZIconButton(ZI.Close, onDismiss, tint = Z.TextSec)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Z.S3)) {
                    ZStat("قالب", if (opt.vertical) "۹:۱۶ عمودی" else "اندازه اصلی", Modifier.weight(1f))
                    ZStat("مدت نهایی", faTime(kept), Modifier.weight(1f), highlight = true)
                    ZStat("زیرنویس", if (opt.captions && phraseCount > 0) fa(phraseCount) + " بخش" else "ندارد", Modifier.weight(1f))
                }
                Column { OptionToggles(opt, onOptions) }
                if (opt.captions && phraseCount == 0) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(Z.RSm)).background(Z.WarnSoft).padding(Z.S3),
                        verticalAlignment = Alignment.Top
                    ) {
                        ZIcon(ZI.Info, tint = Z.Warn, size = Z.IconSm, modifier = Modifier.padding(top = 2.dp))
                        Spacer(Modifier.width(Z.S2))
                        Txt(
                            "هنوز زیرنویسی ساخته نشده؛ ویدیو بدون زیرنویس ساخته می‌شه.",
                            style = ZType.caption, color = Z.Warn
                        )
                    }
                }
                if (original > 0 && kept < original) {
                    Txt(
                        "از " + faTime(original) + " به " + faTime(kept) + " کوتاه شد.",
                        style = ZType.caption, color = Z.TextSec
                    )
                }
                ZButton("ساخت ویدیو", onExport, Modifier.fillMaxWidth(), icon = ZI.Export)
            }
        }
    }
}
