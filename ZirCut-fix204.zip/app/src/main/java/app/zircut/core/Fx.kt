package app.zircut.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader

/**
 * Whole-video visual effects.
 * vignette / grain / bars / leak: pictures drawn over the video (same in preview and export).
 * blur .. shadows: custom GPU shader (core/GpuFx.kt), export only (blur also shows in the preview on Android 12+).
 * trKind / trMs: transition at every cut between two clips (core/GpuFx.kt).
 */
data class Fx(
    val vignette: Float = 0f,
    val grain: Float = 0f,
    /** cinema bars (black bands at top and bottom) */
    val bars: Float = 0f,
    /** warm light leak from the side */
    val leak: Float = 0f,
    val blur: Float = 0f,
    val sharpen: Float = 0f,
    /** RGB channel split (chromatic aberration) */
    val split: Float = 0f,
    val glitch: Float = 0f,
    val noise: Float = 0f,
    /** glow / bloom of bright areas */
    val glow: Float = 0f,
    /** -1..1 */
    val highlights: Float = 0f,
    /** -1..1 */
    val shadows: Float = 0f,
    /** [TrKind.id] */
    val trKind: String = "none",
    val trMs: Long = 400L,
    /** picture transform of video clips: rotation 0/90/180/270 (clockwise), zoom 1..4, pan -1..1 (of the room the zoom leaves) */
    val rot: Int = 0,
    val vzoom: Float = 1f,
    val vpanX: Float = 0f,
    val vpanY: Float = 0f,
    /** mirror of the picture (applied before the rotation, same order in preview and export) */
    val flipH: Boolean = false,
    val flipV: Boolean = false
) {
    val hasTransform: Boolean get() = rot != 0 || vzoom > 1.001f || flipH || flipV

    /** true when no picture-overlay effect is on (the shader effects are handled separately) */
    val isNone: Boolean get() = vignette <= 0f && grain <= 0f && bars <= 0f && leak <= 0f

    val hasShader: Boolean
        get() = blur > 0f || sharpen > 0f || split > 0f || glitch > 0f || noise > 0f || glow > 0f || highlights != 0f || shadows != 0f
}

/** One effect picture: [bitmaps] shown in turn every [periodMs] (film grain moves), drawn with [alpha]. */
class FxLayer(val bitmaps: List<Bitmap>, val periodMs: Long, val alpha: Float) {
    fun at(ms: Long): Bitmap =
        if (bitmaps.size == 1 || periodMs <= 0L) bitmaps[0] else bitmaps[((ms / periodMs) % bitmaps.size).toInt()]
}

object FxRender {
    /** Builds the pictures for [fx] at a frame of [w] x [h] pixels (they are stretched over the whole frame). */
    fun build(fx: Fx, w: Int, h: Int): List<FxLayer> {
        val out = ArrayList<FxLayer>()
        if (fx.isNone || w < 8 || h < 8) return out
        if (fx.leak > 0f) out.add(FxLayer(listOf(leak(w, h)), 0L, 0.75f * fx.leak))
        if (fx.vignette > 0f) out.add(FxLayer(listOf(vignette(w, h)), 0L, fx.vignette))
        if (fx.grain > 0f) {
            val gw = minOf(w, 540)
            val gh = maxOf(8, (gw.toLong() * h / w).toInt())
            out.add(FxLayer(grainFrames(gw, gh), 70L, 0.5f * fx.grain))
        }
        if (fx.bars > 0f) out.add(FxLayer(listOf(bars(w, h, 0.14f * fx.bars)), 0L, 1f))
        return out
    }

    private var grainKey = 0L
    private var grainCache: List<Bitmap> = emptyList()

    /** The moving grain does not depend on its strength, so the 4 pictures are made once per frame size (not on every slider step). */
    @Synchronized
    private fun grainFrames(w: Int, h: Int): List<Bitmap> {
        val key = w.toLong() * 100000L + h
        if (key != grainKey || grainCache.isEmpty()) {
            grainCache = List(4) { grain(w, h, 1234L + it * 77L) }
            grainKey = key
        }
        return grainCache
    }

    private fun vignette(w: Int, h: Int): Bitmap {
        val bw = minOf(w, 540)
        val bh = maxOf(8, (bw.toLong() * h / w).toInt())
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val r = Math.hypot(bw / 2.0, bh / 2.0).toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            bw / 2f, bh / 2f, r, intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(235, 0, 0, 0)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        Canvas(b).drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return b
    }

    private fun leak(w: Int, h: Int): Bitmap {
        val bw = minOf(w, 540)
        val bh = maxOf(8, (bw.toLong() * h / w).toInt())
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(
            bw.toFloat(), 0f, bw * 0.3f, bh * 0.4f,
            intArrayOf(Color.argb(255, 255, 120, 40), Color.argb(150, 255, 70, 110), Color.TRANSPARENT),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        Canvas(b).drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
        return b
    }

    /** black / white speckles: stronger deviation from mid-grey = more opaque, so the picture's average brightness stays put */
    private fun grain(w: Int, h: Int, seed: Long): Bitmap {
        val rnd = java.util.Random(seed)
        val px = IntArray(w * h)
        for (i in px.indices) {
            val g = rnd.nextInt(256)
            val a = (Math.abs(g - 128) * 2).coerceIn(0, 255)
            px[i] = Color.argb(a, if (g > 128) 255 else 0, if (g > 128) 255 else 0, if (g > 128) 255 else 0)
        }
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        b.setPixels(px, 0, w, 0, 0, w, h)
        return b
    }

    private fun bars(w: Int, h: Int, frac: Float): Bitmap {
        val bw = minOf(w, 540)
        val bh = maxOf(8, (bw.toLong() * h / w).toInt())
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint()
        p.color = Color.BLACK
        val bar = bh * frac
        c.drawRect(0f, 0f, bw.toFloat(), bar, p)
        c.drawRect(0f, bh - bar, bw.toFloat(), bh.toFloat(), p)
        return b
    }
}
