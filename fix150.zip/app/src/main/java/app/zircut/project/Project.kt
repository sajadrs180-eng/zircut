package app.zircut.project

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import app.zircut.core.CapLayout
import app.zircut.core.ColorGrade
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Range
import app.zircut.core.VideoInfo
import app.zircut.core.Word
import app.zircut.timeline.AudioClip
import app.zircut.timeline.Layer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** What the library needs to show a project card. Small, so listing is fast. */
data class ProjectMeta(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int
)

/** Extra media added to a project (second video, photo). Stored next to media.mp4. id = source index used by [app.zircut.timeline.Src]. */
data class ExtraMedia(
    val id: Int,
    val file: String,
    val image: Boolean,
    val durationMs: Long,
    val width: Int,
    val height: Int
)

/** Everything that makes up the user's edit. The source video itself lives next to it as media.mp4. */
data class ProjectData(
    val meta: ProjectMeta,
    val phrases: List<Phrase>,
    val original: List<Phrase>,
    val options: Options,
    val styleId: String,
    val fontId: String,
    val layout: CapLayout,
    val grade: ColorGrade,
    /** manual clip list on the edited timeline; null = automatic cut (silence removal) */
    val segments: List<Range>? = null,
    val extras: List<ExtraMedia> = emptyList(),
    /** text and picture layers over the video (part 4) */
    val layers: List<Layer> = emptyList(),
    /** music / voice-over clips (part 5) */
    val audio: List<AudioClip> = emptyList(),
    /** volume of the video's own sound, 0..1, and whether it is switched off */
    val mainVolume: Float = 1f,
    val mainMuted: Boolean = false
)

/**
 * Persistent, non-destructive project storage.
 *
 * filesDir/projects/<id>/
 *   media.mp4     the source video (never modified)
 *   thumb.jpg     poster frame for the library
 *   meta.json     name, dates, size (small, read for the library list)
 *   project.json  the edit: subtitles, options, style, layout, color grade
 */
class ProjectStore(private val ctx: Context) {
    private val root = File(ctx.filesDir, "projects").apply { mkdirs() }

    fun dir(id: String) = File(root, id)
    fun mediaFile(id: String) = File(dir(id), "media.mp4")
    fun thumbFile(id: String) = File(dir(id), "thumb.jpg")

    // ---------------- create / save / load ----------------

    /** Moves (or copies) the prepared video into a new project folder and makes its poster frame. */
    fun create(src: File, info: VideoInfo, name: String): ProjectMeta {
        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        dir(id).mkdirs()
        val media = mediaFile(id)
        val inCache = src.absolutePath.startsWith(ctx.cacheDir.absolutePath)
        val moved = inCache && src.renameTo(media)
        if (!moved) {
            src.copyTo(media, overwrite = true)
            if (inCache) src.delete()
        }
        makeThumb(media, thumbFile(id), info.durationMs)
        val now = System.currentTimeMillis()
        val meta = ProjectMeta(id, name, now, now, info.durationMs, info.width, info.height)
        writeMeta(meta)
        return meta
    }

    fun save(d: ProjectData) {
        dir(d.meta.id).mkdirs()
        writeMeta(d.meta)
        val o = JSONObject()
        o.put("v", 1)
        o.put("phrases", phrasesJson(d.phrases))
        o.put("original", phrasesJson(d.original))
        o.put("styleId", d.styleId)
        o.put("fontId", d.fontId)
        o.put(
            "options", JSONObject()
                .put("captions", d.options.captions).put("removeSilence", d.options.removeSilence)
                .put("removeFillers", d.options.removeFillers).put("zoom", d.options.zoom)
                .put("vertical", d.options.vertical).put("maxGapMs", d.options.maxGapMs)
                .put("language", d.options.language)
        )
        o.put(
            "layout", JSONObject()
                .put("x", d.layout.x.toDouble()).put("y", d.layout.y.toDouble()).put("mw", d.layout.mw.toDouble())
                .put("ls", d.layout.ls.toDouble()).put("lw", d.layout.lw).put("size", d.layout.size.toDouble())
        )
        o.put(
            "grade", JSONObject()
                .put("lookId", d.grade.lookId).put("strength", d.grade.strength.toDouble())
                .put("brightness", d.grade.brightness.toDouble()).put("contrast", d.grade.contrast.toDouble())
                .put("saturation", d.grade.saturation.toDouble()).put("warmth", d.grade.warmth.toDouble())
                .put("tint", d.grade.tint.toDouble()).put("fade", d.grade.fade.toDouble())
        )
        val ex = JSONArray()
        d.extras.forEach { x ->
            ex.put(
                JSONObject().put("id", x.id).put("file", x.file).put("image", x.image)
                    .put("dur", x.durationMs).put("w", x.width).put("h", x.height)
            )
        }
        o.put("extras", ex)
        o.put("layers", layersJson(d.layers))
        o.put("audio", audioJson(d.audio))
        o.put("mainVol", d.mainVolume.toDouble())
        o.put("mainMute", d.mainMuted)
        val sg = d.segments
        if (sg != null) {
            val a = JSONArray()
            sg.forEach { r -> a.put(JSONArray().put(r.startMs).put(r.endMs)) }
            o.put("segments", a)
        }
        atomicWrite(File(dir(d.meta.id), "project.json"), o.toString())
    }

    fun meta(id: String): ProjectMeta? = try {
        val o = JSONObject(File(dir(id), "meta.json").readText())
        ProjectMeta(
            id, o.getString("name"), o.getLong("created"), o.getLong("updated"),
            o.getLong("duration"), o.getInt("w"), o.getInt("h")
        )
    } catch (e: Exception) {
        null
    }

    fun load(id: String): ProjectData? = try {
        val meta = meta(id) ?: return null
        val o = JSONObject(File(dir(id), "project.json").readText())
        val op = o.getJSONObject("options")
        val lo = o.getJSONObject("layout")
        val gr = o.getJSONObject("grade")
        ProjectData(
            meta = meta,
            phrases = phrasesFrom(o.optJSONArray("phrases")),
            original = phrasesFrom(o.optJSONArray("original")),
            options = Options(
                captions = op.optBoolean("captions", true),
                removeSilence = op.optBoolean("removeSilence", true),
                removeFillers = op.optBoolean("removeFillers", true),
                zoom = op.optBoolean("zoom", true),
                vertical = op.optBoolean("vertical", true),
                maxGapMs = op.optLong("maxGapMs", 500L),
                language = op.optString("language", "fa")
            ),
            styleId = o.optString("styleId", "zarbati"),
            fontId = o.optString("fontId", ""),
            layout = CapLayout(
                x = lo.optDouble("x", 0.5).toFloat(), y = lo.optDouble("y", 0.66).toFloat(),
                mw = lo.optDouble("mw", 0.9).toFloat(), ls = lo.optDouble("ls", 1.5).toFloat(),
                lw = lo.optInt("lw", 4), size = lo.optDouble("size", 1.0).toFloat()
            ),
            grade = ColorGrade(
                lookId = gr.optString("lookId", "none"), strength = gr.optDouble("strength", 1.0).toFloat(),
                brightness = gr.optDouble("brightness", 0.0).toFloat(), contrast = gr.optDouble("contrast", 1.0).toFloat(),
                saturation = gr.optDouble("saturation", 1.0).toFloat(), warmth = gr.optDouble("warmth", 0.0).toFloat(),
                tint = gr.optDouble("tint", 0.0).toFloat(), fade = gr.optDouble("fade", 0.0).toFloat()
            ),
            segments = segmentsFrom(o.optJSONArray("segments"), Long.MAX_VALUE),
            extras = extrasFrom(o.optJSONArray("extras")),
            layers = layersFrom(o.optJSONArray("layers")),
            audio = audioFrom(o.optJSONArray("audio")),
            mainVolume = o.optDouble("mainVol", 1.0).toFloat().coerceIn(0f, 1f),
            mainMuted = o.optBoolean("mainMute", false)
        )
    } catch (e: Exception) {
        null
    }

    // ---------------- library ----------------

    /** All projects, most recently edited first. Folders without a readable meta.json are skipped. */
    fun list(): List<ProjectMeta> =
        (root.listFiles() ?: emptyArray()).filter { it.isDirectory }
            .mapNotNull { meta(it.name) }
            .filter { mediaFile(it.id).exists() }
            .sortedByDescending { it.updatedAt }

    fun rename(id: String, name: String) {
        val m = meta(id) ?: return
        writeMeta(m.copy(name = name, updatedAt = System.currentTimeMillis()))
    }

    fun delete(id: String) {
        dir(id).deleteRecursively()
    }

    /** Full copy, so deleting one project never breaks the other. Returns the new id. */
    fun duplicate(id: String): String? {
        val m = meta(id) ?: return null
        val newId = UUID.randomUUID().toString().replace("-", "").take(12)
        val from = dir(id)
        val to = dir(newId)
        to.mkdirs()
        from.listFiles()?.forEach { f -> if (f.isFile) f.copyTo(File(to, f.name), overwrite = true) }
        val now = System.currentTimeMillis()
        writeMeta(m.copy(id = newId, name = m.name + " (کپی)", createdAt = now, updatedAt = now))
        return newId
    }

    // ---------------- helpers ----------------

    private fun writeMeta(m: ProjectMeta) {
        val o = JSONObject()
            .put("name", m.name).put("created", m.createdAt).put("updated", m.updatedAt)
            .put("duration", m.durationMs).put("w", m.width).put("h", m.height)
        atomicWrite(File(dir(m.id), "meta.json"), o.toString())
    }

    private fun atomicWrite(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (f.exists()) f.delete()
        if (!tmp.renameTo(f)) {
            f.writeText(text)
            tmp.delete()
        }
    }

    private fun phrasesJson(l: List<Phrase>): JSONArray {
        val a = JSONArray()
        l.forEach { p ->
            val wa = JSONArray()
            p.words.forEach { w ->
                wa.put(
                    JSONObject().put("t", w.text).put("s", w.startMs).put("e", w.endMs)
                        .put("c", w.cutBefore).put("q", w.conf.toDouble())
                )
            }
            a.put(wa)
        }
        return a
    }

    private fun layersJson(l: List<Layer>): JSONArray {
        val a = JSONArray()
        l.forEach { x ->
            a.put(
                JSONObject().put("id", x.id).put("kind", x.kind).put("s", x.startMs).put("e", x.endMs)
                    .put("x", x.x.toDouble()).put("y", x.y.toDouble()).put("sc", x.scale.toDouble())
                    .put("rot", x.rotation.toDouble()).put("op", x.opacity.toDouble())
                    .put("text", x.text).put("color", x.color).put("bg", x.bgColor).put("stroke", x.stroke)
                    .put("font", x.fontId).put("file", x.file).put("w", x.imgW).put("h", x.imgH)
            )
        }
        return a
    }

    private fun audioJson(l: List<AudioClip>): JSONArray {
        val a = JSONArray()
        l.forEach { x ->
            a.put(
                JSONObject().put("id", x.id).put("kind", x.kind).put("file", x.file).put("name", x.name)
                    .put("s", x.startMs).put("in", x.inMs).put("len", x.lenMs).put("fileMs", x.fileMs)
                    .put("vol", x.volume.toDouble()).put("fi", x.fadeInMs).put("fo", x.fadeOutMs).put("mute", x.muted)
            )
        }
        return a
    }

    private fun audioFrom(a: JSONArray?): List<AudioClip> {
        if (a == null) return emptyList()
        val out = ArrayList<AudioClip>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val file = o.optString("file", "")
            if (file.isEmpty() || o.optLong("len", 0L) < 1L) continue
            out.add(
                AudioClip(
                    id = o.optInt("id", i + 1), kind = o.optInt("kind", AudioClip.KIND_MUSIC), file = file,
                    name = o.optString("name", ""), startMs = o.optLong("s", 0L), inMs = o.optLong("in", 0L),
                    lenMs = o.optLong("len", 0L), fileMs = o.optLong("fileMs", 0L).coerceAtLeast(o.optLong("in", 0L) + o.optLong("len", 0L)),
                    volume = o.optDouble("vol", 1.0).toFloat().coerceIn(0f, 1f),
                    fadeInMs = o.optLong("fi", 0L), fadeOutMs = o.optLong("fo", 0L), muted = o.optBoolean("mute", false)
                )
            )
        }
        // ids must be unique: the editor addresses clips by id
        return out.distinctBy { it.id }
    }

    private fun layersFrom(a: JSONArray?): List<Layer> {
        if (a == null) return emptyList()
        val out = ArrayList<Layer>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val s = o.optLong("s", 0L)
            val e = o.optLong("e", 0L)
            if (e - s < 1L) continue
            out.add(
                Layer(
                    id = o.optInt("id", i + 1), kind = o.optInt("kind", Layer.KIND_TEXT), startMs = s, endMs = e,
                    x = o.optDouble("x", 0.5).toFloat(), y = o.optDouble("y", 0.5).toFloat(),
                    scale = o.optDouble("sc", 1.0).toFloat(), rotation = o.optDouble("rot", 0.0).toFloat(),
                    opacity = o.optDouble("op", 1.0).toFloat(), text = o.optString("text", ""),
                    color = o.optInt("color", 0xFFFFFFFF.toInt()), bgColor = o.optInt("bg", 0),
                    stroke = o.optBoolean("stroke", true), fontId = o.optString("font", ""),
                    file = o.optString("file", ""), imgW = o.optInt("w", 0), imgH = o.optInt("h", 0)
                )
            )
        }
        // ids must be unique: the editor addresses layers by id
        return out.distinctBy { it.id }
    }

    private fun extrasFrom(a: JSONArray?): List<ExtraMedia> {
        if (a == null) return emptyList()
        val out = ArrayList<ExtraMedia>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(
                ExtraMedia(
                    o.optInt("id", 0), o.optString("file", ""), o.optBoolean("image", false),
                    o.optLong("dur", 0L), o.optInt("w", 0), o.optInt("h", 0)
                )
            )
        }
        return out.filter { it.id > 0 && it.file.isNotEmpty() }
    }

    private fun segmentsFrom(a: JSONArray?, durMs: Long): List<Range>? {
        if (a == null) return null
        val out = ArrayList<Range>()
        for (i in 0 until a.length()) {
            val p = a.optJSONArray(i) ?: continue
            val s = p.optLong(0, 0L).coerceIn(0L, durMs)
            val e = p.optLong(1, 0L).coerceIn(0L, durMs)
            if (e - s >= 50L) out.add(Range(s, e))
        }
        return if (out.isEmpty()) null else out
    }

    private fun phrasesFrom(a: JSONArray?): List<Phrase> {
        if (a == null) return emptyList()
        val out = ArrayList<Phrase>()
        for (i in 0 until a.length()) {
            val wa = a.optJSONArray(i) ?: continue
            val words = ArrayList<Word>()
            for (j in 0 until wa.length()) {
                val o = wa.getJSONObject(j)
                words.add(
                    Word(
                        o.getString("t"), o.getLong("s"), o.getLong("e"),
                        o.optBoolean("c", false), o.optDouble("q", 1.0).toFloat()
                    )
                )
            }
            if (words.isNotEmpty()) out.add(Phrase(words))
        }
        return out
    }

    private fun makeThumb(media: File, out: File, durMs: Long) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(media.absolutePath)
            val at = minOf(1_000_000L, (durMs * 1000L) / 2L).coerceAtLeast(0L)
            val b = r.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.getFrameAtTime(0L)
            r.release()
            if (b != null) {
                val k = 400f / maxOf(b.width, b.height)
                val s = if (k < 1f) Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true) else b
                out.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            }
        } catch (e: Exception) {
            // the library shows a placeholder icon when there is no poster frame
        }
    }
}

/** "پروژه ۳" style default name with Persian digits. */
fun defaultProjectName(existing: List<ProjectMeta>): String {
    var n = existing.size + 1
    val names = existing.map { it.name }.toSet()
    while (true) {
        val d = n.toString().map { '۰' + (it - '0') }.joinToString("")
        val name = "پروژه $d"
        if (name !in names) return name
        n++
    }
}
