package app.zircut.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import app.zircut.timeline.Layer
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.math.min

@UnstableApi
class Exporter(private val ctx: Context) {
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    /** Where clip i comes from when the timeline mixes several media. Image clips have no clipping, only a duration. */
    class ClipSource(val uri: Uri, val image: Boolean)

    class Params(
        val uri: Uri,
        val info: VideoInfo,
        val ranges: List<Range>,
        val phrases: List<Phrase>,
        val style: SubStyle,
        val typeface: Typeface,
        val options: Options,
        val out: File,
        val layout: CapLayout = CapLayout(),
        val grade: ColorGrade = ColorGrade(),
        /** parallel to [ranges]; null = every clip comes from [uri] (single video project) */
        val sources: List<ClipSource>? = null,
        /** clip list used for subtitles (clips without subtitles get impossible source times) */
        val captionRanges: List<Range>? = null,
        /** text and picture layers (times on the edited timeline) */
        val layers: List<Layer> = emptyList(),
        /** project folder where picture layers live */
        val projectDir: File? = null,
        /** typeface of a text layer by font id ("" = project font) */
        val layerFont: (String) -> Typeface = { typeface },
        /** finished stereo WAV with the whole sound track (video sound + music + voice-over); null = keep each clip's own sound */
        val mixAudio: File? = null
    )

    /** Must be called on the main thread. */
    fun start(p: Params, onProgress: (Float) -> Unit, onDone: () -> Unit, onError: (String) -> Unit) =
        run(p, 0, onProgress, onDone, onError)

    /** level 0 = best quality; if the phone's encoder refuses, level 1 (30 fps, lower bitrate) and level 2 (720p) are tried automatically. */
    private fun run(p: Params, level: Int, onProgress: (Float) -> Unit, onDone: () -> Unit, onError: (String) -> Unit) {
        val opt = p.options
        val srcW = p.info.width
        val srcH = p.info.height

        // Output geometry
        var outW = srcW
        var outH = srcH
        if (opt.vertical) {
            if (srcW.toFloat() / srcH > 9f / 16f) {
                outH = srcH
                outW = srcH * 9 / 16
            } else {
                outW = srcW
                outH = srcW * 16 / 9
            }
        }
        // Always export at full HD or better: captions stay crisp and platforms keep the quality.
        val baseH = if (opt.vertical) 1920 else (maxOf(1080, min(outH, 1920)) and 1.inv())
        val targetH = (if (level >= 2) baseH * 2 / 3 else baseH) and 1.inv()
        val targetW = if (opt.vertical) (if (level >= 2) 720 else 1080) else ((outW.toLong() * targetH / outH).toInt() and 1.inv())

        // layers are drawn once per run at the real output size, then only moved/faded per frame
        val baked = p.layers.mapNotNull { l ->
            val bs = LayerRenderer.bakeScale(l.scale)
            val b = LayerRenderer.base(l, targetW, targetH, p.layerFont(l.fontId), p.projectDir, bs) ?: return@mapNotNull null
            BakedLayer(l, LayerRenderer.bakeRotation(b, l.rotation), bs)
        }
        val timeline = CaptionTimeline(p.phrases, p.captionRanges ?: p.ranges)
        val renderer = CaptionRenderer(targetW, targetH, p.style, p.typeface, p.layout)
        var acc = 0L
        val multi = p.sources != null
        val items = p.ranges.mapIndexed { i, r ->
            val cs = p.sources?.getOrNull(i)
            val isImage = cs?.image == true
            val mi = if (isImage) {
                MediaItem.fromUri(cs!!.uri)
            } else {
                MediaItem.Builder()
                    .setUri(cs?.uri ?: p.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(r.startMs)
                            .setEndPositionMs(r.endMs)
                            .build()
                    ).build()
            }
            val v = ArrayList<Effect>()
            if (level >= 1 && !isImage) v.add(FrameDropEffect.createDefaultFrameDropEffect(30f))
            if (!p.grade.isIdentity) v.add(GradeEffect(p.grade.affine().toRgbMatrix()))
            if (opt.zoom && i % 2 == 1) {
                v.add(ScaleAndRotateTransformation.Builder().setScale(1.18f, 1.18f).build())
            }
            // when media of different shapes are mixed, every clip is scaled/cropped to the same output size
            if (opt.vertical || multi) {
                v.add(Presentation.createForWidthAndHeight(targetW, targetH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            } else {
                v.add(Presentation.createForHeight(targetH))
            }
            val overlays = ArrayList<TextureOverlay>()
            // layers first, so subtitles stay on top of them
            for (b in baked) {
                if (b.layer.startMs < acc + r.len && b.layer.endMs > acc) overlays.add(LayerOverlay(b, acc * 1000L))
            }
            if (opt.captions && p.phrases.isNotEmpty()) {
                overlays.add(CaptionOverlay(timeline, p.phrases, renderer, p.style, p.layout, acc * 1000L))
            }
            if (overlays.isNotEmpty()) v.add(OverlayEffect(ImmutableList.copyOf(overlays)))
            acc += r.len
            val eb = EditedMediaItem.Builder(mi).setEffects(Effects(emptyList(), v))
            if (isImage) eb.setDurationUs(r.len * 1000L).setFrameRate(30)
            // the mixed track already contains the video's own sound, so the clips themselves go silent
            else if (p.mixAudio != null) eb.setRemoveAudio(true)
            eb.build()
        }

        val videoSeq = EditedMediaItemSequence(items)
        val mixItem = p.mixAudio?.let { EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(it))).build() }
        val cb = if (mixItem != null) Composition.Builder(videoSeq, EditedMediaItemSequence(listOf(mixItem))) else Composition.Builder(videoSeq)
        if (mixItem == null && p.sources?.any { it.image } == true) {
            // photos have no audio: ask Transformer to fill the gaps with silence (method is experimental, so call it softly)
            try {
                Composition.Builder::class.java
                    .getMethod("experimentalSetForceAudioTrack", Boolean::class.javaPrimitiveType)
                    .invoke(cb, true)
            } catch (_: Throwable) {
            }
        }
        val composition = cb.build()

        val bitrate = when (level) {
            0 -> if (targetH >= 1500) 12_000_000 else 10_000_000
            1 -> 8_000_000
            else -> 5_000_000
        }
        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val t = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    polling = false
                    onDone()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    polling = false
                    if (level < 2) {
                        handler.post { run(p, level + 1, onProgress, onDone, onError) }
                    } else {
                        onError((exportException.message ?: "خطا در ساخت ویدیو") + " [" + exportException.errorCodeName + "]")
                    }
                }
            })
            .build()
        transformer = t
        t.start(composition, p.out.absolutePath)

        polling = true
        val holder = ProgressHolder()
        handler.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val tr = transformer ?: return
                if (tr.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress / 100f)
                }
                handler.postDelayed(this, 400)
            }
        })
    }

    fun cancel() {
        polling = false
        transformer?.cancel()
    }
}

@UnstableApi
private class CaptionOverlay(
    private val timeline: CaptionTimeline,
    private val phrases: List<Phrase>,
    private val renderer: CaptionRenderer,
    private val style: SubStyle,
    private val layout: CapLayout,
    private val startUs: Long
) : BitmapOverlay() {
    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private var lastKey = Long.MIN_VALUE
    private var lastBmp: Bitmap = blank

    private var mode = -1

    private fun outMs(presentationTimeUs: Long): Long {
        if (mode < 0) {
            mode = if (startUs > 0 && presentationTimeUs < startUs / 2) 1 else 0
            Diag.mode = if (mode == 1) "نسبی" else "مطلق"
        }
        return (if (mode == 1) presentationTimeUs + startUs else presentationTimeUs) / 1000
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        Diag.calls++
        Diag.lastUs = presentationTimeUs
        try {
            val st = timeline.stateAt(outMs(presentationTimeUs))
            val key = if (st == null) -1L else st.phraseIdx * 1000L + st.wordIdx
            if (st != null) Diag.shown++
            if (key != lastKey) {
                lastBmp = if (st == null) blank else renderer.render(phrases[st.phraseIdx], st.wordIdx)
                lastKey = key
            }
        } catch (t: Throwable) {
            Diag.err = t.toString().take(140)
            return blank
        }
        return lastBmp
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val st = timeline.stateAt(outMs(presentationTimeUs))
        val s = if (style.pop && st != null) st.pop else 1f
        val a = if (style.fade && st != null) minOf(1f, st.tMs / 220f) else 1f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor((layout.x - 0.5f) * 2f, 1f - 2f * layout.y)
            .setOverlayFrameAnchor(0f, 0f)
            .setScale(s, s)
            .setAlphaScale(a)
            .build()
    }
}


/** A layer drawn at output size, rotation already applied; it is shown at layer.scale / bs. */
private class BakedLayer(val layer: Layer, val bmp: Bitmap, val bs: Float)

/** One text/picture layer as a Media3 overlay: visible only between its start and end on the edited timeline. */
@UnstableApi
private class LayerOverlay(private val b: BakedLayer, private val startUs: Long) : BitmapOverlay() {
    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private var mode = -1

    // same time handling as the captions: frame times are either relative to the clip or to the whole export
    private fun outMs(presentationTimeUs: Long): Long {
        if (mode < 0) mode = if (startUs > 0 && presentationTimeUs < startUs / 2) 1 else 0
        return (if (mode == 1) presentationTimeUs + startUs else presentationTimeUs) / 1000
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap =
        if (b.layer.visibleAt(outMs(presentationTimeUs))) b.bmp else blank

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val l = b.layer
        val on = l.visibleAt(outMs(presentationTimeUs))
        val s = l.scale / b.bs
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor((l.x - 0.5f) * 2f, 1f - 2f * l.y)
            .setOverlayFrameAnchor(0f, 0f)
            .setScale(s, s)
            .setAlphaScale(if (on) l.opacity.coerceIn(0f, 1f) else 0f)
            .build()
    }
}


/** Small counters so the app can explain by itself why captions did or did not appear. */
object Diag {
    @Volatile var calls = 0
    @Volatile var shown = 0
    @Volatile var lastUs = 0L
    @Volatile var err = ""
    @Volatile var mode = "-"
    fun reset() { calls = 0; shown = 0; lastUs = 0L; err = ""; mode = "-" }
    fun text(): String =
        "اورلی صدا زده شد: $calls بار · فریم‌های دارای زیرنویس: $shown · زمان‌بندی: $mode · آخرین زمان: ${lastUs / 1000}ms · خطای رندر: ${if (err.isEmpty()) "ندارد" else err}"
}


/** Color grade as a single RGB matrix (same numbers as the editor preview). */
@UnstableApi
private class GradeEffect(private val matrix: FloatArray) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = matrix
}
