package app.zircut

import android.app.Application
import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.zircut.core.AudioDecoder
import app.zircut.core.Exporter
import app.zircut.core.FontStore
import app.zircut.core.ModelManager
import app.zircut.core.ModelSize
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Planner
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import app.zircut.core.CapLayout
import app.zircut.core.CloudTranscriber
import app.zircut.core.Diag
import app.zircut.core.Styles
import app.zircut.core.VideoInfo
import app.zircut.core.WhisperBridge
import app.zircut.core.Word
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Stage {
    data object Idle : Stage
    data object NeedModel : Stage
    data class Working(val label: String, val progress: Float?) : Stage
    data object Review : Stage
    data class Done(val uri: Uri) : Stage
    data class Failed(val message: String) : Stage
}

data class UiState(
    val stage: Stage = Stage.Idle,
    val video: Uri? = null,
    val info: VideoInfo? = null,
    val phrases: List<Phrase> = emptyList(),
    val options: Options = Options(),
    val styleId: String = "zarbati",
    val layout: CapLayout = CapLayout(),
    val debug: String = "",
    val perf: String = "",
    val original: List<Phrase> = emptyList(),
    val cfAccount: String = "",
    val cfToken: String = "",
    val workerUrl: String = "",
    val fontId: String = "",
    val themeId: String = "violet_blue",
    val modelSize: ModelSize = ModelSize.SMALL,
    val fonts: List<FontStore.Font> = emptyList(),
    val modelsReady: Set<ModelSize> = emptySet(),
    val transcribing: Boolean = false,
    val accurate: Boolean = false
)

@UnstableApi
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("zircut", Context.MODE_PRIVATE)
    private val fontStore = FontStore(ctx)
    private val models = ModelManager(ctx)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var job: Job? = null
    private var exporter: Exporter? = null

    init {
        val mem = (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            .let { am -> ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem }
        val defaultModel = if (mem >= 5_500_000_000L) ModelSize.SMALL else ModelSize.BASE
        val savedModel = ModelSize.values().firstOrNull { it.id == prefs.getString("model", null) } ?: defaultModel
        val fonts = fontStore.list()
        val savedFont = prefs.getString("font", null)
        val styleFont = Styles.byId(prefs.getString("style", "zarbati") ?: "zarbati").font
        val fontId = fonts.firstOrNull { it.id == savedFont }?.id
            ?: fonts.firstOrNull { it.name == styleFont }?.id ?: fonts.first().id
        _ui.update {
            it.copy(
                themeId = prefs.getString("theme", "violet_blue") ?: "violet_blue",
                styleId = prefs.getString("style", "zarbati") ?: "zarbati",
                cfAccount = prefs.getString("cf_acct", "") ?: "",
                cfToken = prefs.getString("cf_token", "") ?: "",
                workerUrl = prefs.getString("worker_url", app.zircut.core.Config.WORKER_URL) ?: "",
                layout = CapLayout(
                    x = prefs.getFloat("lx", 0.5f), y = prefs.getFloat("ly", 0.66f), mw = prefs.getFloat("lmw", 0.9f),
                    ls = prefs.getFloat("lls", 1.5f), lw = prefs.getInt("llw", 4), size = prefs.getFloat("lsz", 1f)
                ),
                options = it.options.copy(language = prefs.getString("lang", "fa") ?: "fa"),
                modelSize = savedModel,
                accurate = prefs.getBoolean("accurate", false),
                fonts = fonts,
                fontId = fontId,
                modelsReady = ModelSize.values().filter { m -> models.has(m) }.toSet()
            )
        }
    }

    // ---------- settings ----------
    fun setTheme(id: String) { prefs.edit().putString("theme", id).apply(); _ui.update { it.copy(themeId = id) } }
    fun setStyle(id: String) {
        prefs.edit().putString("style", id).apply()
        val want = Styles.byId(id).font
        _ui.update { s ->
            val f = s.fonts.firstOrNull { it.name == want }?.id
            if (f != null) prefs.edit().putString("font", f).apply()
            s.copy(styleId = id, fontId = f ?: s.fontId)
        }
    }
    fun setLayout(l: CapLayout) {
        prefs.edit().putFloat("lx", l.x).putFloat("ly", l.y).putFloat("lmw", l.mw)
            .putFloat("lls", l.ls).putInt("llw", l.lw).putFloat("lsz", l.size).apply()
        _ui.update { it.copy(layout = l) }
    }
    fun setFont(id: String) { prefs.edit().putString("font", id).apply(); _ui.update { it.copy(fontId = id) } }
    fun setLanguage(l: String) { prefs.edit().putString("lang", l).apply(); _ui.update { it.copy(options = it.options.copy(language = l)) } }
    fun setModel(m: ModelSize) { prefs.edit().putString("model", m.id).apply(); _ui.update { it.copy(modelSize = m) } }
    fun setOptions(o: Options) { _ui.update { it.copy(options = o) } }
    fun setAccurate(v: Boolean) { prefs.edit().putBoolean("accurate", v).apply(); _ui.update { it.copy(accurate = v) } }

    fun addFont(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            }
            val id = fontStore.import(uri, name)
            val fonts = fontStore.list()
            _ui.update { it.copy(fonts = fonts, fontId = id ?: it.fontId) }
            if (id != null) prefs.edit().putString("font", id).apply()
        }
    }

    // ---------- flow ----------
    fun pickVideo(uri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال بررسی ویدیو…", null), video = uri, phrases = emptyList()) }
            val info = try {
                withContext(Dispatchers.IO) { probe(uri) }
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("این ویدیو باز نشد: ${e.message}")) }
                return@launch
            }
            _ui.update { it.copy(info = info) }
            if (models.has(_ui.value.modelSize) || cloudReady()) startTranscribe() else _ui.update { it.copy(stage = Stage.NeedModel) }
        }
    }

    private fun probe(uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur <= 0 || w <= 0 || h <= 0) throw IllegalStateException("اطلاعات ویدیو ناقصه")
            return VideoInfo(dur, w, h)
        } finally {
            r.release()
        }
    }

    fun downloadModel() {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", 0f)) }
            try {
                models.download(m) { p -> _ui.update { s -> s.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", p)) } }
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("دانلود مدل نشد (${e.message}). اگه سایت فیلتره، فایل مدل رو جداگانه بگیر و با «وارد کردن فایل» انتخاب کن.")) }
            }
        }
    }

    fun importModel(uri: Uri) {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال وارد کردن مدل…", null)) }
            try {
                models.importFrom(uri, m)
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("وارد کردن مدل نشد: ${e.message}")) }
            }
        }
    }

    fun setCloud(account: String, token: String) {
        prefs.edit().putString("cf_acct", account).putString("cf_token", token).apply()
        _ui.update { it.copy(cfAccount = account, cfToken = token) }
    }

    fun setWorkerUrl(url: String) {
        prefs.edit().putString("worker_url", url).apply()
        _ui.update { it.copy(workerUrl = url) }
    }

    private fun cloudReady(): Boolean = _ui.value.workerUrl.isNotBlank() || (_ui.value.cfAccount.isNotBlank() && _ui.value.cfToken.isNotBlank())

    private var wake: android.os.PowerManager.WakeLock? = null

    private fun lockOn() {
        try {
            if (wake == null) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                wake = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "zircut:work")
            }
            if (wake?.isHeld != true) wake?.acquire(30 * 60 * 1000L)
        } catch (_: Exception) {
        }
    }

    private fun lockOff() {
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (_: Exception) {
        }
    }

    fun startTranscribe() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val modelFile = models.file(st.modelSize)
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.Default) {
            val bridge = WhisperBridge()
            var wctx = 0L
            lockOn()
            try {
                _ui.update { it.copy(stage = Stage.Working("در حال خواندن صدا…", 0f), transcribing = true) }
                val raw = ArrayList<Word>()
                val t0 = System.currentTimeMillis()
                var cloudOk = false
                var cloudErr = ""
                var nChunks = 0
                val useBeam = if (st.accurate) st.modelSize.beam else 1
                val tag = st.options.language + "|" + (if (cloudReady()) "cloud" else st.modelSize.id + "|b" + useBeam) + "|v1"
                val cacheF = cacheFile(uri, info, tag)
                val cached = if (cacheF != null) loadRaw(cacheF) else null
                if (cached != null) raw.addAll(cached)
                if (cached == null) {
                val pcm = AudioDecoder.decode(ctx, uri) { p ->
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال خواندن صدا…", p)) }
                }
                ensureActive()
                val chunks = AudioDecoder.chunkSpeech(pcm)
                nChunks = chunks.size
                if (cloudReady()) {
                    try {
                        val sem = Semaphore(4)
                        val done = java.util.concurrent.atomic.AtomicInteger(0)
                        val results = coroutineScope {
                            chunks.map { c ->
                                async(Dispatchers.IO) {
                                    sem.withPermit {
                                        var ws: List<CloudTranscriber.W>? = null
                                        var err: Exception? = null
                                        for (attempt in 0..1) {
                                            try {
                                                ws = CloudTranscriber.transcribe(st.workerUrl, st.cfAccount, st.cfToken, c.samples, st.options.language)
                                                break
                                            } catch (e: kotlinx.coroutines.CancellationException) {
                                                throw e
                                            } catch (e: Exception) {
                                                err = e
                                                kotlinx.coroutines.delay(800)
                                            }
                                        }
                                        val d = done.incrementAndGet()
                                        _ui.update { s -> s.copy(stage = Stage.Working("تشخیص گفتار آنلاین… ($d از ${chunks.size})", d.toFloat() / chunks.size)) }
                                        ws ?: throw (err ?: IllegalStateException("پاسخی نیامد"))
                                    }
                                }
                            }.awaitAll()
                        }
                        chunks.forEachIndexed { i, c ->
                            for (w in results[i]) {
                                val a = c.toSrc(w.startMs)
                                raw.add(Word(w.text, a, maxOf(c.toSrc(w.endMs), a + 50)))
                            }
                        }
                        cloudOk = raw.isNotEmpty()
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        cloudErr = e.message ?: ""
                        raw.clear()
                    }
                }
                if (!cloudOk) {
                if (!models.has(st.modelSize)) throw IllegalStateException("تشخیص آنلاین انجام نشد" + (if (cloudErr.isNotEmpty()) " ($cloudErr)" else "") + " و مدل آفلاین هم دانلود نشده.")
                if (!WhisperBridge.cpuSupportsFast()) throw IllegalStateException("پردازنده‌ی این گوشی قدیمی است و از نسخه‌ی سریع تشخیص گفتار پشتیبانی نمی‌کند.")
                wctx = bridge.loadModel(modelFile.absolutePath)
                if (wctx == 0L) throw IllegalStateException("مدل بارگذاری نشد. فایل مدل خراب یا ناقصه.")
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
                val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(4, 8)
                chunks.forEachIndexed { i, c ->
                    ensureActive()
                    val eta = if (i == 0) "" else {
                        val left = (System.currentTimeMillis() - t0) / i * (chunks.size - i) / 60000.0
                        " · حدود ${if (left < 1.0) "کمتر از ۱" else (left + 0.5).toInt().toString()} دقیقه مانده"
                    }
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال تشخیص گفتار… (${i + 1} از ${chunks.size})$eta", i.toFloat() / chunks.size)) }
                    val rows = bridge.transcribe(wctx, c.samples, st.options.language, threads, useBeam)
                    for (row in rows) {
                        val p = row.split('\t', limit = 4)
                        if (p.size < 4) continue
                        val s = p[0].toLongOrNull() ?: continue
                        val e = p[1].toLongOrNull() ?: continue
                        val a = c.toSrc(s)
                        raw.add(Word(p[3], a, maxOf(c.toSrc(maxOf(e, s + 50)), a + 50), conf = (p[2].toIntOrNull() ?: 1000) / 1000f))
                    }
                }
                }
                if (cacheF != null && raw.isNotEmpty()) saveRaw(cacheF, raw)
                }
                val totalS = (System.currentTimeMillis() - t0) / 1000
                val perfText = if (cached != null) "از حافظه (تشخیص دوباره انجام نشد)" else
                    "${if (cloudOk) "آنلاین" else "مدل " + st.modelSize.id + (if (useBeam > 1) " (دقیق)" else " (سریع)")} · ${nChunks} تکه · کل ${totalS} ثانیه · هر تکه ${totalS / maxOf(1, nChunks)} ثانیه" +
                    " · ${raw.size} کلمه تا ثانیه ${(raw.maxOfOrNull { it.endMs } ?: 0L) / 1000} از ${info.durationMs / 1000}"
                _ui.update { it.copy(perf = perfText) }
                val words = Planner.clean(raw, st.options.removeFillers)
                if (words.isEmpty()) {
                    throw IllegalStateException("هیچ گفتاری تشخیص داده نشد (تعداد خام: ${raw.size}). مدل بزرگ‌تر (base یا small) را امتحان کن یا ویدیویی با صدای واضح‌تر بده.")
                }
                val fx = loadFixes()
                val fixed = words.map { w ->
                    val core = fixKey(w.text)
                    val repl = fx[core]
                    if (repl != null && w.conf < 0.85f && w.text.contains(core)) w.copy(text = w.text.replaceFirst(core, repl), conf = 1f) else w
                }
                val phrases = Planner.phrases(fixed)
                _ui.update { it.copy(phrases = phrases, original = phrases, stage = Stage.Review) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                _ui.update { it.copy(stage = Stage.Failed(e.message ?: "خطای ناشناخته")) }
            } finally {
                if (wctx != 0L) bridge.release(wctx)
                _ui.update { it.copy(transcribing = false) }
                lockOff()
            }
        }
    }


    // ---------- transcript cache (same video + same settings = no second recognition) ----------
    private fun cacheFile(uri: Uri, info: VideoInfo, tag: String): File? {
        var name = ""
        var size = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: ""
                    val j = c.getColumnIndex(OpenableColumns.SIZE)
                    if (j >= 0) size = c.getLong(j)
                }
            }
        } catch (_: Exception) {
        }
        if (name.isEmpty() || size <= 0L) return null
        val key = "$name|$size|${info.durationMs}|${info.width}x${info.height}|$tag"
        val h = java.security.MessageDigest.getInstance("SHA-1").digest(key.toByteArray()).joinToString("") { "%02x".format(it) }
        val dir = File(ctx.cacheDir, "transcripts").apply { mkdirs() }
        dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(30)?.forEach { it.delete() }
        return File(dir, "$h.json")
    }

    private fun saveRaw(f: File, raw: List<Word>) {
        try {
            val a = org.json.JSONArray()
            for (w in raw) a.put(org.json.JSONArray().put(w.text).put(w.startMs).put(w.endMs).put(w.conf.toDouble()))
            f.writeText(a.toString())
        } catch (_: Exception) {
        }
    }

    private fun loadRaw(f: File): List<Word>? = try {
        if (!f.exists()) null else {
            val a = org.json.JSONArray(f.readText())
            val out = ArrayList<Word>(a.length())
            for (i in 0 until a.length()) {
                val r = a.getJSONArray(i)
                out.add(Word(r.getString(0), r.getLong(1), r.getLong(2), conf = r.getDouble(3).toFloat()))
            }
            if (out.isEmpty()) null else out
        }
    } catch (e: Exception) {
        null
    }

    private fun fixKey(t: String): String = t.trim().trim { !it.isLetterOrDigit() }.lowercase()

    private fun loadFixes(): Map<String, String> = try {
        val o = org.json.JSONObject(prefs.getString("fixes", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    /** Remembers the words the user corrected, so the same mistake is fixed automatically next time. */
    private fun learnFixes(orig: List<Phrase>, now: List<Phrase>) {
        if (orig.size != now.size) return
        val m = loadFixes().toMutableMap()
        for (i in orig.indices) {
            if (orig[i].words.size != now[i].words.size) continue
            for (j in orig[i].words.indices) {
                val a = fixKey(orig[i].words[j].text)
                val b = fixKey(now[i].words[j].text)
                if (a.length >= 2 && b.length >= 2 && a != b && !b.contains(' ')) m[a] = b
            }
        }
        while (m.size > 500) m.remove(m.keys.first())
        prefs.edit().putString("fixes", org.json.JSONObject(m as Map<*, *>).toString()).apply()
    }

    fun editPhrase(index: Int, text: String) {
        _ui.update { s ->
            if (index !in s.phrases.indices) return@update s
            val list = s.phrases.toMutableList()
            list[index] = Planner.rebuild(list[index], text)
            s.copy(phrases = list)
        }
    }

    fun cancel() {
        exporter?.cancel()
        job?.cancel()
        _ui.update { it.copy(stage = if (it.phrases.isNotEmpty()) Stage.Review else Stage.Idle) }
    }

    fun reset() {
        job?.cancel()
        _ui.update { it.copy(stage = Stage.Idle, video = null, info = null, phrases = emptyList()) }
    }

    fun backToReview() { _ui.update { it.copy(stage = Stage.Review) } }

    // ---------- export ----------
    fun export() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val words = st.phrases.flatMap { it.words }
        val ranges = Planner.ranges(words, info.durationMs, st.options)
        val font = st.fonts.firstOrNull { it.id == st.fontId }?.typeface ?: Typeface.DEFAULT_BOLD
        val out = File(ctx.cacheDir, "zircut_out.mp4").also { it.delete() }
        Diag.reset()
        try { learnFixes(st.original, st.phrases) } catch (_: Exception) { }
        lockOn()
        val first = st.phrases.firstOrNull()
        val dbg = st.perf + "\n" + "عبارت‌ها ${st.phrases.size} · کلمه‌ها ${words.size} · بازه‌ها ${ranges.size} · مجموع ${ranges.sumOf { it.len }}ms از ${info.durationMs}ms · زیرنویس=${st.options.captions} · عمودی=${st.options.vertical}" +
            (if (first != null) "\nاولین عبارت: «${first.words.joinToString(" ") { it.text }}» از ${first.startMs} تا ${first.endMs}ms" else "\nهیچ عبارتی وجود ندارد")
        _ui.update { it.copy(debug = dbg, stage = Stage.Working("در حال ساخت ویدیو…", 0f)) }

        val ex = Exporter(ctx)
        exporter = ex
        ex.start(
            Exporter.Params(uri, info, ranges, st.phrases, Styles.byId(st.styleId), font, st.options, out, st.layout),
            onProgress = { p -> _ui.update { s -> if (s.stage is Stage.Working) s.copy(stage = Stage.Working("در حال ساخت ویدیو…", p)) else s } },
            onDone = {
                lockOff()
                viewModelScope.launch {
                    try {
                        val saved = withContext(Dispatchers.IO) { saveToGallery(out) }
                        _ui.update { it.copy(debug = it.debug + "\n" + Diag.text(), stage = Stage.Done(saved)) }
                    } catch (e: Exception) {
                        _ui.update { it.copy(stage = Stage.Failed("ذخیره ویدیو نشد: ${e.message}")) }
                    }
                }
            },
            onError = { msg -> lockOff(); _ui.update { it.copy(stage = Stage.Failed(msg)) } }
        )
    }

    private fun saveToGallery(file: File): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ZirCut_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZirCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("دسترسی به گالری ممکن نشد")
        resolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }
}
