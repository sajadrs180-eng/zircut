package app.zircut

import android.app.Application
import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.zircut.core.AudioDecoder
import app.zircut.core.Exporter
import app.zircut.core.FontStore
import app.zircut.core.ModelManager
import app.zircut.core.ModelSize
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Planner
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import app.zircut.core.CapLayout
import app.zircut.core.CloudTranscriber
import app.zircut.core.Dsp
import app.zircut.core.Config
import app.zircut.core.Diag
import app.zircut.core.Styles
import app.zircut.core.VideoInfo
import app.zircut.core.WhisperBridge
import app.zircut.core.Word
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Recent(val title: String, val uri: String, val time: Long)

sealed interface Stage {
    data object Idle : Stage
    data object NeedModel : Stage
    data class Working(val label: String, val progress: Float?) : Stage
    data object Review : Stage
    data class Done(val uri: Uri) : Stage
    data class Failed(val message: String) : Stage
}

data class UiState(
    val stage: Stage = Stage.Idle,
    val video: Uri? = null,
    val info: VideoInfo? = null,
    val phrases: List<Phrase> = emptyList(),
    val options: Options = Options(),
    val styleId: String = "zarbati",
    val layout: CapLayout = CapLayout(),
    val debug: String = "",
    val perf: String = "",
    val original: List<Phrase> = emptyList(),
    val cfAccount: String = "",
    val cfToken: String = "",
    val workerUrl: String = "",
    val fontId: String = "",
    val themeId: String = "violet_blue",
    val modelSize: ModelSize = ModelSize.SMALL,
    val fonts: List<FontStore.Font> = emptyList(),
    val modelsReady: Set<ModelSize> = emptySet(),
    val transcribing: Boolean = false,
    val accurate: Boolean = false,
    val recent: List<Recent> = emptyList(),
    val notice: String = "",
    val diag: String = ""
)

@UnstableApi
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("zircut", Context.MODE_PRIVATE)
    private val fontStore = FontStore(ctx)
    private val models = ModelManager(ctx)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var job: Job? = null
    private var cloudBlocked = false
    private var exporter: Exporter? = null

    init {
        val mem = (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            .let { am -> ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem }
        val defaultModel = models.bundled() ?: (if (mem >= 5_500_000_000L) ModelSize.SMALL else ModelSize.BASE)
        val savedModel = ModelSize.values().firstOrNull { it.id == prefs.getString("model", null) } ?: defaultModel
        val fonts = fontStore.list()
        val savedFont = prefs.getString("font", null)
        val styleFont = Styles.byId(prefs.getString("style", "zarbati") ?: "zarbati").font
        val fontId = fonts.firstOrNull { it.id == savedFont }?.id
            ?: fonts.firstOrNull { it.name == styleFont }?.id ?: fonts.first().id
        _ui.update {
            it.copy(
                themeId = prefs.getString("theme", "violet_blue") ?: "violet_blue",
                styleId = prefs.getString("style", "zarbati") ?: "zarbati",
                cfAccount = prefs.getString("cf_acct", "") ?: "",
                cfToken = prefs.getString("cf_token", "") ?: "",
                workerUrl = prefs.getString("worker_url", Config.WORKER_URL) ?: "",
                layout = CapLayout(
                    x = prefs.getFloat("lx", 0.5f), y = prefs.getFloat("ly", 0.66f), mw = prefs.getFloat("lmw", 0.9f),
                    ls = prefs.getFloat("lls", 1.5f), lw = prefs.getInt("llw", 4), size = prefs.getFloat("lsz", 1f)
                ),
                options = it.options.copy(language = prefs.getString("lang", "fa") ?: "fa"),
                modelSize = savedModel,
                accurate = prefs.getBoolean("accurate", false),
                fonts = fonts,
                fontId = fontId,
                modelsReady = ModelSize.values().filter { m -> models.has(m) }.toSet()
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val all = readRecent()
            val alive = all.filter { r -> uriExists(r.uri) }
            if (alive.size != all.size) writeRecent(alive)
            _ui.update { it.copy(recent = alive) }
        }
    }

    // ---------- recent projects ----------
    private fun uriExists(u: String): Boolean = try {
        ctx.contentResolver.openFileDescriptor(Uri.parse(u), "r")?.use { true } ?: false
    } catch (e: Exception) {
        false
    }

    private fun readRecent(): List<Recent> = try {
        val a = org.json.JSONArray(prefs.getString("recent", "[]") ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Recent(o.getString("t"), o.getString("u"), o.getLong("m"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun writeRecent(l: List<Recent>) {
        val a = org.json.JSONArray()
        l.forEach { r -> a.put(org.json.JSONObject().put("t", r.title).put("u", r.uri).put("m", r.time)) }
        prefs.edit().putString("recent", a.toString()).apply()
    }

    fun openRecent(r: Recent) {
        _ui.update { it.copy(stage = Stage.Done(Uri.parse(r.uri)), debug = "") }
    }

    fun removeRecent(r: Recent) {
        val l = _ui.value.recent.filter { it.uri != r.uri }
        writeRecent(l)
        _ui.update { it.copy(recent = l) }
    }

    // ---------- settings ----------
    fun setTheme(id: String) { prefs.edit().putString("theme", id).apply(); _ui.update { it.copy(themeId = id) } }
    fun setStyle(id: String) {
        prefs.edit().putString("style", id).apply()
        val want = Styles.byId(id).font
        _ui.update { s ->
            val f = s.fonts.firstOrNull { it.name == want }?.id
            if (f != null) prefs.edit().putString("font", f).apply()
            s.copy(styleId = id, fontId = f ?: s.fontId)
        }
    }
    fun setLayout(l: CapLayout) {
        prefs.edit().putFloat("lx", l.x).putFloat("ly", l.y).putFloat("lmw", l.mw)
            .putFloat("lls", l.ls).putInt("llw", l.lw).putFloat("lsz", l.size).apply()
        _ui.update { it.copy(layout = l) }
    }
    fun setFont(id: String) { prefs.edit().putString("font", id).apply(); _ui.update { it.copy(fontId = id) } }
    fun setLanguage(l: String) { prefs.edit().putString("lang", l).apply(); _ui.update { it.copy(options = it.options.copy(language = l)) } }
    fun setModel(m: ModelSize) { prefs.edit().putString("model", m.id).apply(); _ui.update { it.copy(modelSize = m) } }
    fun setOptions(o: Options) { _ui.update { it.copy(options = o) } }
    fun setAccurate(v: Boolean) { prefs.edit().putBoolean("accurate", v).apply(); _ui.update { it.copy(accurate = v) } }

    fun addFont(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            }
            val id = fontStore.import(uri, name)
            val fonts = fontStore.list()
            _ui.update { it.copy(fonts = fonts, fontId = id ?: it.fontId) }
            if (id != null) prefs.edit().putString("font", id).apply()
        }
    }

    // ---------- flow ----------
    fun pickVideo(uri: Uri) {
        viewModelScope.launch {
            cloudBlocked = false
            _ui.update { it.copy(stage = Stage.Working("در حال آماده‌سازی ویدیو…", 0f), video = uri, phrases = emptyList(), notice = "") }
            // The picked file is copied into the app first: a video that lives in a cloud gallery (Google Photos, Mi Cloud)
            // would otherwise be read over the internet, which only works with a VPN.
            val local = try {
                copyToCache(uri) { p -> _ui.update { s -> s.copy(stage = Stage.Working("در حال آماده‌سازی ویدیو…", p)) } }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("ویدیو از حافظه‌ی گوشی خونده نشد (${e.message}). اگه ویدیو توی گوگل‌فوتوز یا گالری ابری بود، اول توی حافظه‌ی گوشی ذخیره‌ش کن و دوباره انتخابش کن.")) }
                return@launch
            }
            _ui.update { it.copy(video = local) }
            val info = try {
                withContext(Dispatchers.IO) { probe(local) }
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("این ویدیو باز نشد: ${e.message}")) }
                return@launch
            }
            _ui.update { it.copy(info = info) }
            if (models.has(_ui.value.modelSize) || cloudReady()) startTranscribe() else _ui.update { it.copy(stage = Stage.NeedModel) }
        }
    }

    /** Copies the picked video into the app's cache (with progress) and gives back the local file. Gives up after 30 s without a single new byte. */
    private suspend fun copyToCache(src: Uri, onProgress: (Float) -> Unit): Uri {
        if (src.scheme == "file") return src
        val size = try {
            ctx.contentResolver.query(src, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: -1L
        } catch (e: Exception) {
            -1L
        }
        val dir = java.io.File(ctx.cacheDir, "src").apply { mkdirs() }
        val f = java.io.File(dir, "v_" + (src.toString().hashCode().toLong() and 0xffffffffL) + "_" + size + ".mp4")
        if (f.exists() && f.length() > 0 && (size <= 0 || f.length() == size)) return Uri.fromFile(f)
        dir.listFiles()?.forEach { if (it != f) it.delete() }
        val tmp = java.io.File(dir, f.name + ".part")
        val copied = java.util.concurrent.atomic.AtomicLong(0)
        val failure = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        val stream = java.util.concurrent.atomic.AtomicReference<java.io.InputStream?>(null)
        val worker = Thread {
            try {
                val ins = ctx.contentResolver.openInputStream(src) ?: throw java.io.IOException("فایل باز نشد")
                stream.set(ins)
                ins.use { i ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            copied.addAndGet(n.toLong())
                        }
                    }
                }
            } catch (t: Throwable) {
                failure.set(t)
            }
        }
        worker.isDaemon = true
        worker.start()
        var last = -1L
        var lastChange = System.currentTimeMillis()
        while (worker.isAlive) {
            kotlinx.coroutines.delay(400)
            val v = copied.get()
            if (v != last) {
                last = v
                lastChange = System.currentTimeMillis()
                if (size > 0) onProgress((v.toFloat() / size).coerceIn(0f, 1f))
            }
            if (System.currentTimeMillis() - lastChange > 30_000) {
                try { stream.get()?.close() } catch (_: Exception) { }
                tmp.delete()
                throw java.io.IOException("۳۰ ثانیه هیچ داده‌ای نیومد")
            }
        }
        failure.get()?.let {
            tmp.delete()
            throw java.io.IOException(it.message ?: it.javaClass.simpleName)
        }
        if (size > 0 && tmp.length() != size) {
            tmp.delete()
            throw java.io.IOException("فایل ناقص کپی شد")
        }
        if (!tmp.renameTo(f)) throw java.io.IOException("ذخیره‌ی فایل نشد")
        return Uri.fromFile(f)
    }

    private fun probe(uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur <= 0 || w <= 0 || h <= 0) throw IllegalStateException("اطلاعات ویدیو ناقصه")
            return VideoInfo(dur, w, h)
        } finally {
            r.release()
        }
    }

    fun downloadModel() {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", 0f)) }
            try {
                models.download(m) { p -> _ui.update { s -> s.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", p)) } }
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("دانلود مدل نشد (${e.message}). اگه سایت فیلتره، فایل مدل رو جداگانه بگیر و با «وارد کردن فایل» انتخاب کن.")) }
            }
        }
    }

    fun importModel(uri: Uri) {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال وارد کردن مدل…", null)) }
            try {
                models.importFrom(uri, m)
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("وارد کردن مدل نشد: ${e.message}")) }
            }
        }
    }

    fun setCloud(account: String, token: String) {
        prefs.edit().putString("cf_acct", account).putString("cf_token", token).apply()
        _ui.update { it.copy(cfAccount = account, cfToken = token) }
    }

    fun setWorkerUrl(url: String) {
        prefs.edit().putString("worker_url", url).apply()
        _ui.update { it.copy(workerUrl = url) }
    }

    /** All online recognition addresses; each chunk starts at a different one and moves to the next if one fails (e.g. its daily limit is used up). */
    private fun cloudUrls(user: String): List<String> {
        val u = user.split(',', ' ', '\n').map { it.trim() }.filter { it.isNotEmpty() }
        return if (u.isNotEmpty() && user.trim() != Config.WORKER_URL) u else listOf(Config.WORKER_URL) + Config.WORKER_EXTRA
    }

    /** Online recognition is used only when the selected offline model is NOT on the phone: a downloaded or imported model always wins. */
    private fun cloudReady(): Boolean = !cloudBlocked && !models.has(_ui.value.modelSize) && (_ui.value.workerUrl.isNotBlank() || (_ui.value.cfAccount.isNotBlank() && _ui.value.cfToken.isNotBlank()))

    /** Quick check (5 s) of which online addresses answer at all. Without a VPN the Cloudflare address is blocked and never answers. */
    private fun reachableUrls(user: String): List<String> {
        val ok = ArrayList<String>()
        for (u in cloudUrls(user)) {
            try {
                val c = (java.net.URL(u).openConnection() as java.net.HttpURLConnection).apply {
                    connectTimeout = 5_000
                    readTimeout = 5_000
                    requestMethod = "GET"
                }
                try { c.responseCode } finally { c.disconnect() }
                ok.add(u)
            } catch (e: Exception) {
            }
        }
        return ok
    }

    fun retryCloud() {
        cloudBlocked = false
        _ui.update { it.copy(notice = "") }
        startTranscribe()
    }

    private var wake: android.os.PowerManager.WakeLock? = null

    private fun lockOn() {
        try {
            if (wake == null) {
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                wake = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "zircut:work")
            }
            if (wake?.isHeld != true) wake?.acquire(30 * 60 * 1000L)
        } catch (_: Exception) {
        }
    }

    private fun lockOff() {
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (_: Exception) {
        }
    }

    fun startTranscribe() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val modelFile = models.file(st.modelSize)
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.Default) {
            val bridge = WhisperBridge()
            var wctx = 0L
            lockOn()
            try {
                _ui.update { it.copy(stage = Stage.Working("در حال خواندن صدا…", 0f), transcribing = true) }
                val raw = ArrayList<Word>()
                val t0 = System.currentTimeMillis()
                var cloudOk = false
                var cloudErr = ""
                var nChunks = 0
                val useBeam = if (st.accurate) st.modelSize.beam else 1
                val tag = st.options.language + "|" + (if (cloudReady()) "cloud" else st.modelSize.id + "|b" + useBeam) + "|v4"
                val cacheF = cacheFile(uri, info, tag)
                val cached = if (cacheF != null) loadRaw(cacheF) else null
                if (cached != null) raw.addAll(cached)
                if (cached == null) {
                var onlineUrls: List<String> = emptyList()
                CloudTranscriber.answeredCount.set(0)
                CloudTranscriber.polishedCount.set(0)
                if (cloudReady()) {
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال اتصال به سرویس آنلاین…", null)) }
                    // no separate pre-check any more: it failed on a single slow answer even when uploads worked.
                    // The real uploads below retry on their own and report the real error.
                    onlineUrls = cloudUrls(st.workerUrl)
                }
                val pcm = AudioDecoder.decode(ctx, uri) { p ->
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال خواندن صدا…", p)) }
                }
                ensureActive()
                val chunks = AudioDecoder.chunkSpeech(pcm)
                nChunks = chunks.size
                if (onlineUrls.isNotEmpty()) {
                    try {
                        // small uploads (about 10 s of audio each) survive weak or filtered connections much better than big ones
                        val cchunks = AudioDecoder.chunk(pcm, 25)
                        nChunks = cchunks.size
                        val sem = Semaphore(3)
                        val done = java.util.concurrent.atomic.AtomicInteger(0)
                        val results = coroutineScope {
                            cchunks.mapIndexed { ci, c ->
                                async(Dispatchers.IO) {
                                    sem.withPermit {
                                        var ws: List<CloudTranscriber.W>? = null
                                        var err: Exception? = null
                                        val urls = onlineUrls
                                        for (attempt in 0 until maxOf(5, urls.size)) {
                                            try {
                                                ws = CloudTranscriber.transcribe(urls[(ci + attempt) % urls.size], st.cfAccount, st.cfToken, c.samples, st.options.language)
                                                break
                                            } catch (e: kotlinx.coroutines.CancellationException) {
                                                throw e
                                            } catch (e: Exception) {
                                                err = e
                                                kotlinx.coroutines.delay(800)
                                            }
                                        }
                                        // only "music" (or nothing) came back although there is sound: try again with the voice band and a "speaker over music" hint
                                        val first = ws
                                        if (first != null && CloudTranscriber.isMusicOnly(first) && Dsp.rms(c.samples) > 0.01f) {
                                            try {
                                                val alt = CloudTranscriber.transcribe(urls[ci % urls.size], st.cfAccount, st.cfToken, Dsp.speechBand(c.samples), st.options.language, true)
                                                if (alt.isNotEmpty() && !CloudTranscriber.isMusicOnly(alt)) ws = alt
                                            } catch (e: kotlinx.coroutines.CancellationException) {
                                                throw e
                                            } catch (_: Exception) {
                                            }
                                        }
                                        val d = done.incrementAndGet()
                                        _ui.update { s -> s.copy(stage = Stage.Working("تشخیص گفتار آنلاین… ($d از ${cchunks.size})", d.toFloat() / cchunks.size)) }
                                        ws ?: throw (err ?: IllegalStateException("پاسخی نیامد"))
                                    }
                                }
                            }.awaitAll()
                        }
                        cchunks.forEachIndexed { i, c ->
                            for (w in results[i]) {
                                val a = c.toSrc(w.startMs)
                                raw.add(Word(w.text, a, maxOf(c.toSrc(w.endMs), a + 50)))
                            }
                        }
                        cloudOk = raw.isNotEmpty()
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        cloudErr = when (e) {
                            is java.net.UnknownHostException -> "اینترنت قطعه یا آدرس سرویس پیدا نشد"
                            is java.net.SocketTimeoutException -> "سرویس دیر جواب داد"
                            is java.net.ConnectException -> "اتصال به سرویس برقرار نشد"
                            else -> e.message ?: ""
                        }
                        raw.clear()
                    }
                }
                if (!cloudOk) {
                if (!models.has(st.modelSize)) {
                    val why = if (cloudBlocked) "سرویس آنلاین بدون فیلترشکن باز نمی‌شه. فیلترشکن رو روشن کن و «تلاش دوباره» رو بزن؛ یا مدل آفلاین رو فقط یک بار دانلود کن (معمولاً بدون فیلترشکن دانلود می‌شه)."
                    else "تشخیص آنلاین انجام نشد" + (if (cloudErr.isNotEmpty()) " ($cloudErr)" else "") + ". فیلترشکن رو چک کن و دوباره امتحان کن، یا مدل آفلاین رو دانلود کن."
                    _ui.update { it.copy(stage = Stage.NeedModel, notice = why) }
                    return@launch
                }
                if (!WhisperBridge.cpuSupportsFast()) throw IllegalStateException("پردازنده‌ی این گوشی قدیمی است و از نسخه‌ی سریع تشخیص گفتار پشتیبانی نمی‌کند.")
                if (!modelFile.exists()) {
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال آماده‌سازی مدل (فقط بار اول، چند ثانیه)…", 0f)) }
                    models.ensureBundled(st.modelSize)
                }
                wctx = bridge.loadModel(modelFile.absolutePath)
                if (wctx == 0L) throw IllegalStateException("مدل بارگذاری نشد. فایل مدل خراب یا ناقصه.")
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
                val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(4, 8)
                chunks.forEachIndexed { i, c ->
                    ensureActive()
                    val eta = if (i == 0) "" else {
                        val left = (System.currentTimeMillis() - t0) / i * (chunks.size - i) / 60000.0
                        " · حدود ${if (left < 1.0) "کمتر از ۱" else (left + 0.5).toInt().toString()} دقیقه مانده"
                    }
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال تشخیص گفتار… (${i + 1} از ${chunks.size})$eta", i.toFloat() / chunks.size)) }
                    val rows = bridge.transcribe(wctx, c.samples, st.options.language, threads, useBeam)
                    for (row in rows) {
                        val p = row.split('\t', limit = 4)
                        if (p.size < 4) continue
                        val s = p[0].toLongOrNull() ?: continue
                        val e = p[1].toLongOrNull() ?: continue
                        val a = c.toSrc(s)
                        raw.add(Word(p[3], a, maxOf(c.toSrc(maxOf(e, s + 50)), a + 50), conf = (p[2].toIntOrNull() ?: 1000) / 1000f))
                    }
                }
                }
                if (cacheF != null && raw.isNotEmpty() && (cloudOk || !tag.contains("|cloud|"))) saveRaw(cacheF, raw)
                }
                val totalS = (System.currentTimeMillis() - t0) / 1000
                val perfText = if (cached != null) "از حافظه (تشخیص دوباره انجام نشد)" else
                    "${if (cloudOk) "آنلاین" else "مدل " + st.modelSize.id + (if (useBeam > 1) " (دقیق)" else " (سریع)")} · ${nChunks} تکه · کل ${totalS} ثانیه · هر تکه ${totalS / maxOf(1, nChunks)} ثانیه" +
                    (if (cloudOk) " · اصلاح املا: ${CloudTranscriber.polishedCount.get()} از ${CloudTranscriber.answeredCount.get()} تکه" else "") + " · ${raw.size} کلمه تا ثانیه ${(raw.maxOfOrNull { it.endMs } ?: 0L) / 1000} از ${info.durationMs / 1000}"
                _ui.update { it.copy(perf = perfText) }
                val words = Planner.clean(raw, st.options.removeFillers, st.options.language)
                if (words.isEmpty()) {
                    throw IllegalStateException("هیچ گفتاری تشخیص داده نشد (تعداد خام: ${raw.size}). مدل بزرگ‌تر (base یا small) را امتحان کن یا ویدیویی با صدای واضح‌تر بده.")
                }
                val fx = builtinFixes() + loadFixes()
                val fixed = words.map { w ->
                    val core = fixKey(w.text)
                    val repl = fx[core]
                    if (repl != null && w.text.contains(core)) w.copy(text = w.text.replaceFirst(core, repl), conf = 1f) else w
                }
                val fixedPairs = fixed.toMutableList()
                for (i in 0 until fixedPairs.size - 1) {
                    val r = pairFixes[fixKey(fixedPairs[i].text) + " " + fixKey(fixedPairs[i + 1].text)] ?: continue
                    fixedPairs[i] = fixedPairs[i].copy(text = r.first)
                    fixedPairs[i + 1] = fixedPairs[i + 1].copy(text = r.second)
                }
                val phrases = Planner.phrases(fixedPairs)
                _ui.update { it.copy(phrases = phrases, original = phrases, stage = Stage.Review) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                _ui.update { it.copy(stage = Stage.Failed(e.message ?: "خطای ناشناخته")) }
            } finally {
                if (wctx != 0L) bridge.release(wctx)
                _ui.update { it.copy(transcribing = false) }
                lockOff()
            }
        }
    }


    // ---------- transcript cache (same video + same settings = no second recognition) ----------
    private fun cacheFile(uri: Uri, info: VideoInfo, tag: String): File? {
        var name = ""
        var size = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i) ?: ""
                    val j = c.getColumnIndex(OpenableColumns.SIZE)
                    if (j >= 0) size = c.getLong(j)
                }
            }
        } catch (_: Exception) {
        }
        if (name.isEmpty() || size <= 0L) return null
        val key = "$name|$size|${info.durationMs}|${info.width}x${info.height}|$tag"
        val h = java.security.MessageDigest.getInstance("SHA-1").digest(key.toByteArray()).joinToString("") { "%02x".format(it) }
        val dir = File(ctx.cacheDir, "transcripts").apply { mkdirs() }
        dir.listFiles()?.sortedBy { it.lastModified() }?.dropLast(30)?.forEach { it.delete() }
        return File(dir, "$h.json")
    }

    private fun saveRaw(f: File, raw: List<Word>) {
        try {
            val a = org.json.JSONArray()
            for (w in raw) a.put(org.json.JSONArray().put(w.text).put(w.startMs).put(w.endMs).put(w.conf.toDouble()))
            f.writeText(a.toString())
        } catch (_: Exception) {
        }
    }

    private fun loadRaw(f: File): List<Word>? = try {
        if (!f.exists()) null else {
            val a = org.json.JSONArray(f.readText())
            val out = ArrayList<Word>(a.length())
            for (i in 0 until a.length()) {
                val r = a.getJSONArray(i)
                out.add(Word(r.getString(0), r.getLong(1), r.getLong(2), conf = r.getDouble(3).toFloat()))
            }
            if (out.isEmpty()) null else out
        }
    } catch (e: Exception) {
        null
    }

    /** Common recognition mistakes that are always wrong; the user's own corrections are added on top of these. */
    private fun builtinFixes(): Map<String, String> = mapOf(
        "سانیه" to "ثانیه",
        "سانیه‌ی" to "ثانیه‌ی",
        "ثانیع" to "ثانیه",
        "دقیغه" to "دقیقه",
        "پونسد" to "پونصد",
        "استفا" to "استعفا",
        "حیام" to "پیام",
        "میخچاهیم" to "می‌خوام",
        "می‌خچاهیم" to "می‌خوام",
        "کنچکاوت" to "کنجکاوت",
        "کنچکاو" to "کنجکاو",
        "پوریس" to "پلیس"
    )

    /** Two-word mistakes that are never real Persian. */
    private val pairFixes: Map<String, Pair<String, String>> = mapOf(
        "ته سانیه" to ("بیست" to "ثانیه"),
        "ته ثانیه" to ("بیست" to "ثانیه"),
        "چجی پیتی" to ("چت‌جی" to "پی‌تی")
    )

    private fun fixKey(t: String): String = t.trim().trim { !it.isLetterOrDigit() }.lowercase()

    private fun loadFixes(): Map<String, String> = try {
        val o = org.json.JSONObject(prefs.getString("fixes", "{}") ?: "{}")
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    /** Remembers the words the user corrected, so the same mistake is fixed automatically next time. */
    private fun learnFixes(orig: List<Phrase>, now: List<Phrase>) {
        if (orig.size != now.size) return
        val m = loadFixes().toMutableMap()
        for (i in orig.indices) {
            if (orig[i].words.size != now[i].words.size) continue
            for (j in orig[i].words.indices) {
                val a = fixKey(orig[i].words[j].text)
                val b = fixKey(now[i].words[j].text)
                if (a.length >= 2 && b.length >= 2 && a != b && !b.contains(' ')) m[a] = b
            }
        }
        while (m.size > 500) m.remove(m.keys.first())
        prefs.edit().putString("fixes", org.json.JSONObject(m as Map<*, *>).toString()).apply()
    }

    fun editPhrase(index: Int, text: String) {
        _ui.update { s ->
            if (index !in s.phrases.indices) return@update s
            val list = s.phrases.toMutableList()
            list[index] = Planner.rebuild(list[index], text)
            s.copy(phrases = list)
        }
    }

    fun mergeWithNext(i: Int) {
        _ui.update { s ->
            if (i < 0 || i >= s.phrases.size - 1) s else {
                val l = s.phrases.toMutableList()
                l[i] = Phrase(l[i].words + l[i + 1].words)
                l.removeAt(i + 1)
                s.copy(phrases = l)
            }
        }
    }

    fun deletePhrase(i: Int) {
        _ui.update { s ->
            if (i !in s.phrases.indices) s else s.copy(phrases = s.phrases.toMutableList().also { it.removeAt(i) })
        }
    }

    /** Connection test: shows exactly which step fails (DNS, connect, small upload, big upload). */
    fun diagnose() {
        _ui.update { it.copy(diag = "در حال تست… (تا ۱ دقیقه)") }
        viewModelScope.launch(Dispatchers.IO) {
            val sb = StringBuilder()
            fun line(t: String) {
                sb.append(t).append('\n')
                _ui.update { it.copy(diag = sb.toString()) }
            }
            fun post(url: String, bytes: Int): Boolean {
                val t = System.currentTimeMillis()
                try {
                    val body = ("{\"audio\":\"" + "A".repeat(bytes) + "\"}").toByteArray()
                    val c = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 8_000
                        readTimeout = 20_000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setFixedLengthStreamingMode(body.size)
                    }
                    try {
                        c.outputStream.use { it.write(body) }
                        val code = c.responseCode
                        line("آپلود ${bytes / 1000}KB: رسید (کد $code) · ${System.currentTimeMillis() - t}ms")
                        return true
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    line("آپلود ${bytes / 1000}KB: قطع شد ← ${e.javaClass.simpleName}: ${e.message} · ${System.currentTimeMillis() - t}ms")
                    return false
                }
            }
            val base = cloudUrls(_ui.value.workerUrl).first()
            val host = try { java.net.URL(base).host } catch (e: Exception) { base }
            line("آدرس: $base")
            val t0 = System.currentTimeMillis()
            try {
                val a = java.net.InetAddress.getAllByName(host)
                line("DNS درسته: ${a.joinToString { it.hostAddress ?: "" }} · ${System.currentTimeMillis() - t0}ms")
            } catch (e: Exception) {
                line("DNS خراب: ${e.javaClass.simpleName}")
            }
            try {
                val t1 = System.currentTimeMillis()
                val c = (java.net.URL(base).openConnection() as java.net.HttpURLConnection).apply { connectTimeout = 8_000; readTimeout = 8_000 }
                try { line("اتصال ساده: باز شد (کد ${c.responseCode}) · ${System.currentTimeMillis() - t1}ms") } finally { c.disconnect() }
            } catch (e: Exception) {
                line("اتصال ساده: نشد ← ${e.javaClass.simpleName}: ${e.message}")
            }
            val sizes = listOf(10_000, 25_000, 50_000, 100_000)
            var firstBad = -1
            for (z in sizes) if (!post(base, z) && firstBad < 0) firstBad = z
            // real test: a 3 s compressed clip, exactly what the app uploads
            try {
                val n = 3 * 16000
                val tone = FloatArray(n) { i -> (0.3 * Math.sin(2 * Math.PI * 220 * i / 16000.0) * (0.5 + 0.5 * Math.sin(2 * Math.PI * 3 * i / 16000.0))).toFloat() }
                val aac = app.zircut.core.AacEncoder.encode(tone)
                val b64 = android.util.Base64.encodeToString(aac, android.util.Base64.NO_WRAP)
                val body = ("{\"audio\":\"" + b64 + "\",\"task\":\"transcribe\"}").toByteArray()
                val t = System.currentTimeMillis()
                val c = (java.net.URL(base).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 8_000; readTimeout = 40_000; doOutput = true
                    setRequestProperty("Content-Type", "application/json"); setFixedLengthStreamingMode(body.size)
                }
                try {
                    c.outputStream.use { it.write(body) }
                    val code = c.responseCode
                    val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                    line("کلیپ فشرده ۳ثانیه‌ای (${body.size / 1000}KB): کد $code · ${System.currentTimeMillis() - t}ms")
                    line("پاسخ: " + txt.take(150))
                } finally { c.disconnect() }
            } catch (e: Exception) {
                line("کلیپ فشرده: قطع شد ← ${e.javaClass.simpleName}: ${e.message}")
            }
            line("— مقایسه: همین آپلود به یه سایت دیگه (cloudflare.com) —")
            val other = post("https://www.cloudflare.com/", 400_000)
            line(
                when {
                    firstBad < 0 -> "نتیجه: آپلود به سرویس سالمه. مشکل از چیز دیگه‌ایه؛ این متن رو برام بفرست."
                    firstBad <= 10_000 -> "نتیجه: حتی آپلود کوچیک هم قطع می‌شه؛ آدرس سرویس از این اینترنت بسته‌ست."
                    other -> "نتیجه: آپلودهای بزرگ‌تر از ${firstBad / 1000}KB به سرویس ما قطع می‌شن. برنامه صدا رو فشرده و تکه‌های کوچک می‌فرسته، ولی اگه باز هم قطع شد این متن رو برام بفرست."
                    else -> "نتیجه: آپلود حجیم روی کل این اینترنت قطع می‌شه (از خود شبکه‌ست)."
                }
            )
        }
    }

    fun cancel() {
        exporter?.cancel()
        job?.cancel()
        _ui.update { it.copy(stage = if (it.phrases.isNotEmpty()) Stage.Review else Stage.Idle) }
    }

    fun reset() {
        job?.cancel()
        _ui.update { it.copy(stage = Stage.Idle, video = null, info = null, phrases = emptyList()) }
    }

    fun backToReview() { _ui.update { it.copy(stage = Stage.Review) } }

    // ---------- export ----------
    fun export() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val words = st.phrases.flatMap { it.words }
        val ranges = Planner.ranges(words, info.durationMs, st.options)
        val font = st.fonts.firstOrNull { it.id == st.fontId }?.typeface ?: Typeface.DEFAULT_BOLD
        val out = File(ctx.cacheDir, "zircut_out.mp4").also { it.delete() }
        Diag.reset()
        try { learnFixes(st.original, st.phrases) } catch (_: Exception) { }
        lockOn()
        val first = st.phrases.firstOrNull()
        val dbg = st.perf + "\n" + "عبارت‌ها ${st.phrases.size} · کلمه‌ها ${words.size} · بازه‌ها ${ranges.size} · مجموع ${ranges.sumOf { it.len }}ms از ${info.durationMs}ms · زیرنویس=${st.options.captions} · عمودی=${st.options.vertical}" +
            (if (first != null) "\nاولین عبارت: «${first.words.joinToString(" ") { it.text }}» از ${first.startMs} تا ${first.endMs}ms" else "\nهیچ عبارتی وجود ندارد")
        _ui.update { it.copy(debug = dbg, stage = Stage.Working("در حال ساخت ویدیو…", 0f)) }

        val ex = Exporter(ctx)
        exporter = ex
        ex.start(
            Exporter.Params(uri, info, ranges, st.phrases, Styles.byId(st.styleId), font, st.options, out, st.layout),
            onProgress = { p -> _ui.update { s -> if (s.stage is Stage.Working) s.copy(stage = Stage.Working("در حال ساخت ویدیو…", p)) else s } },
            onDone = {
                lockOff()
                viewModelScope.launch {
                    try {
                        val saved = withContext(Dispatchers.IO) { saveToGallery(out) }
                        val title = st.phrases.firstOrNull()?.text?.take(60) ?: "ویدیوی بدون گفتار"
                        val list = (listOf(Recent(title, saved.toString(), System.currentTimeMillis())) + _ui.value.recent)
                            .distinctBy { it.uri }.take(20)
                        writeRecent(list)
                        _ui.update { it.copy(debug = it.debug + "\n" + Diag.text(), stage = Stage.Done(saved), recent = list) }
                    } catch (e: Exception) {
                        _ui.update { it.copy(stage = Stage.Failed("ذخیره ویدیو نشد: ${e.message}")) }
                    }
                }
            },
            onError = { msg -> lockOff(); _ui.update { it.copy(stage = Stage.Failed(msg)) } }
        )
    }

    private fun saveToGallery(file: File): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ZirCut_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZirCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("دسترسی به گالری ممکن نشد")
        resolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }
}
