package app.zircut.timeline

/**
 * A text or picture laid over the video (part 4). Times are positions on the EDITED timeline
 * (the same time line as the playhead), x/y are the layer centre as a fraction of the output frame,
 * rotation is in degrees clockwise. Layers are drawn in list order (later = on top).
 */
data class Layer(
    val id: Int,
    val kind: Int,
    val startMs: Long,
    val endMs: Long,
    val x: Float = 0.5f,
    val y: Float = 0.5f,
    val scale: Float = 1f,
    val rotation: Float = 0f,
    val opacity: Float = 1f,
    /** text layers */
    val text: String = "",
    val color: Int = 0xFFFFFFFF.toInt(),
    /** 0 = no background box */
    val bgColor: Int = 0,
    val stroke: Boolean = true,
    /** "" = the project's subtitle font */
    val fontId: String = "",
    /** picture layers: file inside the project folder */
    val file: String = "",
    val imgW: Int = 0,
    val imgH: Int = 0,
    /** locked: cannot be moved, edited, split, moved in order or deleted until unlocked */
    val locked: Boolean = false,
    /** hidden: kept on the timeline but not drawn in the preview or the exported video */
    val hidden: Boolean = false
) {
    val isText: Boolean get() = kind == KIND_TEXT
    val len: Long get() = endMs - startMs
    fun visibleAt(ms: Long): Boolean = ms >= startMs && ms < endMs

    companion object {
        const val KIND_TEXT = 0
        const val KIND_IMAGE = 1
        const val MIN_MS = 200L
    }
}

object LayerOps {
    /** the timeline shows at most this many rows of layers; more overlapping layers share the last row */
    const val MAX_ROWS = 3

    fun nextId(layers: List<Layer>): Int = (layers.maxOfOrNull { it.id } ?: 0) + 1

    /** Row of every layer on the timeline: layers that overlap in time go to different rows. */
    fun rows(layers: List<Layer>): IntArray {
        val order = layers.indices.sortedBy { layers[it].startMs }
        val rowEnd = ArrayList<Long>()
        val res = IntArray(layers.size)
        for (i in order) {
            val l = layers[i]
            var r = rowEnd.indexOfFirst { it <= l.startMs }
            if (r < 0) {
                rowEnd.add(l.endMs)
                r = rowEnd.size - 1
            } else {
                rowEnd[r] = l.endMs
            }
            res[i] = minOf(r, MAX_ROWS - 1)
        }
        return res
    }

    fun rowCount(rows: IntArray): Int {
        if (rows.isEmpty()) return 0
        var m = 0
        for (r in rows) if (r > m) m = r
        return m + 1
    }

    /** Cuts one layer into two at [at]. Null when a piece would be shorter than the minimum. */
    fun split(layers: List<Layer>, id: Int, at: Long): List<Layer>? {
        val i = layers.indexOfFirst { it.id == id }
        if (i < 0) return null
        val l = layers[i]
        if (at - l.startMs < Layer.MIN_MS || l.endMs - at < Layer.MIN_MS) return null
        val n = ArrayList(layers)
        n[i] = l.copy(endMs = at)
        n.add(i + 1, l.copy(id = nextId(layers), startMs = at))
        return n
    }

    /** Moves a layer one step up (+1, drawn later = on top) or down (-1) in the drawing order. */
    fun move(layers: List<Layer>, id: Int, dir: Int): List<Layer>? {
        val i = layers.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j < 0 || j >= layers.size) return null
        val n = ArrayList(layers)
        val t = n[i]; n[i] = n[j]; n[j] = t
        return n
    }

    fun normDeg(v: Float): Float {
        var r = v % 360f
        if (r > 180f) r -= 360f
        if (r < -180f) r += 360f
        return r
    }
}
