# زیرکات (ZirCut)

ادیتور خودکار ویدیو برای اندروید: زیرنویس خودکار فارسی/انگلیسی (Whisper روی خود گوشی)، حذف سکوت و «ام…»، زوم ریتمی، خروجی عمودی ۹:۱۶.

## ساخت APK فقط با گوشی (بدون کامپیوتر)

1. توی github.com یه ریپوی جدید بساز (Public یا Private).
2. تو ریپو: Add file ← Create new file. اسم فایل رو دقیقاً `.github/workflows/build.yml` بنویس و محتوای فایل `build.yml` رو توش بچسبون. Commit کن.
3. Add file ← Upload files و فایل `zircut_project.zip` رو آپلود کن (همون zip، بازش نکن). Commit کن.
4. تب Actions ← Build APK. اگه خودکار شروع نشد، Run workflow بزن. حدود ۸ تا ۱۵ دقیقه طول می‌کشه.
5. وقتی سبز شد، همون صفحه پایین بخش Artifacts، فایل `ZirCut-apk` رو دانلود کن (zip می‌شه، بازش کن) و `ZirCut.apk` رو نصب کن.

اگه ساخت قرمز شد، متن خطای آخر لاگ رو برای Claude بفرست تا درست کنه.

نکته: هر بار ساخت، امضای APK فرق داره. قبل از نصب نسخه جدید، نسخه قبلی رو پاک کن.

## ساختار

- `app/src/main/cpp` — پل JNI به whisper.cpp (خود whisper.cpp موقع ساخت دانلود می‌شه)
- `core/AudioDecoder` — خواندن صدای ویدیو و تبدیل به ۱۶kHz
- `core/Planner` — حذف سکوت و ساخت عبارت‌های زیرنویس
- `core/CaptionRenderer` + `core/Exporter` — زیرنویس متحرک و رندر نهایی با Media3
- `ui/` — رابط Compose با تم‌های پس‌زمینه


## fix189
UI updates: nine caption-position presets, layer size presets, 90-degree rotation, layer reset, four audio fade presets, and trim audio to playhead.
