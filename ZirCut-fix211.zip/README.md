# زیرکات (ZirCut)

ادیتور خودکار ویدیو برای اندروید: زیرنویس خودکار فارسی/انگلیسی (Whisper روی خود گوشی)، حذف سکوت و «ام…»، زوم ریتمی، خروجی عمودی ۹:۱۶.

## ساخت APK فقط با گوشی (بدون کامپیوتر)

1. توی github.com یه ریپوی جدید بساز (Public یا Private).
2. تو ریپو: Add file ← Create new file. اسم فایل رو دقیقاً `.github/workflows/build.yml` بنویس و محتوای فایل `build.yml` رو توش بچسبون. Commit کن.
3. Add file ← Upload files و فایل `zircut_project.zip` رو آپلود کن (همون zip، بازش نکن). Commit کن.
4. تب Actions ← Build APK. اگه خودکار شروع نشد، Run workflow بزن. حدود ۸ تا ۱۵ دقیقه طول می‌کشه.
5. وقتی سبز شد، همون صفحه پایین بخش Artifacts، فایل `ZirCut-apk` رو دانلود کن (zip می‌شه، بازش کن) و `ZirCut.apk` رو نصب کن.

اگه ساخت قرمز شد، متن خطای آخر لاگ رو برای Claude بفرست تا درست کنه.

نکته: هر بار ساخت، امضای APK فرق داره. قبل از نصب نسخه جدید، نسخه قبلی رو پاک کن.

## ساختار

- `app/src/main/cpp` — پل JNI به whisper.cpp (خود whisper.cpp موقع ساخت دانلود می‌شه)
- `core/AudioDecoder` — خواندن صدای ویدیو و تبدیل به ۱۶kHz
- `core/Planner` — حذف سکوت و ساخت عبارت‌های زیرنویس
- `core/CaptionRenderer` + `core/Exporter` — زیرنویس متحرک و رندر نهایی با Media3
- `ui/` — رابط Compose با تم‌های پس‌زمینه


## fix189
UI updates: nine caption-position presets, layer size presets, 90-degree rotation, layer reset, four audio fade presets, and trim audio to playhead.

## fix198
Freeze frame (clip tab): turns the frame under the playhead into a photo clip of 1-5 s.

## fix199
Output aspect ratio: 9:16, 16:9, 1:1, 4:5, original.

## fix200
Rotate 90, zoom and pan of the video picture (clip tab).

## fix201
Clip speed 0.25x-4x and speed ramps.

## fix202
Mirror (flip) horizontal/vertical for video picture.

## fix203
Audio: noise reduction (3 strengths) for music/voice clips.

## fix204
Audio: 3-band equaliser for music/voice clips.

## fix205
Timeline: multi-select clips (copy / delete / speed).

## fix206
Transform: free-angle rotation (-45..45 deg, auto-zoom).

## fix207
Output frame: free aspect ratio (0.4-2.5).

## fix208
Subtitles: split into short parts, exact timing nudge, undo for subtitle edits.

## fix209
Audio: extract the video's sound into an audio clip (then noise reduction / EQ apply to it).

## fix210
Layers: colour key (green/blue/white/black) for picture layers.

## fix211
Audio: silence removal for audio clips.
