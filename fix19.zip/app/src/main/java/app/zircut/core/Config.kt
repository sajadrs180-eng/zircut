package app.zircut.core

object Config {
    /** Address of the ZirCut online recognition service (Cloudflare Worker). Users need no key. */
    const val WORKER_URL = "https://zircut.sajadrs1818.workers.dev"
}
