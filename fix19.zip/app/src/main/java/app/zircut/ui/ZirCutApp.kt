@file:OptIn(ExperimentalMaterial3Api::class)

package app.zircut.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.view.WindowManager
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.Slider
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import app.zircut.core.CapLayout
import app.zircut.core.CaptionRenderer
import app.zircut.core.Phrase
import app.zircut.core.Word
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import app.zircut.MainViewModel
import app.zircut.Stage
import app.zircut.core.ModelSize
import app.zircut.core.Planner
import app.zircut.core.Styles

private val CardBg = Color(0xCC12122E)

@UnstableApi
@Composable
fun ZirCutApp(vm: MainViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val keepOn = ui.stage is Stage.Working
    val hostView = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(keepOn) {
        hostView.keepScreenOn = keepOn
        onDispose { hostView.keepScreenOn = false }
    }
    val theme = Themes.byId(ui.themeId)
    var showSettings by remember { mutableStateOf(false) }
    val busy = ui.stage is Stage.Working

    val ctx = LocalContext.current
    DisposableEffect(busy) {
        val w = (ctx as? Activity)?.window
        if (busy) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.pickVideo(uri)
    }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.addFont(uri)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            Image(
                painter = painterResource(theme.res),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x55000000)))

            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("زیرکات", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showSettings = true }) { Text("تنظیمات") }
                }
                Spacer(Modifier.height(12.dp))

                when (val s = ui.stage) {
                    is Stage.Idle -> Panel {
                        Text("ویدیوت رو انتخاب کن", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("زیرنویس خودکار، حذف سکوت و «ام…»، زوم و خروجی عمودی برای ریلز و شورت", color = Color(0xFFCFCBEA))
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("انتخاب ویدیو") }
                    }

                    is Stage.NeedModel -> Panel {
                        Text("یه مدل تشخیص گفتار لازمه", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text("فقط بار اول دانلود می‌شه و بعدش همه‌چیز آفلاین کار می‌کنه.", color = Color(0xFFCFCBEA))
                        Spacer(Modifier.height(12.dp))
                        ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.downloadModel() }, modifier = Modifier.fillMaxWidth()) {
                            Text("دانلود مدل (${ui.modelSize.sizeMb} مگابایت)")
                        }
                        OutlinedButton(
                            onClick = { modelPicker.launch(arrayOf("*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("وارد کردن فایل مدل (.bin)") }
                        TextButton(onClick = { vm.reset() }) { Text("انصراف") }
                    }

                    is Stage.Working -> Panel {
                        Text(s.label, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(16.dp))
                        if (s.progress == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        else LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(12.dp))
                        Text("صفحه رو روشن نگه دار. ممکنه چند دقیقه طول بکشه.", color = Color(0xFFCFCBEA))
                        if (ui.transcribing) {
                            Spacer(Modifier.height(12.dp))
                            Text("تا اینجا تموم بشه، استایل زیرنویس رو انتخاب کن:", color = Color.White, style = MaterialTheme.typography.titleSmall)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Styles.all.forEach { st ->
                                    FilterChip(selected = ui.styleId == st.id, onClick = { vm.setStyle(st.id) }, label = { Text(st.nameFa) })
                                }
                            }
                        }
                        TextButton(onClick = { vm.cancel() }) { Text("لغو") }
                    }

                    is Stage.Review -> {
                        val info = ui.info
                        val words = ui.phrases.flatMap { it.words }
                        val kept = if (info != null) Planner.ranges(words, info.durationMs, ui.options).sumOf { it.len } else 0L
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                            item {
                                Panel {
                                    Text("تنظیمات ادیت", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    SwitchRow("زیرنویس", ui.options.captions) { vm.setOptions(ui.options.copy(captions = it)) }
                                    SwitchRow("حذف سکوت‌ها", ui.options.removeSilence) { vm.setOptions(ui.options.copy(removeSilence = it)) }
                                    SwitchRow("زوم ریتمی", ui.options.zoom) { vm.setOptions(ui.options.copy(zoom = it)) }
                                    SwitchRow("خروجی عمودی (۹:۱۶)", ui.options.vertical) { vm.setOptions(ui.options.copy(vertical = it)) }
                                    if (info != null) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            "مدت ویدیو: ${info.durationMs / 1000} ثانیه  ←  بعد از ادیت: ${kept / 1000} ثانیه",
                                            color = Color(0xFFCFCBEA)
                                        )
                                    }
                                }
                            }
                            item {
                                Panel {
                                    Text("پیش‌نمایش و جایگاه زیرنویس", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    val pvStyle = Styles.byId(ui.styleId)
                                    val pvFont = ui.fonts.firstOrNull { it.id == ui.fontId }?.typeface ?: android.graphics.Typeface.DEFAULT_BOLD
                                    val pvPhrase = ui.phrases.firstOrNull() ?: Phrase(listOf(Word("سلام", 0, 400), Word("به", 400, 700), Word("کانال", 700, 1100), Word("ما", 1100, 1400)))
                                    CaptionPreview(pvPhrase, pvStyle, pvFont, ui.layout)
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("بالا" to 0.2f, "بالا‌میانه" to 0.36f, "وسط" to 0.5f, "پایین ایمن" to 0.66f, "خیلی پایین" to 0.82f).forEach { (n, y) ->
                                            FilterChip(selected = kotlin.math.abs(ui.layout.y - y) < 0.02f, onClick = { vm.setLayout(ui.layout.copy(y = y)) }, label = { Text(n) })
                                        }
                                    }
                                    LabeledSlider("اندازه", ui.layout.size, 0.6f, 1.5f) { vm.setLayout(ui.layout.copy(size = it)) }
                                    LabeledSlider("جای عمودی", ui.layout.y, 0.08f, 0.94f) { vm.setLayout(ui.layout.copy(y = it)) }
                                    LabeledSlider("جای افقی", ui.layout.x, 0.1f, 0.9f) { vm.setLayout(ui.layout.copy(x = it)) }
                                    LabeledSlider("عرض متن", ui.layout.mw, 0.4f, 0.96f) { vm.setLayout(ui.layout.copy(mw = it)) }
                                    LabeledSlider("فاصله خطوط", ui.layout.ls, 1.1f, 2f) { vm.setLayout(ui.layout.copy(ls = it)) }
                                    LabeledSlider("کلمه در هر خط", ui.layout.lw.toFloat(), 1f, 6f, steps = 4) { vm.setLayout(ui.layout.copy(lw = it.toInt())) }
                                    Text("نکته: با گذاشتن * اول یک کلمه در متن زیرنویس، آن کلمه با رنگ تاکیدی نمایش داده می‌شود.", color = Color(0xFFCFCBEA), style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            item {
                                Panel {
                                    Text("استایل زیرنویس", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Spacer(Modifier.height(8.dp))
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Styles.all.forEach { st ->
                                            FilterChip(selected = ui.styleId == st.id, onClick = { vm.setStyle(st.id) }, label = { Text(st.nameFa) })
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("فونت", style = MaterialTheme.typography.titleSmall, color = Color.White)
                                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        ui.fonts.forEach { f ->
                                            FilterChip(selected = ui.fontId == f.id, onClick = { vm.setFont(f.id) },
                                                label = { Text(if (f.persianOk) f.name else f.name + " (بدون فارسی)") })
                                        }
                                    }
                                    TextButton(onClick = { fontPicker.launch(arrayOf("*/*")) }) { Text("افزودن فونت (.ttf / .otf)") }
                                }
                            }
                            item {
                                Text("متن زیرنویس (کلمه‌های قرمز را بررسی کن)", color = Color.White, style = MaterialTheme.typography.titleSmall)
                            }
                            itemsIndexed(ui.phrases) { i, p ->
                                var t by remember(i) { mutableStateOf(p.text) }
                                Column {
                                    if (p.words.any { it.conf < 0.5f }) {
                                        Text(
                                            buildAnnotatedString {
                                                p.words.forEachIndexed { k, w ->
                                                    if (k > 0) append(" ")
                                                    withStyle(SpanStyle(color = if (w.conf < 0.5f) Color(0xFFFF6B6B) else Color(0xFF9A95C4))) { append(w.text) }
                                                }
                                            },
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    OutlinedTextField(
                                        value = t,
                                        onValueChange = { t = it; vm.editPhrase(i, it) },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                            if (ui.phrases.isEmpty()) {
                                item { Panel { Text("گفتاری تشخیص داده نشد. ویدیو بدون زیرنویس ساخته می‌شه.", color = Color(0xFFCFCBEA)) } }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { vm.export() }, modifier = Modifier.fillMaxWidth()) { Text("ساخت ویدیو") }
                        TextButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("ویدیوی دیگه") }
                    }

                    is Stage.Done -> {
                        Panel {
                            Text("ویدیو آماده شد و توی گالری (Movies/ZirCut) ذخیره شد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Text(ui.debug, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9A95C4))
                            Spacer(Modifier.height(10.dp))
                            AndroidView(
                                factory = { c ->
                                    VideoView(c).apply {
                                        val mc = MediaController(c)
                                        mc.setAnchorView(this)
                                        setMediaController(mc)
                                        setVideoURI(s.uri)
                                        setOnPreparedListener { it.isLooping = true; start() }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(420.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = { share(ctx, s.uri) }, modifier = Modifier.fillMaxWidth()) { Text("اشتراک‌گذاری") }
                        OutlinedButton(onClick = { vm.backToReview() }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش دوباره") }
                        TextButton(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("ویدیوی جدید") }
                    }

                    is Stage.Failed -> Panel {
                        Text("یه مشکلی پیش اومد", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text(s.message, color = Color(0xFFFFB4B4))
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.reset() }, modifier = Modifier.fillMaxWidth()) { Text("برگشت") }
                    }
                }
            }

            if (showSettings) {
                ModalBottomSheet(onDismissRequest = { showSettings = false }) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("تم پس‌زمینه", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Themes.all.forEach { t ->
                                    FilterChip(selected = ui.themeId == t.id, onClick = { vm.setTheme(t.id) }, label = { Text(t.nameFa) })
                                }
                            }
                            Text("زبان ویدیو", style = MaterialTheme.typography.titleMedium)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار").forEach { (code, name) ->
                                    FilterChip(selected = ui.options.language == code, onClick = { vm.setLanguage(code) }, label = { Text(name) })
                                }
                            }
                            Text("مدل تشخیص گفتار", style = MaterialTheme.typography.titleMedium)
                            ModelChips(ui.modelSize, ui.modelsReady) { vm.setModel(it) }
                            SwitchRow("دقت بیشتر (کندتر)", ui.accurate) { vm.setAccurate(it) }
                            Text("خاموش = جستجوی سریع (پیش‌فرض). روشن = جستجوی دقیق‌تر ولی کندتر.", style = MaterialTheme.typography.bodySmall)
                            Text("تشخیص آنلاین (بدون دانلود مدل، دقیق‌ترین)", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "اگر آدرس سرویس آنلاین پر باشد، صدا برای تشخیص فرستاده می‌شود و هیچ مدلی دانلود نمی‌شود. اگر خطا بدهد، مدل روی گوشی استفاده می‌شود.",
                                style = MaterialTheme.typography.bodySmall
                            )
                            OutlinedTextField(value = ui.workerUrl, onValueChange = { vm.setWorkerUrl(it) }, label = { Text("آدرس سرویس آنلاین") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) { content() }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ModelChips(selected: ModelSize, ready: Set<ModelSize>, onSelect: (ModelSize) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        ModelSize.values().forEach { m ->
            FilterChip(
                selected = selected == m,
                onClick = { onSelect(m) },
                label = { Text(m.labelFa + " — " + m.sizeMb + "MB" + if (m in ready) " ✓" else "") }
            )
        }
    }
}

private fun share(ctx: android.content.Context, uri: Uri) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "اشتراک‌گذاری"))
}


@Composable
private fun CaptionPreview(phrase: Phrase, style: app.zircut.core.SubStyle, font: android.graphics.Typeface, layout: CapLayout) {
    val bmp = remember(phrase, style, font, layout) {
        CaptionRenderer(540, 960, style, font, layout).render(phrase, minOf(1, phrase.words.size - 1))
    }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Canvas(Modifier.height(300.dp).aspectRatio(9f / 16f)) {
            drawRect(Color(0xFF15151B))
            val img = bmp.asImageBitmap()
            val k = size.width / 540f
            val w = img.width * k
            val h = img.height * k
            drawImage(
                img,
                dstOffset = IntOffset((layout.x * size.width - w / 2f).toInt(), (layout.y * size.height - h / 2f).toInt()),
                dstSize = IntSize(w.toInt(), h.toInt())
            )
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, min: Float, max: Float, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Color(0xFFCFCBEA), style = MaterialTheme.typography.labelMedium)
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max, steps = steps)
    }
}
