package app.zircut.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import kotlin.math.ceil
import kotlin.math.min

/** Draws one caption (a phrase with the active word highlighted) into a bitmap. */
class CaptionRenderer(
    frameW: Int,
    frameH: Int,
    private val subStyle: SubStyle,
    private val typeface: Typeface
) {
    private val base = min(frameW, frameH).toFloat()
    private val textSize = base * subStyle.sizeFrac
    private val maxW = min(frameW * 0.88f, base * 1.4f).toInt()
    private val pad = (textSize * 0.35f).toInt()

    fun render(p: Phrase, active: Int): Bitmap {
        val sb = SpannableStringBuilder()
        var aStart = -1
        var aEnd = -1
        p.words.forEachIndexed { i, w ->
            if (i > 0) sb.append(' ')
            val st = sb.length
            sb.append(w.text)
            if (i == active) {
                aStart = st
                aEnd = sb.length
            }
        }
        val plain = sb.toString()

        val fillPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = this@CaptionRenderer.typeface
            textSize = this@CaptionRenderer.textSize
            color = subStyle.textColor
        }
        val spannable = SpannableString(plain)
        if (aStart >= 0 && subStyle.highlightColor != 0) {
            spannable.setSpan(ForegroundColorSpan(subStyle.highlightColor), aStart, aEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val fillLayout = makeLayout(spannable, fillPaint)

        var lineMax = 0f
        for (i in 0 until fillLayout.lineCount) lineMax = maxOf(lineMax, fillLayout.getLineWidth(i))

        val w = maxW + 2 * pad
        val h = fillLayout.height + 2 * pad
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        if (subStyle.box) {
            val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = subStyle.boxColor }
            val bw = lineMax + 2 * pad
            val left = (w - bw) / 2f
            c.drawRoundRect(RectF(left, 0f, left + bw, h.toFloat()), textSize * 0.35f, textSize * 0.35f, boxPaint)
        }

        c.save()
        c.translate(pad.toFloat(), pad.toFloat())
        if (subStyle.outline > 0f) {
            val strokePaint = TextPaint(fillPaint).apply {
                this.style = Paint.Style.STROKE
                strokeWidth = textSize * subStyle.outline
                strokeJoin = Paint.Join.ROUND
                color = 0xFF000000.toInt()
            }
            makeLayout(SpannableString(plain), strokePaint).draw(c)
        }
        fillLayout.draw(c)
        c.restore()
        return bmp
    }

    private fun makeLayout(text: CharSequence, paint: TextPaint): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.ANYRTL_LTR)
            .setLineSpacing(0f, 1.05f)
            .build()

    @Suppress("unused")
    private fun roundUp(v: Float) = ceil(v).toInt()
}
