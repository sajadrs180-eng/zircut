package app.zircut.core

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

/**
 * Squeezes 16 kHz mono speech into a small AAC-LC stream inside an .m4a (MP4) container,
 * about 3 KB per second (the 16-bit WAV is 32 KB per second). Groq accepts m4a directly,
 * and small uploads survive filtered mobile networks.
 */
object AacEncoder {
    private const val SR = 16000
    private const val BITRATE = 24_000

    private class Frame(val data: ByteArray, val ptsUs: Long)

    fun encode(samples: FloatArray): ByteArray {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val frames = ArrayList<Frame>()
        var outFmt: MediaFormat? = null
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        buf.clear()
                        val n = minOf(samples.size - pos, buf.capacity() / 2)
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pos * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            buf.order(java.nio.ByteOrder.nativeOrder())
                            for (k in 0 until n) buf.putShort((samples[pos + k].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                            codec.queueInputBuffer(ii, 0, n * 2, pos * 1_000_000L / SR, 0)
                            pos += n
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    idle = 0
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val data = ByteArray(info.size)
                        ob.get(data)
                        frames.add(Frame(data, info.presentationTimeUs))
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFmt = codec.outputFormat
                } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (++idle > 500) throw IllegalStateException("AAC encoder stalled")
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            try { codec.release() } catch (_: Exception) { }
        }
        val format = outFmt ?: throw IllegalStateException("AAC encoder gave no format")
        if (frames.isEmpty()) throw IllegalStateException("AAC encoder gave no data")

        val f = File.createTempFile("zc", ".m4a")
        try {
            val mux = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            try {
                val track = mux.addTrack(format)
                mux.start()
                val bi = MediaCodec.BufferInfo()
                var last = -1L
                for (fr in frames) {
                    val pts = if (fr.ptsUs <= last) last + 1 else fr.ptsUs
                    last = pts
                    bi.set(0, fr.data.size, pts, 0)
                    mux.writeSampleData(track, ByteBuffer.wrap(fr.data), bi)
                }
                mux.stop()
            } finally {
                try { mux.release() } catch (_: Exception) { }
            }
            return f.readBytes()
        } finally {
            f.delete()
        }
    }
}
