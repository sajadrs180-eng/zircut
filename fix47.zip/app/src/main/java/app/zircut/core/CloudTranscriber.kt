package app.zircut.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Online recognition. The app sends small compressed audio pieces to the Cloudflare Worker;
 * only the Worker holds GROQ_API_KEY and talks to Groq Whisper, so no key is ever inside the app.
 */
object CloudTranscriber {
    data class W(val text: String, val startMs: Long, val endMs: Long)

    private class T(val text: String, val s: Long, val e: Long)

    /** The server answered with an error (so the upload itself got through). */
    private class HttpFail(val code: Int, detail: String = "", val retryMs: Long = 0L) :
        IOException("خطای سرویس آنلاین ($code)" + (if (detail.isNotBlank()) ": " + detail.trim().take(160) else ""))

    /** Only used by the old direct-Cloudflare path (no Worker address): the Worker adds its own prompt for Groq. */
    private const val HINT = "سلام دوستان، خوش اومدید. بیست ثانیه، سی ثانیه، چهل و پنج ثانیه، یک دقیقه، پنج دقیقه، یک ساعت، سه روز، دو هفته، یک ماه، ده سال. صد، دویست، هزار، میلیون، میلیارد تومن. می‌خوام، نمی‌دونم، باهاتون، اومدید، گفتم، مثلاً، یعنی، دقیقاً، واقعاً. ویدیو، یوتیوب، اینستاگرام، گوشی، اینترنت، فیلترشکن، گیم، تیم، لول، رنک، پلیر، آنلاین."

    private const val SR = 16000
    private const val MIN_SAMPLES = SR

    /** Largest piece (in samples) that went through a filtered network; it only ever shrinks while the app is open. */
    @Volatile private var maxSamples = 7 * SR

    /** Set when the server could not read the compressed audio and the plain WAV worked instead. */
    @Volatile private var useWav = false

    /** Groq's free tier allows 20 requests per minute: every request waits for its slot. */
    private const val MIN_GAP_MS = 3200L
    private val gateLock = Any()
    private var nextAt = 0L

    private fun waitSlot() {
        val wait: Long
        synchronized(gateLock) {
            val now = System.currentTimeMillis()
            val at = maxOf(now, nextAt)
            nextAt = at + MIN_GAP_MS
            wait = at - now
        }
        if (wait > 0) try { Thread.sleep(wait) } catch (_: InterruptedException) { }
    }

    private fun pushGate(ms: Long) {
        synchronized(gateLock) { nextAt = maxOf(nextAt, System.currentTimeMillis() + ms) }
    }

    /**
     * Uploads are kept small on purpose: filtered mobile networks cut big uploads (connection reset).
     * The audio is compressed (AAC in m4a, about 3 KB per second) and, if a piece is still cut,
     * it is split in two and each half is sent on its own, so the size adapts to the network by itself.
     */
    fun transcribe(workerUrl: String, account: String, token: String, samples: FloatArray, lang: String): List<W> =
        send(workerUrl, account, token, samples, 0L, lang)

    private fun send(workerUrl: String, account: String, token: String, samples: FloatArray, offsetMs: Long, lang: String): List<W> {
        if (samples.size > maxSamples && samples.size > MIN_SAMPLES * 2) return split(workerUrl, account, token, samples, offsetMs, lang)
        var last: IOException? = null
        for (t in 0 until 2) {
            try {
                val ws = sendOnce(workerUrl, account, token, samples, lang)
                return if (offsetMs == 0L) ws else ws.map { W(it.text, it.startMs + offsetMs, it.endMs + offsetMs) }
            } catch (e: HttpFail) {
                throw e
            } catch (e: IOException) {
                last = e
                try { Thread.sleep(600) } catch (_: InterruptedException) { }
            }
        }
        if (samples.size < MIN_SAMPLES * 2) throw last ?: IOException("upload failed")
        synchronized(this) { maxSamples = minOf(maxSamples, samples.size / 2) }
        return split(workerUrl, account, token, samples, offsetMs, lang)
    }

    private fun split(workerUrl: String, account: String, token: String, samples: FloatArray, offsetMs: Long, lang: String): List<W> {
        val cut = quietPoint(samples)
        val a = samples.copyOfRange(0, cut)
        val b = samples.copyOfRange(cut, samples.size)
        val first = send(workerUrl, account, token, a, offsetMs, lang)
        val second = send(workerUrl, account, token, b, offsetMs + cut * 1000L / SR, lang)
        return first + second
    }

    /** The quietest 100 ms near the middle, so a cut rarely lands inside a word. */
    private fun quietPoint(x: FloatArray): Int {
        val mid = x.size / 2
        val span = x.size / 6
        val frame = SR / 10
        var best = mid
        var bestE = Float.MAX_VALUE
        var p = mid - span
        while (p + frame <= mid + span) {
            var e = 0f
            for (k in p until p + frame) e += x[k] * x[k]
            if (e < bestE) { bestE = e; best = p + frame / 2 }
            p += frame
        }
        return best.coerceIn(SR / 2, x.size - SR / 2)
    }

    private fun sendOnce(workerUrl: String, account: String, token: String, samples: FloatArray, lang: String): List<W> {
        val dur = samples.size / 16f
        if (!useWav) {
            val m4a = try { AacEncoder.encode(samples) } catch (e: Exception) { null }
            if (m4a != null && m4a.isNotEmpty()) {
                try {
                    return postRL(workerUrl, account, token, m4a, lang, dur)
                } catch (e: HttpFail) {
                    // the upload arrived but the server could not use it: try the plain WAV once
                    if (e.code == 429 || e.code == 401 || e.code == 403 || e.code == 413 || e.code == 502 || e.code == 500) throw e
                    val r = try {
                        postRL(workerUrl, account, token, toWav(samples), lang, dur)
                    } catch (e2: IOException) {
                        throw e
                    }
                    useWav = true
                    return r
                }
            }
        }
        return postRL(workerUrl, account, token, toWav(samples), lang, dur)
    }

    /** Waits and retries when the service says "too many requests"; a long limit (hour/day) is reported at once. */
    private fun postRL(workerUrl: String, account: String, token: String, audio: ByteArray, lang: String, dur: Float): List<W> {
        var tries = 0
        while (true) {
            try {
                return post(workerUrl, account, token, audio, lang, dur)
            } catch (e: HttpFail) {
                if (e.code != 429 || e.retryMs > 90_000L || ++tries > 6) throw e
                val wait = maxOf(e.retryMs, 4_000L)
                pushGate(wait)
                try { Thread.sleep(wait) } catch (_: InterruptedException) { }
            }
        }
    }

    private fun post(workerUrl: String, account: String, token: String, audio: ByteArray, lang: String, durMs: Float): List<W> {
        val viaWorker = workerUrl.isNotBlank()
        val bytes: ByteArray
        val conn: HttpURLConnection
        if (viaWorker) {
            waitSlot()
            val base = workerUrl.trim()
            val q = "lang=" + java.net.URLEncoder.encode(lang, "UTF-8") + "&hint=" + (if (lang == "fa") "1" else "0")
            bytes = audio
            conn = (URL(base + (if (base.contains('?')) "&" else "?") + q).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8_000
                readTimeout = 60_000
                doOutput = true
                setFixedLengthStreamingMode(bytes.size)
                setRequestProperty("Content-Type", "application/octet-stream")
            }
        } else {
            // old direct path to Cloudflare Workers AI (account + token typed in settings)
            val body = JSONObject().put("audio", android.util.Base64.encodeToString(audio, android.util.Base64.NO_WRAP)).put("task", "transcribe")
            if (lang != "auto") body.put("language", lang)
            if (lang == "fa") body.put("initial_prompt", HINT)
            bytes = body.toString().toByteArray()
            conn = (URL("https://api.cloudflare.com/client/v4/accounts/${account.trim()}/ai/run/@cf/openai/whisper-large-v3-turbo").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 8_000
                readTimeout = 60_000
                doOutput = true
                setFixedLengthStreamingMode(bytes.size)
                setRequestProperty("Authorization", "Bearer ${token.trim()}")
                setRequestProperty("Content-Type", "application/json")
            }
        }
        var ok = false
        try {
            conn.outputStream.use { it.write(bytes) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.readText() ?: ""
            if (code !in 200..299) {
                val retry = ((conn.getHeaderField("Retry-After")?.trim()?.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                throw HttpFail(code, errorText(text), retry)
            }
            val root = try { JSONObject(text) } catch (e: org.json.JSONException) { throw HttpFail(502, "پاسخ نامعتبر") }
            if (root.has("success") && !root.optBoolean("success", true)) throw HttpFail(500, root.optString("error"))
            val res = root.optJSONObject("result") ?: root
            val r = parse(res, durMs)
            ok = true
            return r
        } finally {
            // a healthy connection is kept open and reused: no new TLS handshake for the next piece
            if (!ok) conn.disconnect()
        }
    }

    private fun errorText(t: String): String = try {
        val o = JSONObject(t)
        val e = o.opt("error")
        if (e is JSONObject) e.optString("message") else (e?.toString() ?: t)
    } catch (_: Exception) {
        t
    }

    private fun collect(arr: JSONArray?, into: MutableList<T>) {
        if (arr == null) return
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val w = o.optString("word").trim()
            if (w.isEmpty()) continue
            val s = (o.optDouble("start", 0.0) * 1000).toLong()
            val e = (o.optDouble("end", 0.0) * 1000).toLong()
            into.add(T(w, s, maxOf(e, s + 50)))
        }
    }

    /**
     * The model's full text is the most reliable source for spelling and for which words are separate.
     * The timed word list is only used for timing: each real word of the text gets its time from the matching letters.
     */
    private fun parse(res: JSONObject, durMs: Float): List<W> {
        val segs = res.optJSONArray("segments")
        val timed = ArrayList<T>()
        collect(res.optJSONArray("words"), timed)
        if (timed.isEmpty() && segs != null) {
            for (i in 0 until segs.length()) collect(segs.optJSONObject(i)?.optJSONArray("words"), timed)
        }
        var fullText = res.optString("text").trim()
        if (fullText.isEmpty() && segs != null) {
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.optJSONObject(i)?.optString("text") ?: "").append(' ')
            fullText = sb.toString().trim()
        }
        val tokens = fullText.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) {
            return timed.map { W(it.text, it.s, maxOf(it.e, it.s + 50)) }
        }
        if (timed.isNotEmpty()) {
            val a = align(tokens, timed)
            if (a != null) return a
        }
        val out = ArrayList<W>()
        if (segs != null && segs.length() > 0) {
            for (i in 0 until segs.length()) {
                val sg = segs.optJSONObject(i) ?: continue
                spread(out, sg.optString("text"), (sg.optDouble("start", 0.0) * 1000).toLong(), (sg.optDouble("end", 0.0) * 1000).toLong())
            }
            if (out.size >= tokens.size * 0.9 && out.size <= tokens.size * 1.1) return out
            out.clear()
        }
        spread(out, fullText, 0L, durMs.toLong())
        return out
    }

    /** Letters and digits only (no spaces, no half-space, no punctuation), with Arabic letter variants unified. */
    private fun nz(s: String): String {
        val b = StringBuilder()
        for (ch in s) {
            val c = when (ch) {
                'ي' -> 'ی'
                'ك' -> 'ک'
                else -> ch
            }
            if (c.isLetterOrDigit()) b.append(c.lowercaseChar())
        }
        return b.toString()
    }

    private fun align(tokens: List<String>, timed: List<T>): List<W>? {
        val tn = timed.map { nz(it.text) }
        val kn = tokens.map { nz(it) }
        val timedLen = tn.sumOf { it.length }
        val tokLen = kn.sumOf { it.length }
        if (timedLen == 0 || tokLen == 0) return null
        if (abs(timedLen - tokLen) > 0.15 * maxOf(timedLen, tokLen)) return null

        val startOf = IntArray(timed.size)
        var acc = 0
        for (i in timed.indices) {
            startOf[i] = acc
            acc += tn[i].length
        }
        val scale = timedLen.toDouble() / tokLen

        fun ownerOf(pos: Double): Int {
            var lo = 0
            var hi = timed.size - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (startOf[mid] <= pos) lo = mid else hi = mid - 1
            }
            return lo
        }

        fun timeAt(pos: Double, isEnd: Boolean): Long {
            val p = if (isEnd) maxOf(0.0, pos - 0.001) else minOf(pos, timedLen - 0.001)
            val o = ownerOf(p)
            val len = maxOf(1, tn[o].length)
            val edge = if (isEnd) pos else p
            val frac = ((edge - startOf[o]) / len).coerceIn(0.0, 1.0)
            val t = timed[o]
            return t.s + ((t.e - t.s) * frac).toLong()
        }

        val out = ArrayList<W>()
        var cum = 0
        var prevStart = 0L
        for (i in tokens.indices) {
            val len = kn[i].length
            if (len == 0) {
                if (out.isNotEmpty()) {
                    val l = out.removeAt(out.size - 1)
                    out.add(W(l.text + tokens[i], l.startMs, l.endMs))
                }
                continue
            }
            var s = timeAt(cum * scale, false)
            var e = timeAt((cum + len) * scale, true)
            if (s < prevStart) s = prevStart
            if (e < s + 50) e = s + 50
            out.add(W(tokens[i], s, e))
            prevStart = s
            cum += len
        }
        return if (out.isEmpty()) null else out
    }

    private fun spread(out: MutableList<W>, text: String, s: Long, e: Long) {
        val parts = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val total = parts.sumOf { it.length }.coerceAtLeast(1)
        val end = maxOf(e, s + 200)
        var cur = s
        parts.forEachIndexed { i, p ->
            val d = (end - s) * p.length / total
            out.add(W(p, cur, if (i == parts.size - 1) end else cur + d))
            cur += d
        }
    }

    private fun toWav(s: FloatArray): ByteArray {
        val n = s.size * 2
        val b = ByteBuffer.allocate(44 + n).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt(36 + n).put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(16000).putInt(32000).putShort(2).putShort(16)
        b.put("data".toByteArray()).putInt(n)
        for (v in s) {
            val x = (v.coerceIn(-1f, 1f) * 32767f).toInt()
            b.putShort(x.toShort())
        }
        return b.array()
    }
}
