# Credits

- whisper.cpp (MIT) — https://github.com/ggerganov/whisper.cpp
- OpenAI Whisper models (MIT) — downloaded at first run from https://huggingface.co/ggerganov/whisper.cpp
- AndroidX Media3 Transformer (Apache 2.0)
- Jetpack Compose / Material 3 (Apache 2.0)
- Vazirmatn font (OFL) — https://github.com/rastikerdar/vazirmatn
