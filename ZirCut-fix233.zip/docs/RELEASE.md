# Store-readiness notes (fix212) — honest status

Done / checked in the source:
- Manifest permissions are only INTERNET, WAKE_LOCK (export keeps running), RECORD_AUDIO (voice-over). Media is picked with the system picker (no broad storage permission). allowBackup is off.
- Privacy: no ads, no analytics, no tracking SDK. Audio is sent to the online recognition service ONLY after the user agrees in a dialog (fix212); declining leads to on-phone recognition (model download). Consent can be revoked on the model screen.
- Network use to declare in Data Safety: (a) model download from GitHub/HuggingFace mirrors; (b) optional speech recognition upload (audio chunks of the video, only with consent).

NOT done (needs the owner / a real device):
- Release signing: `release` still uses the DEBUG key (`signingConfig = debug`). A store build needs your own keystore (never put it in the repo).
- Minify/shrink is OFF (`isMinifyEnabled = false`) on purpose: the whisper JNI and media3 need keep-rules that cannot be verified without a build+device test.
- No crash/memory-leak profiling on devices has been done; no Play/Bazaar/Myket listing text or policy pages written.
- Android 14+ foreground-service rules for long exports are not reviewed beyond the existing WAKE_LOCK use.
