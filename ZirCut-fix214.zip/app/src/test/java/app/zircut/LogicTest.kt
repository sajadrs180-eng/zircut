package app.zircut

import app.zircut.core.Frame
import app.zircut.core.Options
import app.zircut.core.Range
import app.zircut.core.fineCover
import app.zircut.timeline.AudioClip
import app.zircut.timeline.AudioOps
import app.zircut.timeline.EdlOps
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-logic unit tests (no Android needed): run with `./gradlew testDebugUnitTest`.
 * WRITTEN WITHOUT A COMPILER / NEVER RUN in the environment where they were authored; if one fails to compile or fails,
 * fix the test or the code from the real message.
 */
class LogicTest {
    private fun segs() = listOf(Range(0, 1000), Range(1000, 3000), Range(3000, 4000))

    @Test fun deleteManyKeepsAtLeastOneClip() {
        assertNull(EdlOps.deleteMany(segs(), setOf(0, 1, 2)))
        val r = EdlOps.deleteMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(1, r!!.segs.size)
        assertEquals(1000L, r.segs[0].startMs)
    }

    @Test fun duplicateManyPutsCopiesAfterEachChosenClip() {
        val r = EdlOps.duplicateMany(segs(), setOf(0, 2))
        assertNotNull(r)
        assertEquals(5, r!!.segs.size)
        assertEquals(r.segs[0], r.segs[1])
        assertEquals(r.segs[3], r.segs[4])
    }

    @Test fun speedManySkipsPhotosAndSpeedsUpTheTimeline() {
        val r = EdlOps.setSpeedMany(segs(), setOf(0, 1), 2f, skip = setOf(0))
        assertNotNull(r)
        assertEquals(1f, r!!.segs[0].speed, 0.001f)
        assertEquals(2f, r.segs[1].speed, 0.001f)
        assertNull(EdlOps.setSpeedMany(segs(), setOf(0), 2f, skip = setOf(0)))
    }

    @Test fun fineCoverIsOneWithoutRotationAndGrows() {
        assertEquals(1f, fineCover(0f, 1080f, 1920f), 0.001f)
        assertTrue(fineCover(10f, 1080f, 1920f) > 1f)
        assertTrue(fineCover(30f, 1080f, 1920f) > fineCover(10f, 1080f, 1920f))
        assertEquals(fineCover(15f, 100f, 100f), fineCover(-15f, 100f, 100f), 0.0001f)
    }

    @Test fun freeAspectRatioRoundTrips() {
        val o = Options(ratio = Frame.customId(1.5f))
        assertEquals(1.5f, Frame.aspect(o), 0.001f)
        assertEquals(1.5f, Frame.free(o)!!, 0.001f)
        assertEquals(Frame.MAX_FREE, Frame.free(Options(ratio = Frame.customId(99f)))!!, 0.001f)
    }

    private fun clip(inMs: Long, lenMs: Long) = AudioClip(1, AudioClip.KIND_VOICE, "a.wav", "a", 1000L, inMs, lenMs, 10_000L)

    @Test fun removeSilenceClosesGapsAndKeepsOrder() {
        // 10 s at 50 peaks/s: loud 0-2 s, silent 2-5 s, loud 5-10 s
        val peaks = ByteArray(500) { i -> if (i in 100 until 250) 0 else 200.toByte() }
        val r = AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36)
        assertNotNull(r)
        assertEquals(2, r!!.size)
        assertEquals(1000L, r[0].startMs)
        assertEquals(r[0].endMs, r[1].startMs)
        assertTrue(r.sumOf { it.lenMs } < 10_000L - 2000L)
    }

    @Test fun removeSilenceReturnsNullWhenNothingIsQuiet() {
        val peaks = ByteArray(500) { 200.toByte() }
        assertNull(AudioOps.removeSilence(listOf(clip(0, 10_000)), 1, peaks, 36))
    }
}
