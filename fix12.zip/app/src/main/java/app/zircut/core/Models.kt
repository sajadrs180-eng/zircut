package app.zircut.core

import android.graphics.Color

data class Word(
    val text: String,
    val startMs: Long,
    val endMs: Long,
    val cutBefore: Boolean = false
)

data class Phrase(val words: List<Word>) {
    val startMs: Long get() = words.first().startMs
    val endMs: Long get() = words.last().endMs
    val text: String get() = words.joinToString(" ") { it.text }
}

data class Range(val startMs: Long, val endMs: Long) {
    val len: Long get() = endMs - startMs
}

data class VideoInfo(val durationMs: Long, val width: Int, val height: Int)

data class Options(
    val captions: Boolean = true,
    val removeSilence: Boolean = true,
    val removeFillers: Boolean = true,
    val zoom: Boolean = true,
    val vertical: Boolean = true,
    val maxGapMs: Long = 500,
    val language: String = "fa"
)

data class SubStyle(
    val id: String,
    val nameFa: String,
    val textColor: Int,
    val highlightColor: Int,
    val box: Boolean,
    val boxColor: Int,
    val outline: Float,
    val sizeFrac: Float,
    val pop: Boolean,
    val fade: Boolean = false,
    val hlBox: Int = 0,
    val glow: Int = 0,
    val font: String = "Vazirmatn-ExtraBold",
    val fontScale: Float = 1f
)

data class CapLayout(
    val x: Float = 0.5f,
    val y: Float = 0.66f,
    val mw: Float = 0.9f,
    val ls: Float = 1.5f,
    val lw: Int = 4,
    val size: Float = 1f
)

object Styles {
    private fun c(h: String) = Color.parseColor(h)

    val all = listOf(
        SubStyle("zarbati", "ضربتی", Color.WHITE, c("#FFD83A"), false, 0, 4f, 0.078f, true, font = "Lalezar-Regular", fontScale = 1.12f),
        SubStyle("clean", "تمیز", Color.WHITE, Color.WHITE, false, 0, 2f, 0.070f, false, fade = true),
        SubStyle("box", "کادر", Color.WHITE, Color.WHITE, true, c("#CC000000"), 0f, 0.066f, false),
        SubStyle("highlight", "هایلایت", Color.WHITE, Color.WHITE, false, 0, 2f, 0.068f, false, hlBox = c("#FFD83A"), font = "Cairo", fontScale = 0.96f),
        SubStyle("vlog", "ویلاگ", Color.WHITE, c("#5CF2C0"), false, 0, 3f, 0.072f, true, font = "Changa"),
        SubStyle("news", "خبری", Color.WHITE, Color.WHITE, true, c("#DD111111"), 0f, 0.062f, false, font = "Vazirmatn-Bold"),
        SubStyle("neon", "نئون", c("#EFE9FF"), c("#C4A8FF"), false, 0, 0f, 0.070f, false, fade = true, glow = c("#8B5CFF"), font = "Cairo", fontScale = 0.96f),
        SubStyle("cinema", "سینمایی", c("#F2F2F2"), Color.WHITE, false, 0, 1.5f, 0.060f, false, fade = true, font = "Vazirmatn-Regular")
    )

    fun byId(id: String): SubStyle = all.firstOrNull { it.id == id } ?: all.first()
}

enum class ModelSize(val id: String, val labelFa: String, val file: String, val sizeMb: Int) {
    TINY("tiny", "سریع (ضعیف‌تر)", "ggml-tiny-q5_1.bin", 31),
    BASE("base", "متوسط", "ggml-base-q5_1.bin", 57),
    SMALL("small", "دقیق (کندتر)", "ggml-small-q5_1.bin", 181),
    TURBO("turbo", "بهترین دقت (۵۷۰ مگابایت، خیلی کندتر)", "ggml-large-v3-turbo-q5_0.bin", 574),
    LARGE("large", "حداکثر دقت (۱ گیگابایت، بسیار کند)", "ggml-large-v3-q5_0.bin", 1080);

    val beam: Int
        get() = when (this) {
            TINY -> 1
            BASE, SMALL -> 2
            TURBO -> 3
            LARGE -> 5
        }

    val url: String
        get() = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"
}
