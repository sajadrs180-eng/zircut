package app.zircut.core

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import java.io.ByteArrayOutputStream

/**
 * Squeezes 16 kHz mono speech into a small AAC-LC (ADTS) stream, about 2.5 KB per second
 * (the 16-bit WAV is 32 KB per second). Small uploads survive filtered mobile networks.
 */
object AacEncoder {
    private const val SR = 16000
    private const val BITRATE = 20_000

    fun encode(samples: FloatArray): ByteArray {
        val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SR, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        val out = ByteArrayOutputStream()
        try {
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var pos = 0
            var inputDone = false
            var outputDone = false
            var idle = 0
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        buf.clear()
                        val n = minOf(samples.size - pos, buf.capacity() / 2)
                        if (n <= 0) {
                            codec.queueInputBuffer(ii, 0, 0, pos * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            buf.order(java.nio.ByteOrder.nativeOrder())
                            for (k in 0 until n) buf.putShort((samples[pos + k].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                            codec.queueInputBuffer(ii, 0, n * 2, pos * 1_000_000L / SR, 0)
                            pos += n
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi >= 0) {
                    idle = 0
                    if (info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val frame = ByteArray(info.size)
                        ob.get(frame)
                        out.write(adts(frame.size))
                        out.write(frame)
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (++idle > 500) throw IllegalStateException("AAC encoder stalled")
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            try { codec.release() } catch (_: Exception) { }
        }
        return out.toByteArray()
    }

    /** 7-byte ADTS header: AAC-LC, 16000 Hz (index 8), mono. */
    private fun adts(frameLen: Int): ByteArray {
        val len = frameLen + 7
        val profile = 2 // AAC LC
        val freq = 8
        val chan = 1
        return byteArrayOf(
            0xFF.toByte(),
            0xF1.toByte(),
            (((profile - 1) shl 6) + (freq shl 2) + (chan shr 2)).toByte(),
            (((chan and 3) shl 6) + (len shr 11)).toByte(),
            ((len and 0x7FF) shr 3).toByte(),
            (((len and 7) shl 5) + 0x1F).toByte(),
            0xFC.toByte()
        )
    }
}
