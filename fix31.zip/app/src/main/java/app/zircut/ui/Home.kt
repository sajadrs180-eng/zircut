package app.zircut.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.zircut.Recent
import app.zircut.UiState
import app.zircut.core.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val CardColor = Color(0xCC12122E)
private val Soft = Color(0xFFB9B4E0)

@Composable
fun HomeScreen(
    ui: UiState,
    modifier: Modifier,
    onNew: () -> Unit,
    onSettings: () -> Unit,
    onOptions: (Options) -> Unit,
    onLanguage: (String) -> Unit,
    onOpen: (Recent) -> Unit,
    onDelete: (Recent) -> Unit
) {
    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("زیرکات", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("ادیتور خودکار ویدیو", color = Soft, fontSize = 13.sp)
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(Color(0x33FFFFFF))
                        .clickable(onClick = onSettings).padding(horizontal = 16.dp, vertical = 9.dp)
                ) { Text("تنظیمات", color = Color.White, fontSize = 14.sp) }
            }
        }

        item {
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(30.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFFB65BFF), Color(0xFF6A1BE0), Color(0xFF3B2BD6))))
                    .clickable(onClick = onNew),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    Modifier.padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    PlusBadge()
                    Column {
                        Text("ساخت پروژه‌ی جدید", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text("ویدیو رو انتخاب کن؛ زیرنویس و ادیت خودکار انجام می‌شه", color = Color(0xFFEDE3FF), fontSize = 13.sp)
                    }
                }
            }
        }

        item { SectionTitle("ادیت خودکار") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ToolTile(Modifier.weight(1f), "زیرنویس خودکار", "فارسی و انگلیسی", ui.options.captions) {
                    onOptions(ui.options.copy(captions = it))
                }
                ToolTile(Modifier.weight(1f), "حذف سکوت و «اِم»", "ویدیو فشرده‌تر می‌شه", ui.options.removeSilence) {
                    onOptions(ui.options.copy(removeSilence = it, removeFillers = it))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ToolTile(Modifier.weight(1f), "زوم ریتمیک", "جلوه‌ی حرکتی روی برش‌ها", ui.options.zoom) {
                    onOptions(ui.options.copy(zoom = it))
                }
                ToolTile(Modifier.weight(1f), "خروجی ۹:۱۶", "ریلز، شورت و استوری", ui.options.vertical) {
                    onOptions(ui.options.copy(vertical = it))
                }
            }
        }

        item { SectionTitle("زبان گفتار ویدیو") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("fa" to "فارسی", "en" to "English", "auto" to "خودکار").forEach { (code, name) ->
                    FilterChip(selected = ui.options.language == code, onClick = { onLanguage(code) }, label = { Text(name) })
                }
            }
        }

        item { SectionTitle("پروژه‌های اخیر") }
        if (ui.recent.isEmpty()) {
            item {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CardColor).padding(20.dp)
                ) {
                    Text("هنوز ویدیویی نساختی. اولین ویدیوت رو بساز؛ بعد از ساخت، اینجا نشون داده می‌شه.", color = Soft, fontSize = 14.sp)
                }
            }
        } else {
            items(ui.recent, key = { it.uri }) { r ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(CardColor)
                        .clickable { onOpen(r) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Thumb(r.uri, Modifier.size(width = 72.dp, height = 96.dp).clip(RoundedCornerShape(14.dp)))
                    Column(Modifier.weight(1f)) {
                        Text(r.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        Text(ago(r.time), color = Soft, fontSize = 12.sp)
                    }
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(Color(0x22FFFFFF))
                            .clickable { onDelete(r) }.padding(horizontal = 12.dp, vertical = 7.dp)
                    ) { Text("حذف", color = Color(0xFFFF9C9C), fontSize = 12.sp) }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun PlusBadge() {
    Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(24.dp)) {
            val w = size.width
            drawLine(Color.White, Offset(w / 2f, 2f), Offset(w / 2f, w - 2f), strokeWidth = 4f, cap = StrokeCap.Round)
            drawLine(Color.White, Offset(2f, w / 2f), Offset(w - 2f, w / 2f), strokeWidth = 4f, cap = StrokeCap.Round)
        }
    }
}

@Composable
private fun ToolTile(modifier: Modifier, title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(shape)
            .background(if (on) Color(0xCC241A4D) else CardColor)
            .border(1.5.dp, if (on) Color(0xFF9147FF) else Color(0x22FFFFFF), shape)
            .clickable { onChange(!on) }
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = Soft, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            if (on) "روشن" else "خاموش",
            color = if (on) Color(0xFF5CF2C0) else Color(0xFF8A86B0),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun Thumb(uri: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, Uri.parse(uri))
                val b = r.getFrameAtTime(500_000L)
                r.release()
                b
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.background(Color(0x33FFFFFF))) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b.asImageBitmap(), contentDescription = null, modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        }
    }
}

private fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000L
    return when {
        m < 1L -> "همین الان"
        m < 60L -> "$m دقیقه پیش"
        m < 1440L -> "${m / 60L} ساعت پیش"
        else -> "${m / 1440L} روز پیش"
    }
}
