@file:OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package app.zircut.ui

import android.graphics.Typeface
import android.media.MediaPlayer
import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import androidx.compose.foundation.Image
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.layout.width
import app.zircut.core.SubStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.runtime.CompositionLocalProvider
import androidx.media3.common.util.UnstableApi
import app.zircut.MainViewModel
import app.zircut.UiState
import app.zircut.core.CapLayout
import app.zircut.core.ColorGrade
import app.zircut.core.Looks
import app.zircut.core.CaptionRenderer
import app.zircut.core.CaptionTimeline
import app.zircut.core.FontStore
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Planner
import app.zircut.core.Range
import app.zircut.core.Styles
import app.zircut.core.VideoInfo
import app.zircut.core.Word
import kotlinx.coroutines.delay

private val Soft = Color(0xFFCFCBEA)
private val Accent = Color(0xFF8B5CFF)

private enum class EdTab(val label: String, val icon: String) {
    CAPTIONS("زیرنویس", "💬"), STYLE("استایل", "🎨"), FILTER("فیلتر", "🎞️"), POSITION("جایگاه", "📍"), FONT("فونت", "🔤"), EDIT("ادیت", "✂️")
}

private class PlayerHolder {
    var mp: MediaPlayer? = null
    var ready = false
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

private fun outTime(pos: Long, ranges: List<Range>): Long {
    var acc = 0L
    for (r in ranges) {
        if (pos >= r.endMs) {
            acc += r.len
        } else {
            if (pos > r.startMs) acc += pos - r.startMs
            break
        }
    }
    return acc
}

/** CapCut-like editor: the video plays on top with live captions, all tools are in the bottom panel. */
@UnstableApi
@Composable
fun EditorScreen(
    ui: UiState,
    vm: MainViewModel,
    onSettings: () -> Unit,
    onPickFont: () -> Unit,
    modifier: Modifier = Modifier
) {
    val info: VideoInfo = ui.info ?: return
    val uri = ui.video ?: return
    val holder = remember { PlayerHolder() }
    var playing by remember { mutableStateOf(false) }
    var posMs by remember { mutableStateOf(0L) }
    var tab by remember { mutableStateOf(EdTab.CAPTIONS) }

    val words = remember(ui.phrases) { ui.phrases.flatMap { it.words } }
    val ranges = remember(words, ui.options, info) { Planner.ranges(words, info.durationMs, ui.options) }
    val kept = ranges.sumOf { it.len }

    fun seek(ms: Long) {
        val t = ms.coerceIn(0L, info.durationMs)
        posMs = t
        val m = holder.mp
        if (m != null && holder.ready) {
            try { m.seekTo(t, MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { }
        }
    }

    fun toggle() {
        val m = holder.mp
        if (m == null || !holder.ready) return
        if (playing) {
            try { m.pause() } catch (_: Exception) { }
            playing = false
        } else {
            if (posMs >= info.durationMs - 150) seek(ranges.firstOrNull()?.startMs ?: 0L)
            try { m.start() } catch (_: Exception) { }
            playing = true
        }
    }

    val rangesNow by rememberUpdatedState(ranges)
    val skipNow by rememberUpdatedState(ui.options.removeSilence)

    LaunchedEffect(Unit) {
        while (true) {
            val v = holder.mp
            if (v != null && holder.ready && playing) {
                val p = try { v.currentPosition.toLong() } catch (_: Exception) { posMs }
                var np = p
                if (skipNow) {
                    val rs = rangesNow
                    val inside = rs.any { p >= it.startMs && p < it.endMs }
                    if (!inside) {
                        val next = rs.firstOrNull { it.startMs > p }
                        if (next != null) {
                            seek(next.startMs)
                            np = next.startMs
                        } else {
                            try { v.pause() } catch (_: Exception) { }
                            playing = false
                        }
                    }
                }
                posMs = np
            }
            delay(33)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            holder.ready = false
            try { holder.mp?.release() } catch (_: Exception) { }
            holder.mp = null
        }
    }

    val appCtx = LocalContext.current
    val style = Styles.byId(ui.styleId)
    val font: Typeface = ui.fonts.firstOrNull { it.id == ui.fontId }?.typeface ?: Typeface.DEFAULT_BOLD
    val timeline = remember(ui.phrases, info) { CaptionTimeline(ui.phrases, listOf(Range(0L, info.durationMs))) }
    val st = if (ui.options.captions) timeline.stateAt(posMs) else null
    val activeIdx = st?.phraseIdx ?: -1

    val va = info.width.toFloat() / info.height
    val fa = if (ui.options.vertical) 9f / 16f else va
    val renderW = 540
    val renderH = (540f / fa).toInt()
    val capBmp = remember(st?.phraseIdx, st?.wordIdx, style, font, ui.layout, ui.phrases, fa) {
        if (st == null || st.phraseIdx !in ui.phrases.indices) null
        else try {
            CaptionRenderer(renderW, renderH, style, font, ui.layout).render(ui.phrases[st.phraseIdx], st.wordIdx)
        } catch (e: Throwable) {
            null
        }
    }
    val curRange = ranges.indexOfFirst { posMs >= it.startMs && posMs < it.endMs }
    val zoom = if (ui.options.zoom && curRange % 2 == 1) 1.18f else 1f

    Column(modifier.fillMaxWidth()) {
        // ---- top bar ----
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.reset() }) { Text("ویدیوی دیگه", color = Soft) }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onSettings) { Text("تنظیمات") }
            Button(onClick = { vm.export() }) { Text("ساخت ویدیو") }
        }

        // ---- preview ----
        BoxWithConstraints(Modifier.fillMaxWidth().weight(1f).padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            var fw: Dp = maxWidth
            var fh: Dp = fw / fa
            if (fh > maxHeight) {
                fh = maxHeight
                fw = fh * fa
            }
            val cw: Dp
            val ch: Dp
            if (va >= fa) {
                ch = fh
                cw = fh * va
            } else {
                cw = fw
                ch = fw / va
            }
            Box(
                Modifier.size(fw, fh).clip(RoundedCornerShape(10.dp)).background(Color.Black)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { toggle() },
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { c ->
                        TextureView(c).apply {
                            surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                override fun onSurfaceTextureAvailable(t: SurfaceTexture, w: Int, h: Int) {
                                    try {
                                        val m = MediaPlayer()
                                        m.setDataSource(appCtx, uri)
                                        m.setSurface(Surface(t))
                                        m.setOnPreparedListener { p ->
                                            holder.ready = true
                                            try { p.seekTo(1L, MediaPlayer.SEEK_CLOSEST) } catch (_: Exception) { }
                                        }
                                        m.setOnCompletionListener { playing = false }
                                        holder.mp = m
                                        m.prepareAsync()
                                    } catch (_: Exception) {
                                    }
                                }

                                override fun onSurfaceTextureSizeChanged(t: SurfaceTexture, w: Int, h: Int) {}

                                override fun onSurfaceTextureDestroyed(t: SurfaceTexture): Boolean {
                                    holder.ready = false
                                    try { holder.mp?.release() } catch (_: Exception) { }
                                    holder.mp = null
                                    return true
                                }

                                override fun onSurfaceTextureUpdated(t: SurfaceTexture) {}
                            }
                        }
                    },
                    modifier = Modifier.requiredSize(cw, ch).graphicsLayer { scaleX = zoom; scaleY = zoom },
                    update = { v -> applyGrade(v, ui.grade) }
                )
                Canvas(Modifier.fillMaxSize()) {
                    val b = capBmp
                    if (b != null && st != null) {
                        val img = b.asImageBitmap()
                        val k = size.width / renderW
                        val w = img.width * k
                        val h = img.height * k
                        val cx = ui.layout.x * size.width
                        val cy = ui.layout.y * size.height
                        val sc = if (style.pop) st.pop else 1f
                        val al = if (style.fade) minOf(1f, st.tMs / 220f) else 1f
                        scale(sc, Offset(cx, cy)) {
                            drawImage(
                                img,
                                dstOffset = IntOffset((cx - w / 2f).toInt(), (cy - h / 2f).toInt()),
                                dstSize = IntSize(w.toInt(), h.toInt()),
                                alpha = al
                            )
                        }
                    }
                    if (!playing) {
                        val c = Offset(size.width / 2f, size.height / 2f)
                        drawCircle(Color(0x66000000), radius = 34.dp.toPx(), center = c)
                        val r = 14.dp.toPx()
                        val path = Path().apply {
                            moveTo(c.x - r * 0.6f, c.y - r)
                            lineTo(c.x + r, c.y)
                            lineTo(c.x - r * 0.6f, c.y + r)
                            close()
                        }
                        drawPath(path, Color.White)
                    }
                }
            }
        }

        // ---- word strip: every word is a chip, tap to jump, the current one follows the video ----
        WordStrip(words, posMs) { t ->
            if (playing) {
                try { holder.mp?.pause() } catch (_: Exception) { }
                playing = false
            }
            seek(t)
        }

        // ---- play button + time + timeline (always left-to-right like a player) ----
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Accent).clickable { toggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(18.dp)) {
                        if (playing) {
                            drawRect(Color.White, Offset(size.width * 0.15f, 0f), Size(size.width * 0.25f, size.height))
                            drawRect(Color.White, Offset(size.width * 0.6f, 0f), Size(size.width * 0.25f, size.height))
                        } else {
                            val p = Path().apply {
                                moveTo(size.width * 0.2f, 0f)
                                lineTo(size.width, size.height / 2f)
                                lineTo(size.width * 0.2f, size.height)
                                close()
                            }
                            drawPath(p, Color.White)
                        }
                    }
                }
                Spacer(Modifier.size(8.dp))
                Text(fmt(outTime(posMs, ranges)) + " / " + fmt(kept), color = Soft, fontSize = 12.sp)
                Spacer(Modifier.size(8.dp))
                TimelineBar(info.durationMs, posMs, ranges, ui.phrases, Modifier.weight(1f)) { seek(it) }
            }
        }

        // ---- bottom tool panel ----
        Box(
            Modifier.fillMaxWidth().height(250.dp).padding(top = 6.dp)
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .background(Color(0xFF15151F)).padding(10.dp)
        ) {
            when (tab) {
                EdTab.CAPTIONS -> CaptionsPanel(
                    phrases = ui.phrases,
                    activeIdx = activeIdx,
                    follow = playing,
                    onSeek = { t ->
                        if (playing) {
                            try { holder.mp?.pause() } catch (_: Exception) { }
                            playing = false
                        }
                        seek(t)
                    },
                    onEdit = { i, t -> vm.editPhrase(i, t) },
                    onMerge = { vm.mergeWithNext(it) },
                    onDelete = { vm.deletePhrase(it) }
                )
                EdTab.STYLE -> Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("استایل زیرنویس", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Styles.all.forEach { s ->
                            StyleCard(s, ui.styleId == s.id, ui.fonts.firstOrNull { it.name == s.font }?.typeface) { vm.setStyle(s.id) }
                        }
                    }
                    Text(
                        "نکته: اگه اول یک کلمه در متن زیرنویس * بذاری، اون کلمه با رنگ تاکیدی نشون داده می‌شه.",
                        color = Soft, style = MaterialTheme.typography.bodySmall
                    )
                }
                EdTab.FILTER -> FilterPanel(ui.video, ui.grade) { vm.setGrade(it) }
                EdTab.POSITION -> PositionPanel(ui.layout) { vm.setLayout(it) }
                EdTab.FONT -> Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("فونت زیرنویس", color = Color.White, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        ui.fonts.forEach { f: FontStore.Font ->
                            FilterChip(
                                selected = ui.fontId == f.id,
                                onClick = { vm.setFont(f.id) },
                                label = { Text(if (f.persianOk) f.name else f.name + " (بدون فارسی)") }
                            )
                        }
                    }
                    TextButton(onClick = onPickFont) { Text("افزودن فونت (.ttf / .otf)") }
                }
                EdTab.EDIT -> EditPanel(ui.options, info, kept) { vm.setOptions(it) }
            }
        }

        // ---- bottom tab bar ----
        Row(Modifier.fillMaxWidth().background(Color(0xFF0B0B12)).padding(vertical = 4.dp, horizontal = 4.dp)) {
            // Nothing is processed when the video opens. The auto-subtitle icon below starts the speech recognition.
            if (ui.phrases.isEmpty()) {
                ActionItem("زیرنویس خودکار", "✨", Modifier.weight(1.4f).padding(horizontal = 3.dp)) { vm.startCaptions() }
            }
            EdTab.values().forEach { t ->
                TabItem(t, tab == t, Modifier.weight(1f).padding(horizontal = 3.dp)) { tab = t }
            }
        }
    }
}

@Composable
private fun TabItem(t: EdTab, sel: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val sc by androidx.compose.animation.core.animateFloatAsState(
        if (sel) 1.3f else 1f,
        androidx.compose.animation.core.spring(dampingRatio = 0.35f, stiffness = 300f),
        label = "tabScale"
    )
    val lift by androidx.compose.animation.core.animateFloatAsState(
        if (sel) -3f else 0f,
        androidx.compose.animation.core.spring(dampingRatio = 0.5f, stiffness = 300f),
        label = "tabLift"
    )
    val bg by androidx.compose.animation.animateColorAsState(
        if (sel) Color(0x448B5CFF) else Color.Transparent,
        androidx.compose.animation.core.tween(250),
        label = "tabBg"
    )
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable { onClick() }.padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(t.icon, fontSize = 20.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc; translationY = lift * density })
        Text(
            t.label,
            color = if (sel) Color(0xFFC9B3FF) else Soft,
            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun WordStrip(words: List<Word>, posMs: Long, onSeek: (Long) -> Unit) {
    if (words.isEmpty()) return
    var lo = 0
    var hi = words.size - 1
    var cur = 0
    while (lo <= hi) {
        val m = (lo + hi) / 2
        if (words[m].startMs <= posMs) { cur = m; lo = m + 1 } else hi = m - 1
    }
    val state = rememberLazyListState()
    LaunchedEffect(cur) { state.animateScrollToItem((cur - 1).coerceAtLeast(0)) }
    LazyRow(
        state = state,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        itemsIndexed(words) { i, w ->
            val sel = i == cur
            Box(
                Modifier.clip(RoundedCornerShape(10.dp))
                    .background(if (sel) Color(0xFF3A3A4D) else Color(0xFF26262F))
                    .clickable { onSeek(w.startMs) }
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(w.text, color = Color.White, fontSize = 16.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                if (sel) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth(0.8f).height(2.dp).background(Accent))
            }
        }
    }
}

@Composable
private fun StyleCard(s: SubStyle, selected: Boolean, tf: Typeface?, onClick: () -> Unit) {
    val ff = if (tf != null) FontFamily(tf) else FontFamily.Default
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.width(88.dp).clip(shape).background(Color(0xFF1E1E2C))
            .border(2.dp, if (selected) Accent else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF3A3A4C)), contentAlignment = Alignment.Center) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color(s.textColor))) { append("سلام ") }
                    withStyle(SpanStyle(color = Color(s.highlightColor))) { append("دنیا") }
                },
                fontFamily = ff,
                fontSize = 15.sp
            )
        }
        Text(s.nameFa, color = if (selected) Color.White else Soft, fontSize = 12.sp)
    }
}

@Composable
private fun TimelineBar(durMs: Long, posMs: Long, ranges: List<Range>, phrases: List<Phrase>, modifier: Modifier, onSeek: (Long) -> Unit) {
    val cb by rememberUpdatedState(onSeek)
    Canvas(
        modifier.height(44.dp)
            .pointerInput(durMs) {
                detectTapGestures { o -> cb((o.x / size.width * durMs).toLong().coerceIn(0L, durMs)) }
            }
            .pointerInput(durMs) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    cb((change.position.x / size.width * durMs).toLong().coerceIn(0L, durMs))
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val top = h * 0.25f
        val th = h * 0.5f
        val d = durMs.coerceAtLeast(1L).toFloat()
        drawRoundRect(Color(0xFF2A2A44), Offset(0f, top), Size(w, th), CornerRadius(8f, 8f))
        for (r in ranges) {
            val x1 = r.startMs / d * w
            val x2 = r.endMs / d * w
            drawRoundRect(Accent, Offset(x1, top), Size(maxOf(3f, x2 - x1), th), CornerRadius(8f, 8f))
        }
        for (p in phrases) {
            val x = p.startMs / d * w
            drawLine(Color(0x66FFFFFF), Offset(x, top), Offset(x, top + th), strokeWidth = 1f)
        }
        val px = (posMs / d * w).coerceIn(0f, w)
        drawLine(Color.White, Offset(px, 2f), Offset(px, h - 2f), strokeWidth = 3f)
        drawCircle(Color.White, radius = 6f, center = Offset(px, h / 2f))
    }
}

@Composable
private fun CaptionsPanel(
    phrases: List<Phrase>,
    activeIdx: Int,
    follow: Boolean,
    onSeek: (Long) -> Unit,
    onEdit: (Int, String) -> Unit,
    onMerge: (Int) -> Unit,
    onDelete: (Int) -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(activeIdx, follow) {
        if (follow && activeIdx in phrases.indices) listState.animateScrollToItem(activeIdx)
    }
    if (phrases.isEmpty()) {
        Text("هنوز زیرنویسی نیست. آیکون «✨ زیرنویس خودکار» پایین صفحه رو بزن تا ساخته بشه. اگه نزنی، ویدیو بدون زیرنویس ساخته می‌شه.", color = Soft)
        return
    }
    LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(phrases) { i, p ->
            var t by remember(p.startMs, p.words.size) { mutableStateOf(p.text) }
            var editIdx by remember(p.startMs, p.words.size) { mutableStateOf(-1) }
            var wordText by remember { mutableStateOf("") }
            val shape = RoundedCornerShape(14.dp)
            Column(
                Modifier.fillMaxWidth().clip(shape)
                    .background(if (i == activeIdx) Color(0x338B5CFF) else Color(0x14FFFFFF))
                    .border(1.dp, if (i == activeIdx) Accent else Color.Transparent, shape)
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmt(p.startMs), color = Soft, fontSize = 12.sp, modifier = Modifier.clickable { onSeek(p.startMs) })
                    Spacer(Modifier.weight(1f))
                    if (i < phrases.size - 1) TextButton(onClick = { onMerge(i) }) { Text("ادغام با بعدی", fontSize = 12.sp) }
                    TextButton(onClick = { onDelete(i) }) { Text("حذف", color = Color(0xFFFF9C9C), fontSize = 12.sp) }
                }
                val bad = p.words.withIndex().filter { it.value.conf < 0.5f }
                if (bad.isNotEmpty()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        bad.forEach { iv ->
                            Box(
                                Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0x44FF6B6B))
                                    .clickable { editIdx = iv.index; wordText = iv.value.text }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) { Text(iv.value.text, color = Color(0xFFFF9C9C), fontSize = 13.sp) }
                        }
                    }
                }
                OutlinedTextField(
                    value = t,
                    onValueChange = { t = it; onEdit(i, it) },
                    modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) onSeek(p.startMs) }
                )
            }
            if (editIdx >= 0 && editIdx < p.words.size) {
                AlertDialog(
                    onDismissRequest = { editIdx = -1 },
                    title = { Text("اصلاح کلمه") },
                    text = { OutlinedTextField(value = wordText, onValueChange = { wordText = it }, singleLine = true) },
                    confirmButton = {
                        TextButton(onClick = {
                            val nt = p.words.mapIndexed { k, w -> if (k == editIdx) wordText.trim() else w.text }
                                .filter { it.isNotEmpty() }.joinToString(" ")
                            t = nt
                            onEdit(i, nt)
                            editIdx = -1
                        }) { Text("تایید") }
                    },
                    dismissButton = { TextButton(onClick = { editIdx = -1 }) { Text("لغو") } }
                )
            }
        }
    }
}

@Composable
private fun PositionPanel(layout: CapLayout, onLayout: (CapLayout) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("بالا" to 0.2f, "بالا‌میانه" to 0.36f, "وسط" to 0.5f, "پایین ایمن" to 0.66f, "خیلی پایین" to 0.82f).forEach { (n, y) ->
                FilterChip(selected = kotlin.math.abs(layout.y - y) < 0.02f, onClick = { onLayout(layout.copy(y = y)) }, label = { Text(n) })
            }
        }
        EdSlider("اندازه", layout.size, 0.6f, 1.5f) { onLayout(layout.copy(size = it)) }
        EdSlider("جای عمودی", layout.y, 0.08f, 0.94f) { onLayout(layout.copy(y = it)) }
        EdSlider("جای افقی", layout.x, 0.1f, 0.9f) { onLayout(layout.copy(x = it)) }
        EdSlider("عرض متن", layout.mw, 0.4f, 0.96f) { onLayout(layout.copy(mw = it)) }
        EdSlider("فاصله خطوط", layout.ls, 1.1f, 2f) { onLayout(layout.copy(ls = it)) }
        EdSlider("کلمه در هر خط", layout.lw.toFloat(), 1f, 6f, steps = 4) { onLayout(layout.copy(lw = it.toInt())) }
    }
}

@Composable
private fun EditPanel(opt: Options, info: VideoInfo, kept: Long, onOptions: (Options) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState())) {
        EdSwitch("زیرنویس", opt.captions) { onOptions(opt.copy(captions = it)) }
        EdSwitch("حذف سکوت‌ها", opt.removeSilence) { onOptions(opt.copy(removeSilence = it)) }
        EdSwitch("زوم ریتمی", opt.zoom) { onOptions(opt.copy(zoom = it)) }
        EdSwitch("خروجی عمودی (۹:۱۶)", opt.vertical) { onOptions(opt.copy(vertical = it)) }
        Spacer(Modifier.height(6.dp))
        Text("مدت ویدیو: ${info.durationMs / 1000} ثانیه  ←  بعد از ادیت: ${kept / 1000} ثانیه", color = Soft, fontSize = 13.sp)
    }
}

@Composable
private fun EdSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EdSlider(label: String, value: Float, min: Float, max: Float, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, color = Soft, style = MaterialTheme.typography.labelMedium)
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max, steps = steps)
    }
}


/** Live preview of the color grade: the same matrix the exporter uses is applied to the video surface. */
private fun applyGrade(v: View, g: ColorGrade) {
    if (v.tag == g) return
    v.tag = g
    if (g.isIdentity) {
        v.setLayerType(View.LAYER_TYPE_NONE, null)
        return
    }
    val p = android.graphics.Paint()
    p.colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix(g.affine().toColorMatrix()))
    v.setLayerType(View.LAYER_TYPE_HARDWARE, p)
}

@Composable
private fun FilterPanel(video: android.net.Uri?, grade: ColorGrade, onGrade: (ColorGrade) -> Unit) {
    val ctx = LocalContext.current
    val frame by produceState<Bitmap?>(null, video) {
        value = withContext(Dispatchers.IO) {
            val src = video ?: return@withContext null
            try {
                val r = MediaMetadataRetriever()
                r.setDataSource(ctx, src)
                val b = r.getFrameAtTime(1_000_000L)
                r.release()
                if (b == null) null else {
                    val k = 160f / maxOf(b.width, b.height)
                    Bitmap.createScaledBitmap(b, maxOf(1, (b.width * k).toInt()), maxOf(1, (b.height * k).toInt()), true)
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Looks.all.forEach { look ->
                val sel = grade.lookId == look.id
                val m = ColorGrade(lookId = look.id).affine().toColorMatrix()
                Column(
                    Modifier.clickable { onGrade(grade.copy(lookId = look.id)) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val shape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.size(width = 62.dp, height = 82.dp).clip(shape).background(Color(0x22FFFFFF))
                            .border(2.dp, if (sel) Accent else Color.Transparent, shape)
                    ) {
                        val b = frame
                        if (b != null) {
                            Image(
                                bitmap = b.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.matchParentSize(),
                                contentScale = ContentScale.Crop,
                                colorFilter = ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(m))
                            )
                        }
                    }
                    Text(look.nameFa, color = if (sel) Color.White else Soft, fontSize = 12.sp)
                }
            }
        }
        if (grade.lookId != "none") EdSlider("شدت فیلتر", grade.strength, 0f, 1f) { onGrade(grade.copy(strength = it)) }
        EdSlider("روشنایی", grade.brightness, -0.3f, 0.3f) { onGrade(grade.copy(brightness = it)) }
        EdSlider("کنتراست", grade.contrast, 0.6f, 1.6f) { onGrade(grade.copy(contrast = it)) }
        EdSlider("اشباع رنگ", grade.saturation, 0f, 2f) { onGrade(grade.copy(saturation = it)) }
        EdSlider("گرمی / سردی", grade.warmth, -1f, 1f) { onGrade(grade.copy(warmth = it)) }
        EdSlider("مایل به سبز / سرخ", grade.tint, -1f, 1f) { onGrade(grade.copy(tint = it)) }
        EdSlider("محو (رنگ مات)", grade.fade, 0f, 0.3f) { onGrade(grade.copy(fade = it)) }
        TextButton(onClick = { onGrade(ColorGrade()) }) { Text("برگرداندن همه به حالت اصلی") }
    }
}


/** A bottom-bar item that runs an action instead of opening a panel. */
@Composable
private fun ActionItem(label: String, icon: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x448B5CFF)).clickable { onClick() }.padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 20.sp)
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
