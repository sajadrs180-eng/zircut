package app.zircut

import android.app.Application
import android.app.ActivityManager
import android.content.ContentValues
import android.content.Context
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import app.zircut.core.AudioDecoder
import app.zircut.core.Exporter
import app.zircut.core.FontStore
import app.zircut.core.ModelManager
import app.zircut.core.ModelSize
import app.zircut.core.Options
import app.zircut.core.Phrase
import app.zircut.core.Planner
import app.zircut.core.CapLayout
import app.zircut.core.Diag
import app.zircut.core.Styles
import app.zircut.core.VideoInfo
import app.zircut.core.WhisperBridge
import app.zircut.core.Word
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface Stage {
    data object Idle : Stage
    data object NeedModel : Stage
    data class Working(val label: String, val progress: Float?) : Stage
    data object Review : Stage
    data class Done(val uri: Uri) : Stage
    data class Failed(val message: String) : Stage
}

data class UiState(
    val stage: Stage = Stage.Idle,
    val video: Uri? = null,
    val info: VideoInfo? = null,
    val phrases: List<Phrase> = emptyList(),
    val options: Options = Options(),
    val styleId: String = "zarbati",
    val layout: CapLayout = CapLayout(),
    val debug: String = "",
    val fontId: String = "",
    val themeId: String = "violet_blue",
    val modelSize: ModelSize = ModelSize.SMALL,
    val fonts: List<FontStore.Font> = emptyList(),
    val modelsReady: Set<ModelSize> = emptySet()
)

@UnstableApi
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app.applicationContext
    private val prefs = ctx.getSharedPreferences("zircut", Context.MODE_PRIVATE)
    private val fontStore = FontStore(ctx)
    private val models = ModelManager(ctx)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var job: Job? = null
    private var exporter: Exporter? = null

    init {
        val mem = (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager)
            .let { am -> ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem }
        val defaultModel = if (mem >= 5_500_000_000L) ModelSize.SMALL else ModelSize.BASE
        val savedModel = ModelSize.values().firstOrNull { it.id == prefs.getString("model", null) } ?: defaultModel
        val fonts = fontStore.list()
        val savedFont = prefs.getString("font", null)
        val styleFont = Styles.byId(prefs.getString("style", "zarbati") ?: "zarbati").font
        val fontId = fonts.firstOrNull { it.id == savedFont }?.id
            ?: fonts.firstOrNull { it.name == styleFont }?.id ?: fonts.first().id
        _ui.update {
            it.copy(
                themeId = prefs.getString("theme", "violet_blue") ?: "violet_blue",
                styleId = prefs.getString("style", "zarbati") ?: "zarbati",
                layout = CapLayout(
                    x = prefs.getFloat("lx", 0.5f), y = prefs.getFloat("ly", 0.66f), mw = prefs.getFloat("lmw", 0.9f),
                    ls = prefs.getFloat("lls", 1.5f), lw = prefs.getInt("llw", 4), size = prefs.getFloat("lsz", 1f)
                ),
                options = it.options.copy(language = prefs.getString("lang", "fa") ?: "fa"),
                modelSize = savedModel,
                fonts = fonts,
                fontId = fontId,
                modelsReady = ModelSize.values().filter { m -> models.has(m) }.toSet()
            )
        }
    }

    // ---------- settings ----------
    fun setTheme(id: String) { prefs.edit().putString("theme", id).apply(); _ui.update { it.copy(themeId = id) } }
    fun setStyle(id: String) {
        prefs.edit().putString("style", id).apply()
        val want = Styles.byId(id).font
        _ui.update { s ->
            val f = s.fonts.firstOrNull { it.name == want }?.id
            if (f != null) prefs.edit().putString("font", f).apply()
            s.copy(styleId = id, fontId = f ?: s.fontId)
        }
    }
    fun setLayout(l: CapLayout) {
        prefs.edit().putFloat("lx", l.x).putFloat("ly", l.y).putFloat("lmw", l.mw)
            .putFloat("lls", l.ls).putInt("llw", l.lw).putFloat("lsz", l.size).apply()
        _ui.update { it.copy(layout = l) }
    }
    fun setFont(id: String) { prefs.edit().putString("font", id).apply(); _ui.update { it.copy(fontId = id) } }
    fun setLanguage(l: String) { prefs.edit().putString("lang", l).apply(); _ui.update { it.copy(options = it.options.copy(language = l)) } }
    fun setModel(m: ModelSize) { prefs.edit().putString("model", m.id).apply(); _ui.update { it.copy(modelSize = m) } }
    fun setOptions(o: Options) { _ui.update { it.copy(options = o) } }

    fun addFont(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            }
            val id = fontStore.import(uri, name)
            val fonts = fontStore.list()
            _ui.update { it.copy(fonts = fonts, fontId = id ?: it.fontId) }
            if (id != null) prefs.edit().putString("font", id).apply()
        }
    }

    // ---------- flow ----------
    fun pickVideo(uri: Uri) {
        viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال بررسی ویدیو…", null), video = uri, phrases = emptyList()) }
            val info = try {
                withContext(Dispatchers.IO) { probe(uri) }
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("این ویدیو باز نشد: ${e.message}")) }
                return@launch
            }
            _ui.update { it.copy(info = info) }
            if (models.has(_ui.value.modelSize)) startTranscribe() else _ui.update { it.copy(stage = Stage.NeedModel) }
        }
    }

    private fun probe(uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            if (dur <= 0 || w <= 0 || h <= 0) throw IllegalStateException("اطلاعات ویدیو ناقصه")
            return VideoInfo(dur, w, h)
        } finally {
            r.release()
        }
    }

    fun downloadModel() {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", 0f)) }
            try {
                models.download(m) { p -> _ui.update { s -> s.copy(stage = Stage.Working("در حال دانلود مدل (${m.sizeMb} مگابایت)…", p)) } }
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("دانلود مدل نشد (${e.message}). اگه سایت فیلتره، فایل مدل رو جداگانه بگیر و با «وارد کردن فایل» انتخاب کن.")) }
            }
        }
    }

    fun importModel(uri: Uri) {
        val m = _ui.value.modelSize
        job?.cancel()
        job = viewModelScope.launch {
            _ui.update { it.copy(stage = Stage.Working("در حال وارد کردن مدل…", null)) }
            try {
                models.importFrom(uri, m)
                _ui.update { it.copy(modelsReady = it.modelsReady + m) }
                startTranscribe()
            } catch (e: Exception) {
                _ui.update { it.copy(stage = Stage.Failed("وارد کردن مدل نشد: ${e.message}")) }
            }
        }
    }

    fun startTranscribe() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val modelFile = models.file(st.modelSize)
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.Default) {
            val bridge = WhisperBridge()
            var wctx = 0L
            try {
                _ui.update { it.copy(stage = Stage.Working("در حال خواندن صدا…", 0f)) }
                val pcm = AudioDecoder.decode(ctx, uri) { p ->
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال خواندن صدا…", p)) }
                }
                ensureActive()
                wctx = bridge.loadModel(modelFile.absolutePath)
                if (wctx == 0L) throw IllegalStateException("مدل بارگذاری نشد. فایل مدل خراب یا ناقصه.")
                val chunks = AudioDecoder.chunk(pcm)
                val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
                val raw = ArrayList<Word>()
                chunks.forEachIndexed { i, c ->
                    ensureActive()
                    _ui.update { s -> s.copy(stage = Stage.Working("در حال تشخیص گفتار… (${i + 1} از ${chunks.size})", i.toFloat() / chunks.size)) }
                    val rows = bridge.transcribe(wctx, c.samples, st.options.language, threads)
                    for (row in rows) {
                        val p = row.split('\t', limit = 3)
                        if (p.size < 3) continue
                        val s = p[0].toLongOrNull() ?: continue
                        val e = p[1].toLongOrNull() ?: continue
                        raw.add(Word(p[2], c.startMs + s, c.startMs + maxOf(e, s + 50)))
                    }
                }
                val words = Planner.clean(raw, st.options.removeFillers)
                if (words.isEmpty()) {
                    throw IllegalStateException("هیچ گفتاری تشخیص داده نشد (تعداد خام: ${raw.size}). مدل بزرگ‌تر (base یا small) را امتحان کن یا ویدیویی با صدای واضح‌تر بده.")
                }
                val phrases = Planner.phrases(words)
                _ui.update { it.copy(phrases = phrases, stage = Stage.Review) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Throwable) {
                _ui.update { it.copy(stage = Stage.Failed(e.message ?: "خطای ناشناخته")) }
            } finally {
                if (wctx != 0L) bridge.release(wctx)
            }
        }
    }

    fun editPhrase(index: Int, text: String) {
        _ui.update { s ->
            if (index !in s.phrases.indices) return@update s
            val list = s.phrases.toMutableList()
            list[index] = Planner.rebuild(list[index], text)
            s.copy(phrases = list)
        }
    }

    fun cancel() {
        exporter?.cancel()
        job?.cancel()
        _ui.update { it.copy(stage = if (it.phrases.isNotEmpty()) Stage.Review else Stage.Idle) }
    }

    fun reset() {
        job?.cancel()
        _ui.update { it.copy(stage = Stage.Idle, video = null, info = null, phrases = emptyList()) }
    }

    fun backToReview() { _ui.update { it.copy(stage = Stage.Review) } }

    // ---------- export ----------
    fun export() {
        val st = _ui.value
        val uri = st.video ?: return
        val info = st.info ?: return
        val words = st.phrases.flatMap { it.words }
        val ranges = Planner.ranges(words, info.durationMs, st.options)
        val font = st.fonts.firstOrNull { it.id == st.fontId }?.typeface ?: Typeface.DEFAULT_BOLD
        val out = File(ctx.cacheDir, "zircut_out.mp4").also { it.delete() }
        Diag.reset()
        val first = st.phrases.firstOrNull()
        val dbg = "عبارت‌ها ${st.phrases.size} · کلمه‌ها ${words.size} · بازه‌ها ${ranges.size} · مجموع ${ranges.sumOf { it.len }}ms از ${info.durationMs}ms · زیرنویس=${st.options.captions} · عمودی=${st.options.vertical}" +
            (if (first != null) "\nاولین عبارت: «${first.words.joinToString(" ") { it.text }}» از ${first.startMs} تا ${first.endMs}ms" else "\nهیچ عبارتی وجود ندارد")
        _ui.update { it.copy(debug = dbg, stage = Stage.Working("در حال ساخت ویدیو…", 0f)) }

        val ex = Exporter(ctx)
        exporter = ex
        ex.start(
            Exporter.Params(uri, info, ranges, st.phrases, Styles.byId(st.styleId), font, st.options, out, st.layout),
            onProgress = { p -> _ui.update { s -> if (s.stage is Stage.Working) s.copy(stage = Stage.Working("در حال ساخت ویدیو…", p)) else s } },
            onDone = {
                viewModelScope.launch {
                    try {
                        val saved = withContext(Dispatchers.IO) { saveToGallery(out) }
                        _ui.update { it.copy(debug = it.debug + "\n" + Diag.text(), stage = Stage.Done(saved)) }
                    } catch (e: Exception) {
                        _ui.update { it.copy(stage = Stage.Failed("ذخیره ویدیو نشد: ${e.message}")) }
                    }
                }
            },
            onError = { msg -> _ui.update { it.copy(stage = Stage.Failed(msg)) } }
        )
    }

    private fun saveToGallery(file: File): Uri {
        val resolver = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ZirCut_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZirCut")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("دسترسی به گالری ممکن نشد")
        resolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        return uri
    }
}
