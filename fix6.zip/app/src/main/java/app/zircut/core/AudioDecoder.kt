package app.zircut.core

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.sqrt

object AudioDecoder {
    private const val TARGET_SR = 16000

    private class Growable {
        var data = FloatArray(1 shl 20)
        var size = 0
        fun add(v: Float) {
            if (size == data.size) data = data.copyOf(data.size * 2)
            data[size++] = v
        }
        fun toArray(): FloatArray = data.copyOf(size)
    }

    fun decode(ctx: Context, uri: Uri, onProgress: (Float) -> Unit = {}): FloatArray {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val m = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (m.startsWith("audio/")) {
                track = i
                fmt = f
                break
            }
        }
        if (track < 0 || fmt == null) {
            ex.release()
            throw IllegalStateException("این ویدیو صدا ندارد")
        }
        ex.selectTrack(track)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        val out = Growable()
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var prev = 0f
        var phase = 0.0

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        val buf = codec.getInputBuffer(idx)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val t = ex.sampleTime
                            codec.queueInputBuffer(idx, 0, n, t, 0)
                            if (durationUs > 0) onProgress((t.toFloat() / durationUs).coerceIn(0f, 1f))
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = codec.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = sb.remaining() / ch
                        val mono = FloatArray(frames)
                        for (f in 0 until frames) {
                            var s = 0f
                            for (c in 0 until ch) s += sb.get() / 32768f
                            mono[f] = s / ch
                        }
                        val step = sr.toDouble() / TARGET_SR
                        val n = mono.size
                        var p = phase
                        while (true) {
                            val i = p.toInt()
                            if (i + 1 > n) break
                            val a = if (i == 0) prev else mono[i - 1]
                            val b = mono[i]
                            val fr = (p - i).toFloat()
                            out.add(a + (b - a) * fr)
                            p += step
                        }
                        phase = p - n
                        if (n > 0) prev = mono[n - 1]
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            ex.release()
        }
        return out.toArray()
    }

    class Chunk(val startMs: Long, val samples: FloatArray)

    /** Splits audio into ~28s windows, cutting at the quietest moment near the end. Silent windows are skipped. */
    fun chunk(audio: FloatArray): List<Chunk> {
        val sr = TARGET_SR
        val target = 28 * sr
        val search = 4 * sr
        val frame = sr / 10
        val res = ArrayList<Chunk>()
        var start = 0
        while (start < audio.size) {
            var end = minOf(start + target, audio.size)
            if (end < audio.size) {
                var bestPos = end
                var bestE = Float.MAX_VALUE
                var p = end - search
                while (p + frame <= end) {
                    var e = 0f
                    for (k in p until p + frame) e += audio[k] * audio[k]
                    if (e < bestE) { bestE = e; bestPos = p + frame / 2 }
                    p += frame
                }
                if (bestPos > start + sr) end = bestPos
            }
            val seg = audio.copyOfRange(start, end)
            var sum = 0.0
            for (v in seg) sum += (v * v).toDouble()
            val rms = sqrt(sum / maxOf(1, seg.size))
            if (rms > 0.003) res.add(Chunk(start * 1000L / sr, seg))
            start = end
        }
        return res
    }
}
