package app.zircut.core

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class ModelManager(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "models").apply { mkdirs() }

    fun file(m: ModelSize) = File(dir, m.file)
    fun has(m: ModelSize): Boolean = file(m).let { it.exists() && it.length() > 5_000_000 }

    suspend fun download(m: ModelSize, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val part = File(dir, m.file + ".part")
        val dest = file(m)
        val conn = (URL(m.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
        }
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) throw IOException("خطای سرور: ${conn.responseCode}")
            val total = conn.contentLengthLong
            var read = 0L
            conn.inputStream.use { ins ->
                part.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                        read += n
                        ensureActive()
                        if (total > 0) onProgress(read.toFloat() / total)
                    }
                }
            }
            if (!part.renameTo(dest)) throw IOException("ذخیره مدل ناموفق بود")
        } finally {
            conn.disconnect()
            if (part.exists() && !dest.exists()) part.delete()
        }
    }

    suspend fun importFrom(uri: Uri, m: ModelSize) = withContext(Dispatchers.IO) {
        val dest = file(m)
        ctx.contentResolver.openInputStream(uri)!!.use { ins ->
            dest.outputStream().use { o -> ins.copyTo(o) }
        }
    }
}
