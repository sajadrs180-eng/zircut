package app.zircut.core

class WhisperBridge {
    external fun loadModel(modelPath: String): Long
    external fun release(ctx: Long)
    external fun transcribe(ctx: Long, audio: FloatArray, lang: String, threads: Int): Array<String>

    companion object {
        init {
            System.loadLibrary("zircut_whisper")
        }
    }
}
