package app.zircut.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import app.zircut.R

private val Scheme = darkColorScheme(
    primary = Color(0xFF9147FF),
    onPrimary = Color.White,
    secondary = Color(0xFF1F6BFF),
    onSecondary = Color.White,
    background = Color(0xFF0B0D2A),
    surface = Color(0xFF12122E),
    onSurface = Color(0xFFEDEBFF),
    onBackground = Color(0xFFEDEBFF)
)

@Composable
fun ZirCutTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

data class BgTheme(val id: String, val nameFa: String, val res: Int)

object Themes {
    val all = listOf(
        BgTheme("violet_blue", "بنفش‌آبی", R.drawable.bg_violet_blue),
        BgTheme("night_blue", "شب آبی", R.drawable.bg_night_blue),
        BgTheme("graphite", "گرافیتی", R.drawable.bg_graphite),
        BgTheme("forest", "جنگل", R.drawable.bg_forest),
        BgTheme("ocean", "اقیانوس", R.drawable.bg_ocean),
        BgTheme("crimson", "قرمز", R.drawable.bg_crimson)
    )

    fun byId(id: String) = all.firstOrNull { it.id == id } ?: all.first()
}
